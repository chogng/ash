use crate::managed::WorkPermit;
use crate::managed::lifetime::ObjectGuard;
use crate::ondisk::IndexLayout;
/// Mmap-based read-only index reader.
///
/// Uses memory-mapped files for zero-copy access to `lookup.bin` and
/// `index.bin`. Binary searches the sorted lookup table to find
/// posting lists for queried trigrams.
use memmap2::Mmap;
use std::fs::File;
use std::path::Path;
use std::sync::Arc;

use crate::Result;
use crate::ondisk::{self, LOOKUP_ENTRY_SIZE, LookupEntry, POSTING_ENTRY_SIZE, PostingEntry};

#[derive(Clone, Copy)]
pub(crate) struct SnapshotLimits {
    pub(crate) files: u64,
    pub(crate) metadata: u64,
    lookup: u64,
    postings: u64,
}

impl SnapshotLimits {
    pub(crate) fn measure(
        layout: IndexLayout,
        mut open: impl FnMut(&str) -> Result<File>,
    ) -> Result<Self> {
        use std::io::{Seek, SeekFrom};
        Ok(Self {
            files: open(layout.files())?.seek(SeekFrom::End(0))?,
            metadata: open(layout.meta())?.seek(SeekFrom::End(0))?,
            lookup: open(layout.lookup())?.seek(SeekFrom::End(0))?,
            postings: open(layout.postings())?.seek(SeekFrom::End(0))?,
        })
    }

    pub(crate) fn private_estimate(&self) -> crate::managed::Result<u64> {
        self.files
            .checked_mul(12)
            .and_then(|bytes| {
                self.metadata
                    .checked_mul(8)
                    .and_then(|meta| bytes.checked_add(meta))
            })
            .and_then(|bytes| bytes.checked_add(64 * 1024))
            .ok_or_else(|| crate::managed::Error::pressure("base-private-account-overflow"))
    }

    pub(crate) fn mapped_bytes(&self) -> crate::managed::Result<u64> {
        self.lookup
            .checked_add(self.postings)
            .ok_or_else(|| crate::managed::Error::pressure("generation-mapped-account-overflow"))
    }
}

pub struct IndexReader {
    lookup: Option<Mmap>,
    postings: Option<Mmap>,
    file_paths: Vec<String>,
    file_table_id: crate::meta::FileTableId,
    /// File IDs sorted by path, for exact membership checks without duplicating
    /// every path string in a second collection.
    path_order: Vec<usize>,
    /// Populated only by strict snapshot validation, in its existing posting pass.
    snapshot_file_has_postings: Vec<bool>,
    num_entries: usize,
    managed: Option<Arc<ObjectGuard>>,
    retained: Vec<crate::managed::memory::RetainedMemory>,
}

impl IndexReader {
    pub fn open(index_dir: &Path) -> Result<Self> {
        crate::managed::reject_unguarded(index_dir)?;
        Self::open_impl(index_dir, false, IndexLayout::Legacy, None, None, None)
    }

    /// Open every section needed to identify an immutable snapshot. Ordinary
    /// readers retain their legacy empty-section handling.
    pub(crate) fn open_for_snapshot(index_dir: &Path) -> Result<Self> {
        crate::managed::reject_unguarded(index_dir)?;
        Self::open_snapshot(index_dir, IndexLayout::Legacy, None, None, None)
    }

    pub(crate) fn open_for_snapshot_controlled(
        index_dir: &Path,
        permit: &Arc<WorkPermit>,
        limits: &SnapshotLimits,
    ) -> Result<Self> {
        crate::managed::reject_unguarded(index_dir)?;
        Self::open_snapshot(
            index_dir,
            IndexLayout::Legacy,
            None,
            Some(permit),
            Some(limits),
        )
    }

    pub(crate) fn open_managed(
        guard: Arc<ObjectGuard>,
        permit: Option<&Arc<WorkPermit>>,
        limits: &SnapshotLimits,
    ) -> Result<Self> {
        let directory = guard.directory.path().to_path_buf();
        Self::open_snapshot(
            &directory,
            IndexLayout::Managed,
            Some(guard),
            permit,
            Some(limits),
        )
    }

    fn open_snapshot(
        index_dir: &Path,
        layout: IndexLayout,
        guard: Option<Arc<ObjectGuard>>,
        permit: Option<&Arc<WorkPermit>>,
        limits: Option<&SnapshotLimits>,
    ) -> Result<Self> {
        let mut reader = Self::open_impl(index_dir, true, layout, guard, permit, limits)?;
        reader.validate_lookup_controlled(permit)?;
        reader.snapshot_file_has_postings = reader.validate_snapshot_postings(permit)?;
        Ok(reader)
    }

    fn validate_snapshot_postings(&self, permit: Option<&Arc<WorkPermit>>) -> Result<Vec<bool>> {
        let mut file_has_postings = vec![false; self.file_paths.len()];
        let mut expected_offset = 0_u64;
        for i in 0..self.num_entries {
            if let Some(permit) = permit {
                permit.check()?;
            }
            let entry = self.read_lookup_entry(i);
            if entry.trigram > 0x00ff_ffff {
                return Err(crate::Error::IndexCorrupted(format!(
                    "shared base lookup entry {i} has an invalid trigram"
                )));
            }
            if entry.offset != expected_offset {
                return Err(crate::Error::IndexCorrupted(format!(
                    "shared base lookup entry {i} has posting offset {}, expected {expected_offset}",
                    entry.offset
                )));
            }
            let (_, bytes) = self.nth_trigram_raw(i).ok_or_else(|| {
                crate::Error::IndexCorrupted(format!(
                    "shared base lookup entry {i} has an invalid posting range"
                ))
            })?;
            let mut previous_file_id = None;
            for (index, raw) in bytes.as_chunks::<POSTING_ENTRY_SIZE>().0.iter().enumerate() {
                if index.is_multiple_of(4096)
                    && let Some(permit) = permit
                {
                    permit.check()?;
                }
                let posting = PostingEntry::decode(raw);
                if self.file_path(posting.file_id).is_none() {
                    return Err(crate::Error::IndexCorrupted(format!(
                        "shared base lookup entry {i} references out-of-range file_id {}",
                        posting.file_id
                    )));
                }
                if previous_file_id.is_some_and(|previous| posting.file_id <= previous) {
                    return Err(crate::Error::IndexCorrupted(format!(
                        "shared base lookup entry {i} has non-increasing posting file IDs"
                    )));
                }
                if posting.loc_mask == 0 {
                    return Err(crate::Error::IndexCorrupted(format!(
                        "shared base lookup entry {i} has a zero location mask for file_id {}",
                        posting.file_id
                    )));
                }
                file_has_postings[posting.file_id as usize] = true;
                previous_file_id = Some(posting.file_id);
            }
            expected_offset += bytes.len() as u64;
        }
        let postings_len = self.postings.as_ref().map_or(0, |postings| postings.len()) as u64;
        if expected_offset != postings_len {
            return Err(crate::Error::IndexCorrupted(
                "shared base index.bin contains unreferenced posting bytes".to_string(),
            ));
        }
        Ok(file_has_postings)
    }

    fn open_impl(
        index_dir: &Path,
        require_complete_sections: bool,
        layout: IndexLayout,
        guard: Option<Arc<ObjectGuard>>,
        permit: Option<&Arc<WorkPermit>>,
        limits: Option<&SnapshotLimits>,
    ) -> Result<Self> {
        if let Some(permit) = permit {
            permit.check()?;
        }
        let lookup_path = index_dir.join(layout.lookup());
        let postings_path = index_dir.join(layout.postings());
        let files_path = index_dir.join(layout.files());

        if guard.is_none()
            && (!lookup_path.exists() || !postings_path.exists() || !files_path.exists())
        {
            return Err(crate::Error::IndexNotFound(index_dir.display().to_string()));
        }

        // Open files and seek to get their true length, then mmap with that
        // explicit length.
        //
        // On Windows, `File::metadata().len()` (fstat) can transiently return
        // zero for a file that was just renamed into place by
        // `move_staged_files`, because NTFS metadata updates are not always
        // immediately visible — even from the same file handle. Since memmap2
        // internally queries `File::metadata().len()` to determine the mapping
        // size, we bypass it by seeking to the end of the file to get the true
        // length, then passing it explicitly via `MmapOptions::len()`.
        //
        // `SetFilePointerEx` (which backs `file.seek(SeekFrom::End(0))`) reads
        // the file object's size directly from the kernel, which is always
        // up-to-date even when the NTFS directory-entry metadata cache has not
        // yet been invalidated.
        use memmap2::MmapOptions;
        use std::io::{Seek, SeekFrom};

        let open = |name: &str| -> Result<File> {
            match &guard {
                Some(guard) => Ok(guard.directory.open_file(name, false)?),
                None => Ok(File::open(index_dir.join(name))?),
            }
        };
        let mut lookup_file = open(layout.lookup())?;
        let mut postings_file = open(layout.postings())?;

        let lookup_len_u64 = lookup_file.seek(SeekFrom::End(0))?;
        let postings_len_u64 = postings_file.seek(SeekFrom::End(0))?;
        if limits.is_some_and(|limits| {
            limits.lookup != lookup_len_u64 || limits.postings != postings_len_u64
        }) {
            return Err(
                crate::managed::Error::busy("snapshot-size-changed-after-admission").into(),
            );
        }

        if require_complete_sections && ((lookup_len_u64 == 0) != (postings_len_u64 == 0)) {
            return Err(crate::Error::IndexCorrupted(
                "shared base has mismatched empty lookup.bin and index.bin sections".to_string(),
            ));
        }

        let (lookup, postings, num_entries) = if lookup_len_u64 == 0 || postings_len_u64 == 0 {
            (None, None, 0)
        } else {
            // A corrupted lookup.bin whose size is not a multiple of the fixed
            // entry size would cause silent truncation of the trailing entry
            // (and binary search would still see it via integer division).
            // Reject up-front so the failure is loud and obvious.
            //
            // Validate in u64 before narrowing to usize so that oversized files
            // on 32-bit targets are caught before any truncation.
            if !lookup_len_u64.is_multiple_of(LOOKUP_ENTRY_SIZE as u64) {
                return Err(crate::Error::IndexCorrupted(format!(
                    "lookup.bin size {} is not a multiple of {}",
                    lookup_len_u64, LOOKUP_ENTRY_SIZE
                )));
            }
            let lookup_len = usize::try_from(lookup_len_u64).map_err(|_| {
                crate::Error::IndexCorrupted(format!(
                    "lookup.bin size {} does not fit in usize on this platform",
                    lookup_len_u64
                ))
            })?;
            let postings_len = usize::try_from(postings_len_u64).map_err(|_| {
                crate::Error::IndexCorrupted(format!(
                    "index.bin size {} does not fit in usize on this platform",
                    postings_len_u64
                ))
            })?;
            // SAFETY: Files are opened read-only and the Mmap lifetime is tied
            // to IndexReader. The close() method drops the mappings before any
            // file overwrites (required on Windows).
            let lk = unsafe { MmapOptions::new().len(lookup_len).map(&lookup_file)? };
            let pk = unsafe { MmapOptions::new().len(postings_len).map(&postings_file)? };
            let n = lk.len() / LOOKUP_ENTRY_SIZE;
            (Some(lk), Some(pk), n)
        };

        // Load file paths. A truncated files.bin used to be silently accepted,
        // resulting in queries that returned empty file paths for high IDs.
        let files_data = crate::managed::inputs::read_bytes(
            open(layout.files())?,
            limits.map_or(u64::MAX, |limits| limits.files),
            permit,
        )?;
        let file_table_id = crate::meta::file_table_id_controlled(&files_data, permit)?;
        let body = ondisk::file_table_body_for(&files_data, layout)?;
        let file_entries = match permit {
            Some(_) => ondisk::decode_file_entries_controlled(body, permit)?,
            None => ondisk::decode_file_entries(body)?,
        };

        // Validate that file IDs are dense (0..N) with no duplicates.
        // Without this, a corrupted files.bin declaring an id like
        // u32::MAX would cause `vec![String::new(); max_id + 1]` to attempt
        // a multi-GiB allocation and likely OOM/crash. Current writers
        // always assign dense IDs starting at 0, so this is a strict
        // tightening of the format invariant rather than a behavior change.
        let n = file_entries.len();
        let mut seen = vec![false; n];
        for (id, _) in &file_entries {
            if let Some(permit) = permit {
                permit.check()?;
            }
            let idx = *id as usize;
            if idx >= n {
                return Err(crate::Error::IndexCorrupted(format!(
                    "files.bin contains out-of-range file_id {id} (entry count = {n}); \
                     IDs must be dense in 0..{n}"
                )));
            }
            if seen[idx] {
                return Err(crate::Error::IndexCorrupted(format!(
                    "files.bin contains duplicate file_id {id}"
                )));
            }
            seen[idx] = true;
        }
        let mut file_paths = vec![String::new(); n];
        for (id, path) in file_entries {
            if let Some(permit) = permit {
                permit.check()?;
            }
            file_paths[id as usize] = path;
        }
        let path_order = if let Some(permit) = permit {
            let mut ordered = std::collections::BTreeSet::new();
            for (index, path) in file_paths.iter().enumerate() {
                permit.check()?;
                ordered.insert((path.as_str(), index));
            }
            let mut order = Vec::with_capacity(ordered.len());
            for (_, index) in ordered {
                permit.check()?;
                order.push(index);
            }
            order
        } else {
            let mut order: Vec<usize> = (0..file_paths.len()).collect();
            order.sort_unstable_by(|&a, &b| file_paths[a].cmp(&file_paths[b]));
            order
        };

        Ok(Self {
            lookup,
            postings,
            file_paths,
            file_table_id,
            path_order,
            snapshot_file_has_postings: Vec::new(),
            num_entries,
            managed: guard,
            retained: Vec::new(),
        })
    }

    /// An empty reader that returns no results. Useful as a placeholder
    /// when callers need to release the previous mmap before swapping in a
    /// freshly-built reader.
    pub fn empty() -> Self {
        Self {
            lookup: None,
            postings: None,
            file_paths: Vec::new(),
            file_table_id: crate::meta::file_table_id(&[]),
            path_order: Vec::new(),
            snapshot_file_has_postings: Vec::new(),
            num_entries: 0,
            managed: None,
            retained: Vec::new(),
        }
    }

    /// Release mmap handles so the underlying files can be overwritten (Windows).
    pub fn close(&mut self) {
        self.lookup = None;
        self.postings = None;
        self.file_paths = Vec::new();
        self.path_order = Vec::new();
        self.snapshot_file_has_postings = Vec::new();
        self.num_entries = 0;
        self.managed = None;
        self.retained = Vec::new();
    }

    pub(crate) fn retain_memory(&mut self, memory: crate::managed::memory::RetainedMemory) {
        self.retained.push(memory);
    }

    pub fn managed_identity(&self) -> Option<(&crate::managed::Id, &crate::managed::Id)> {
        self.managed
            .as_ref()
            .map(|guard| (&guard.namespace, &guard.id))
    }

    pub(crate) fn managed_guard(&self) -> Option<&Arc<ObjectGuard>> {
        self.managed.as_ref()
    }

    pub fn mapped_bytes(&self) -> u64 {
        self.lookup
            .as_ref()
            .map_or(0, |mapping| mapping.len() as u64)
            + self
                .postings
                .as_ref()
                .map_or(0, |mapping| mapping.len() as u64)
    }

    /// Binary search the lookup table for a trigram hash.
    /// Returns the posting list (file IDs only) or an empty vec if not found.
    pub fn lookup_trigram(&self, trigram: u32) -> Vec<u32> {
        self.lookup_trigram_with_masks(trigram)
            .into_iter()
            .map(|e| e.file_id)
            .collect()
    }

    /// Binary search the lookup table for a trigram hash.
    /// Returns full posting entries with masks.
    pub fn lookup_trigram_with_masks(&self, trigram: u32) -> Vec<PostingEntry> {
        if self.lookup.is_none() {
            return Vec::new();
        }
        let idx = self.binary_search(trigram);
        match idx {
            Some(i) => {
                let entry = self.read_lookup_entry(i);
                self.read_posting_entries(entry.offset, entry.length)
            }
            None => Vec::new(),
        }
    }

    /// Get file path by ID.
    pub fn file_path(&self, file_id: u32) -> Option<&str> {
        self.file_paths.get(file_id as usize).map(|s| s.as_str())
    }

    pub fn contains_path(&self, path: &str) -> bool {
        self.path_order
            .binary_search_by(|&id| self.file_paths[id].as_str().cmp(path))
            .is_ok()
    }

    /// Posting presence from strict snapshot opening; `None` for absent paths
    /// or readers that have not undergone snapshot validation.
    pub(crate) fn snapshot_path_has_postings(&self, path: &str) -> Option<bool> {
        let index = self
            .path_order
            .binary_search_by(|&id| self.file_paths[id].as_str().cmp(path))
            .ok()?;
        self.snapshot_file_has_postings
            .get(self.path_order[index])
            .copied()
    }

    /// Whether the reader contains a path strictly below `directory`.
    pub fn has_descendant_path(&self, directory: &str) -> bool {
        if directory.is_empty() {
            return !self.path_order.is_empty();
        }
        let prefix = directory
            .as_bytes()
            .iter()
            .copied()
            .chain(std::iter::once(b'/'));
        let lower = self.path_order.partition_point(|&id| {
            self.file_paths[id]
                .as_bytes()
                .iter()
                .copied()
                .cmp(prefix.clone())
                .is_lt()
        });
        self.path_order.get(lower).is_some_and(|&id| {
            self.file_paths[id]
                .strip_prefix(directory)
                .is_some_and(|suffix| suffix.starts_with('/'))
        })
    }

    /// Total number of indexed files.
    pub fn num_files(&self) -> usize {
        self.file_paths.len()
    }

    pub fn file_table_id(&self) -> crate::meta::FileTableId {
        self.file_table_id
    }

    /// Identity of the path table, lookup table and postings, independent of
    /// their storage directory. Computed once when opening a shared base.
    pub(crate) fn snapshot_id(&self) -> [u8; 32] {
        self.snapshot_id_controlled(None)
            .expect("uncontrolled fingerprint has no work-budget failure")
    }

    pub(crate) fn snapshot_id_controlled(
        &self,
        permit: Option<&Arc<WorkPermit>>,
    ) -> Result<[u8; 32]> {
        let mut hasher = blake3::Hasher::new();
        hasher.update(b"tgrep/shared-base/v1\0");
        hasher.update(&self.file_table_id);
        for bytes in [
            self.lookup.as_deref().unwrap_or_default(),
            self.postings.as_deref().unwrap_or_default(),
        ] {
            hasher.update(&(bytes.len() as u64).to_le_bytes());
            if let Some(permit) = permit {
                for chunk in bytes.chunks(64 * 1024) {
                    permit.check()?;
                    hasher.update(chunk);
                }
            } else {
                hasher.update(bytes);
            }
        }
        Ok(*hasher.finalize().as_bytes())
    }

    /// Total number of unique trigrams.
    pub fn num_trigrams(&self) -> usize {
        self.num_entries
    }

    /// Returns `true` when the reader state is structurally inconsistent.
    ///
    /// A well-formed index may legitimately contain files that produce no
    /// trigrams (for example, files shorter than 3 bytes), so
    /// `num_files() > 0 && num_trigrams() == 0` is not inherently
    /// degenerate. The zero-trigram case is only suspicious when one of the
    /// mmap-backed binary sections is nevertheless present and non-empty,
    /// indicating that the in-memory counters and on-disk metadata disagree
    /// (observed on Windows NTFS after rapid file renames when stale
    /// metadata causes a zero-length mmap despite non-empty files on disk).
    ///
    /// Note: because `open()` derives `num_entries` directly from the
    /// lookup mmap length, this condition cannot occur through normal
    /// construction — it represents a post-construction inconsistency
    /// (e.g. partial `close()` or direct field mutation). Call sites in
    /// `serve.rs` that need to detect the "files present, trigrams missing"
    /// Windows stale-metadata heuristic should compare `num_files()` vs
    /// `num_trigrams()` independently rather than relying solely on this
    /// method.
    pub fn is_degenerate(&self) -> bool {
        self.num_entries == 0
            && (self.lookup.as_ref().is_some_and(|m| !m.is_empty())
                || self.postings.as_ref().is_some_and(|m| !m.is_empty()))
    }

    /// Validate that the lookup table is sorted by trigram hash and that
    /// posting-list ranges stay within `index.bin` bounds.
    ///
    /// Returns `Ok(())` when the table is well-formed. As a side-effect, this
    /// sequentially reads every lookup entry, warming the mmap pages into the
    /// OS page cache so that subsequent binary searches never hit cold pages.
    pub fn validate_lookup(&self) -> std::result::Result<(), String> {
        self.validate_lookup_controlled(None)
            .map_err(|error| match error {
                crate::Error::IndexCorrupted(detail) => detail,
                error => error.to_string(),
            })
    }

    fn validate_lookup_controlled(&self, permit: Option<&Arc<WorkPermit>>) -> Result<()> {
        let lookup = match self.lookup.as_ref() {
            Some(l) => l,
            None => return Ok(()), // empty index, nothing to validate
        };
        let postings_len = self.postings.as_ref().map_or(0, |p| p.len());
        let mut prev_trigram: Option<u32> = None;
        for i in 0..self.num_entries {
            if i.is_multiple_of(4096)
                && let Some(permit) = permit
            {
                permit.check()?;
            }
            let entry = self.read_lookup_entry(i);
            if let Some(prev) = prev_trigram
                && entry.trigram <= prev
            {
                return Err(crate::Error::IndexCorrupted(format!(
                    "lookup.bin not sorted at entry {i}: trigram {:#x} <= prev {:#x}",
                    entry.trigram, prev
                )));
            }
            // Perform range math in u64 to avoid truncation on 32-bit targets
            // or corrupted indexes with large offsets.
            let postings_len_u64 = postings_len as u64;
            let byte_len = (entry.length as u64).checked_mul(POSTING_ENTRY_SIZE as u64);
            let end = byte_len.and_then(|bl| entry.offset.checked_add(bl));
            match end {
                Some(e) if e <= postings_len_u64 => {}
                _ => {
                    return Err(crate::Error::IndexCorrupted(format!(
                        "lookup entry {i} (trigram {:#x}): posting range \
                         [offset={}, length={}] exceeds index.bin length {postings_len}",
                        entry.trigram, entry.offset, entry.length
                    )));
                }
            }
            prev_trigram = Some(entry.trigram);
        }
        // Touch last byte of lookup to ensure the final page is paged in.
        if !lookup.is_empty() {
            std::hint::black_box(lookup[lookup.len() - 1]);
        }
        Ok(())
    }

    /// Get all file IDs present in this reader.
    pub fn all_file_ids(&self) -> Vec<u32> {
        (0..self.file_paths.len() as u32).collect()
    }

    /// Get all file paths in this reader (for skip-set construction).
    pub fn all_paths(&self) -> &[String] {
        &self.file_paths
    }

    /// Iterate all trigram entries in the lookup table.
    /// Returns (trigram_hash, posting_list) for each entry.
    pub fn all_trigram_postings(&self) -> Vec<(u32, Vec<u32>)> {
        let mut result = Vec::with_capacity(self.num_entries);
        for i in 0..self.num_entries {
            let entry = self.read_lookup_entry(i);
            let postings = self.read_posting_entries(entry.offset, entry.length);
            let file_ids: Vec<u32> = postings.into_iter().map(|e| e.file_id).collect();
            result.push((entry.trigram, file_ids));
        }
        result
    }

    /// Decode the `i`-th trigram entry (ascending trigram order) with its full
    /// posting list, including masks.
    ///
    /// Paired with [`Self::num_trigrams`] this lets a caller drive the decode
    /// itself — across threads, and fused with its own per-entry transform, so
    /// the whole index never has to be materialised on the heap just to be
    /// walked once. That matters: a 94k-file tree carries ~170M posting
    /// entries, so collecting them all first costs both the allocation and a
    /// second copy in whatever the caller builds next.
    pub fn trigram_posting_at(&self, i: usize) -> (u32, Vec<PostingEntry>) {
        let entry = self.read_lookup_entry(i);
        (
            entry.trigram,
            self.read_posting_entries(entry.offset, entry.length),
        )
    }

    /// Iterate all trigram entries with full posting data (including masks).
    /// Returns (trigram_hash, Vec<PostingEntry>) preserving loc_mask/next_mask.
    pub fn all_trigram_postings_with_masks(&self) -> Vec<(u32, Vec<PostingEntry>)> {
        (0..self.num_entries)
            .map(|i| self.trigram_posting_at(i))
            .collect()
    }

    fn binary_search(&self, trigram: u32) -> Option<usize> {
        let mut lo = 0usize;
        let mut hi = self.num_entries;
        while lo < hi {
            let mid = lo + (hi - lo) / 2;
            let entry = self.read_lookup_entry(mid);
            match entry.trigram.cmp(&trigram) {
                std::cmp::Ordering::Equal => return Some(mid),
                std::cmp::Ordering::Less => lo = mid + 1,
                std::cmp::Ordering::Greater => hi = mid,
            }
        }
        None
    }

    /// Return the `i`-th trigram (in ascending sorted order) together with the
    /// raw, on-disk posting bytes for that trigram. Zero-copy: the returned
    /// slice points directly into the mmap, so callers can copy the bytes
    /// verbatim into a new index without decoding them into heap.
    ///
    /// Used by the streaming append-merge in the builder to keep the existing
    /// on-disk postings out of heap while merging a live overlay into a new
    /// index. Returns `None` if `i` is out of range or the postings mmap is
    /// absent/truncated for the entry.
    pub fn nth_trigram_raw(&self, i: usize) -> Option<(u32, &[u8])> {
        if i >= self.num_entries {
            return None;
        }
        let entry = self.read_lookup_entry(i);
        let postings = self.postings.as_ref()?;
        // Do the range math in u64 and validate against the mmap length before
        // narrowing to usize, so a large/corrupt offset can't truncate on
        // 32-bit targets and yield an in-bounds slice from the wrong region.
        let start = entry.offset;
        let byte_len = (entry.length as u64).checked_mul(POSTING_ENTRY_SIZE as u64)?;
        let end = start.checked_add(byte_len)?;
        // Guard both ends against the mmap length. `end >= start` holds because
        // `byte_len` is unsigned and `checked_add` rejects overflow, but check
        // `start` explicitly so a zero-length entry with an out-of-range offset
        // can never reach the slice below.
        let len = postings.len() as u64;
        if start > len || end > len {
            return None;
        }
        let start = usize::try_from(start).ok()?;
        let end = usize::try_from(end).ok()?;
        Some((entry.trigram, &postings[start..end]))
    }

    fn read_lookup_entry(&self, index: usize) -> LookupEntry {
        let lookup = self.lookup.as_ref().unwrap();
        let start = index * LOOKUP_ENTRY_SIZE;
        let buf: &[u8; LOOKUP_ENTRY_SIZE] =
            lookup[start..start + LOOKUP_ENTRY_SIZE].try_into().unwrap();
        LookupEntry::decode(buf)
    }

    /// Decode the posting entries a lookup entry points at.
    ///
    /// `offset` and `length` are read verbatim out of `lookup.bin`, so on a
    /// corrupt or truncated index they are arbitrary and must not be trusted
    /// to describe a range that exists. Two invariants are enforced here:
    ///
    /// * The range is validated against the mmap length *before* `offset` is
    ///   narrowed to `usize`. Adding to a `usize` first and testing
    ///   `pos + POSTING_ENTRY_SIZE <= postings.len()` is not merely incomplete,
    ///   it is inverted: the sum wraps, so the further past the end `offset`
    ///   sits, the smaller the wrapped sum and the more likely the guard is to
    ///   accept it (`offset = u64::MAX` wraps to `POSTING_ENTRY_SIZE - 1` and
    ///   then slices out of range). It also truncates rather than wraps on
    ///   32-bit targets, which can fold an out-of-range offset back into the
    ///   mapping and decode the wrong region.
    /// * The trip count and the reserved capacity come from how many entries
    ///   the postings mmap actually holds, never from `length`. Otherwise a
    ///   corrupt `length` of `u32::MAX` reserves ~25 GiB and spins through
    ///   4.29 billion iterations to produce nothing, even against a 60-byte
    ///   `index.bin`.
    ///
    /// Entries past the end of the mapping are dropped, which preserves the
    /// existing best-effort behaviour for a truncated index: this is the hot
    /// query path and has no error channel. Callers that want corruption
    /// surfaced as [`crate::Error::IndexCorrupted`] should run
    /// [`Self::validate_lookup`] first, as `HybridIndex::open` and the server's
    /// reader swap already do.
    fn read_posting_entries(&self, offset: u64, length: u32) -> Vec<PostingEntry> {
        let postings = match self.postings.as_ref() {
            Some(p) => p,
            None => return Vec::new(),
        };
        // Narrow only after the mmap length has vetted the value, so an offset
        // wider than `usize` can never truncate into range on a 32-bit target.
        let Ok(start) = usize::try_from(offset) else {
            return Vec::new();
        };
        // `None` when `start` is past the end of the mapping — no entries.
        let Some(remaining) = postings.len().checked_sub(start) else {
            return Vec::new();
        };
        let count = (length as usize).min(remaining / POSTING_ENTRY_SIZE);
        let mut result = Vec::with_capacity(count);
        for i in 0..count {
            // `count * POSTING_ENTRY_SIZE <= remaining` and
            // `start + remaining == postings.len()`, so both `start + i * SIZE`
            // and its `+ SIZE` end stay within the mapping without overflow.
            let pos = start + i * POSTING_ENTRY_SIZE;
            let buf: &[u8; POSTING_ENTRY_SIZE] =
                postings[pos..pos + POSTING_ENTRY_SIZE].try_into().unwrap();
            result.push(PostingEntry::decode(buf));
        }
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::TempDir;

    /// Write a minimal trio of index files so `IndexReader::open` runs the
    /// validation paths we want to exercise.
    fn write_index(dir: &Path, lookup_bytes: &[u8], postings_bytes: &[u8], files_bytes: &[u8]) {
        std::fs::create_dir_all(dir).unwrap();
        let mut f = std::fs::File::create(dir.join("lookup.bin")).unwrap();
        f.write_all(lookup_bytes).unwrap();
        let mut f = std::fs::File::create(dir.join("index.bin")).unwrap();
        f.write_all(postings_bytes).unwrap();
        let mut f = std::fs::File::create(dir.join("files.bin")).unwrap();
        f.write_all(files_bytes).unwrap();
    }

    fn open_err(dir: &Path) -> crate::Error {
        match IndexReader::open(dir) {
            Ok(_) => panic!("expected IndexReader::open to fail"),
            Err(e) => e,
        }
    }

    #[test]
    fn open_rejects_lookup_with_non_multiple_size() {
        let tmp = TempDir::new().unwrap();
        // 1 byte short of a single LOOKUP_ENTRY_SIZE-sized record.
        let lookup = vec![0u8; LOOKUP_ENTRY_SIZE - 1];
        // postings non-empty so we get past the `len() == 0` short-circuit.
        let postings = vec![0u8; POSTING_ENTRY_SIZE];
        write_index(tmp.path(), &lookup, &postings, &[]);
        match open_err(tmp.path()) {
            crate::Error::IndexCorrupted(msg) => {
                assert!(
                    msg.contains("lookup.bin"),
                    "expected lookup.bin diagnostic, got: {msg}"
                );
            }
            other => panic!("expected IndexCorrupted, got {other:?}"),
        }
    }

    #[test]
    fn open_accepts_empty_index() {
        // Both lookup.bin and postings.bin are zero-length: legitimate case
        // for a freshly-created server with no files indexed yet.
        let tmp = TempDir::new().unwrap();
        write_index(tmp.path(), &[], &[], &[]);
        let reader = IndexReader::open(tmp.path()).expect("empty index should open");
        assert_eq!(reader.num_entries, 0);
        assert!(reader.file_paths.is_empty());
    }

    #[test]
    fn open_rejects_files_with_out_of_range_id() {
        let tmp = TempDir::new().unwrap();
        // Single record whose declared file_id (5) is past entry count (1).
        // Without the dense-id check this would attempt to allocate a
        // `Vec<String>` of size 6 for a single entry — and a u32::MAX id
        // would attempt a multi-GiB allocation.
        let entry = ondisk::encode_file_entry(5, "a.rs").unwrap();
        write_index(tmp.path(), &[], &[], &entry);
        match open_err(tmp.path()) {
            crate::Error::IndexCorrupted(msg) => assert!(msg.contains("out-of-range")),
            other => panic!("expected IndexCorrupted, got {other:?}"),
        }
    }

    #[test]
    fn open_rejects_files_with_duplicate_id() {
        let tmp = TempDir::new().unwrap();
        let mut buf = ondisk::encode_file_entry(0, "a.rs").unwrap();
        buf.extend_from_slice(&ondisk::encode_file_entry(0, "b.rs").unwrap());
        write_index(tmp.path(), &[], &[], &buf);
        match open_err(tmp.path()) {
            crate::Error::IndexCorrupted(msg) => assert!(msg.contains("duplicate")),
            other => panic!("expected IndexCorrupted, got {other:?}"),
        }
    }

    #[test]
    fn open_accepts_dense_files_table() {
        let tmp = TempDir::new().unwrap();
        let mut buf = ondisk::encode_file_entry(0, "a.rs").unwrap();
        buf.extend_from_slice(&ondisk::encode_file_entry(1, "b.rs").unwrap());
        buf.extend_from_slice(&ondisk::encode_file_entry(2, "c.rs").unwrap());
        write_index(tmp.path(), &[], &[], &buf);
        let reader = IndexReader::open(tmp.path()).expect("dense IDs should be accepted");
        assert_eq!(reader.file_paths.len(), 3);
        assert_eq!(reader.file_paths[0], "a.rs");
        assert_eq!(reader.file_paths[1], "b.rs");
        assert_eq!(reader.file_paths[2], "c.rs");
    }

    #[test]
    fn descendant_lookup_is_sorted_and_directory_boundary_aware() {
        let tmp = TempDir::new().unwrap();
        let mut files = ondisk::encode_file_entry(0, "elsewhere.rs").unwrap();
        files.extend_from_slice(&ondisk::encode_file_entry(1, "src/deep/a.rs").unwrap());
        files.extend_from_slice(&ondisk::encode_file_entry(2, "src2/not-a-child.rs").unwrap());
        write_index(tmp.path(), &[], &[], &files);
        let reader = IndexReader::open(tmp.path()).unwrap();

        assert!(reader.has_descendant_path("src"));
        assert!(reader.has_descendant_path("src/deep"));
        assert!(!reader.has_descendant_path("sr"));
        assert!(!reader.has_descendant_path("src2/not-a-child.rs"));
    }

    #[test]
    fn is_degenerate_detects_mmap_counter_disagreement() {
        let tmp = TempDir::new().unwrap();
        let (lookup, postings) = make_sorted_index(&[0x616263]);
        let files = ondisk::encode_file_entry(0, "a.rs").unwrap();

        // Files present but empty lookup/postings is valid (files <3 bytes)
        write_index(tmp.path(), &[], &[], &files);
        let reader = IndexReader::open(tmp.path()).expect("should open");
        assert!(
            !reader.is_degenerate(),
            "files with empty sections is valid, not degenerate"
        );

        // Non-empty sections with matching entries IS also not degenerate
        let tmp2 = TempDir::new().unwrap();
        write_index(tmp2.path(), &lookup, &postings, &files);
        let reader2 = IndexReader::open(tmp2.path()).expect("should open");
        assert!(
            !reader2.is_degenerate(),
            "well-formed index is not degenerate"
        );

        // Fabricate the inconsistent internal state: mmap-backed
        // lookup/postings are present, but num_entries is forced to 0.
        // This simulates a post-construction inconsistency.
        let tmp3 = TempDir::new().unwrap();
        write_index(tmp3.path(), &lookup, &postings, &files);
        let opened = IndexReader::open(tmp3.path()).expect("should open");
        assert!(
            opened.lookup.as_ref().map_or(0, |m| m.len()) >= LOOKUP_ENTRY_SIZE,
            "fixture should have a non-empty lookup mmap"
        );
        let degenerate_reader = IndexReader {
            lookup: opened.lookup,
            postings: opened.postings,
            file_paths: opened.file_paths,
            file_table_id: opened.file_table_id,
            path_order: opened.path_order,
            snapshot_file_has_postings: opened.snapshot_file_has_postings,
            num_entries: 0,
            managed: opened.managed,
            retained: opened.retained,
        };
        assert!(
            degenerate_reader.is_degenerate(),
            "non-empty mmap with num_entries == 0 must be degenerate"
        );
    }

    #[test]
    fn is_degenerate_false_for_empty_index() {
        let tmp = TempDir::new().unwrap();
        write_index(tmp.path(), &[], &[], &[]);
        let reader = IndexReader::open(tmp.path()).expect("should open");
        assert!(!reader.is_degenerate(), "empty index is not degenerate");
    }

    /// Build a well-formed lookup + postings for testing validate_lookup.
    fn make_sorted_index(trigrams: &[u32]) -> (Vec<u8>, Vec<u8>) {
        let mut lookup_buf = Vec::new();
        let mut postings_buf = Vec::new();
        for &tri in trigrams {
            let offset = postings_buf.len() as u64;
            // One posting entry per trigram for simplicity
            let pe = PostingEntry {
                file_id: 0,
                loc_mask: 0xFF,
                next_mask: 0xFF,
            };
            postings_buf.extend_from_slice(&pe.encode());
            let le = LookupEntry {
                trigram: tri,
                offset,
                length: 1,
            };
            lookup_buf.extend_from_slice(&le.encode());
        }
        (lookup_buf, postings_buf)
    }

    #[test]
    fn validate_lookup_accepts_sorted_table() {
        let tmp = TempDir::new().unwrap();
        let (lookup, postings) = make_sorted_index(&[100, 200, 300]);
        let files = ondisk::encode_file_entry(0, "a.rs").unwrap();
        write_index(tmp.path(), &lookup, &postings, &files);
        let reader = IndexReader::open(tmp.path()).unwrap();
        assert!(reader.validate_lookup().is_ok());
    }

    #[test]
    fn validate_lookup_rejects_unsorted_table() {
        let tmp = TempDir::new().unwrap();
        let (lookup, postings) = make_sorted_index(&[200, 100, 300]); // unsorted!
        let files = ondisk::encode_file_entry(0, "a.rs").unwrap();
        write_index(tmp.path(), &lookup, &postings, &files);
        let reader = IndexReader::open(tmp.path()).unwrap();
        let err = reader.validate_lookup().unwrap_err();
        assert!(
            err.contains("not sorted"),
            "expected sort error, got: {err}"
        );
    }

    #[test]
    fn validate_lookup_rejects_out_of_bounds_postings() {
        let tmp = TempDir::new().unwrap();
        // Create lookup that points past the end of postings
        let le = LookupEntry {
            trigram: 100,
            offset: 0,
            length: 999, // way past the single entry we provide
        };
        let mut lookup = Vec::new();
        lookup.extend_from_slice(&le.encode());
        let pe = PostingEntry {
            file_id: 0,
            loc_mask: 0xFF,
            next_mask: 0xFF,
        };
        let mut postings = Vec::new();
        postings.extend_from_slice(&pe.encode());
        let files = ondisk::encode_file_entry(0, "a.rs").unwrap();
        write_index(tmp.path(), &lookup, &postings, &files);
        let reader = IndexReader::open(tmp.path()).unwrap();
        let err = reader.validate_lookup().unwrap_err();
        assert!(err.contains("exceeds"), "expected bounds error, got: {err}");
    }

    #[test]
    fn validate_lookup_empty_is_ok() {
        let tmp = TempDir::new().unwrap();
        write_index(tmp.path(), &[], &[], &[]);
        let reader = IndexReader::open(tmp.path()).unwrap();
        assert!(reader.validate_lookup().is_ok());
    }

    /// `n` posting entries with `file_id` 0..n so decoded content is checkable.
    fn make_postings(n: u32) -> Vec<u8> {
        let mut buf = Vec::new();
        for file_id in 0..n {
            buf.extend_from_slice(
                &PostingEntry {
                    file_id,
                    loc_mask: 0xFF,
                    next_mask: 0xFF,
                }
                .encode(),
            );
        }
        buf
    }

    /// A single-entry `lookup.bin` pointing at an arbitrary (possibly corrupt)
    /// posting range, so the reader's trust in `offset`/`length` can be probed
    /// through the public API.
    fn open_with_lookup(dir: &Path, trigram: u32, offset: u64, length: u32, postings: &[u8]) {
        let lookup = LookupEntry {
            trigram,
            offset,
            length,
        }
        .encode();
        let files = ondisk::encode_file_entry(0, "a.rs").unwrap();
        write_index(dir, &lookup, postings, &files);
    }

    #[test]
    fn lookup_survives_offset_that_overflows_the_bounds_check() {
        // `offset = u64::MAX` used to wrap `pos + POSTING_ENTRY_SIZE` around to
        // a small value that passed the guard, then slice far out of range:
        // "attempt to add with overflow" in debug, an out-of-range slice panic
        // in release.
        let tmp = TempDir::new().unwrap();
        open_with_lookup(tmp.path(), 1, u64::MAX, 5, &make_postings(10));
        let reader = IndexReader::open(tmp.path()).unwrap();
        assert!(reader.lookup_trigram_with_masks(1).is_empty());
        // Every offset in the top of the u64 range must be rejected, not just
        // the one that happens to wrap to zero.
        for offset in [u64::MAX, u64::MAX - 1, u64::MAX - 5, u64::MAX / 2] {
            let tmp = TempDir::new().unwrap();
            open_with_lookup(tmp.path(), 1, offset, 5, &make_postings(10));
            let reader = IndexReader::open(tmp.path()).unwrap();
            assert!(
                reader.lookup_trigram_with_masks(1).is_empty(),
                "offset {offset} must decode to nothing"
            );
        }
    }

    #[test]
    fn lookup_bounds_work_by_postings_len_not_declared_length() {
        // `length = u32::MAX` used to reserve ~25 GiB and iterate 4.29 billion
        // times against a 60-byte index.bin (~1.65 s release, ~55 s debug).
        // Both the trip count and the reservation must derive from the mapping.
        let tmp = TempDir::new().unwrap();
        open_with_lookup(tmp.path(), 1, 0, u32::MAX, &make_postings(10));
        let reader = IndexReader::open(tmp.path()).unwrap();

        let started = std::time::Instant::now();
        let entries = reader.lookup_trigram_with_masks(1);
        let elapsed = started.elapsed();

        assert_eq!(entries.len(), 10, "only the 10 entries on disk exist");
        assert!(
            entries.capacity() < 1_000,
            "capacity {} must be bounded by index.bin, not by `length`",
            entries.capacity()
        );
        assert!(
            elapsed < std::time::Duration::from_secs(10),
            "decoding 10 entries took {elapsed:?}; work is scaling with `length`"
        );
    }

    #[test]
    fn lookup_with_offset_past_end_returns_empty() {
        let postings = make_postings(10);
        for offset in [postings.len() as u64, postings.len() as u64 + 1, 4096] {
            let tmp = TempDir::new().unwrap();
            open_with_lookup(tmp.path(), 1, offset, 5, &postings);
            let reader = IndexReader::open(tmp.path()).unwrap();
            assert!(
                reader.lookup_trigram_with_masks(1).is_empty(),
                "offset {offset} is not inside index.bin"
            );
        }
    }

    #[test]
    fn lookup_clamps_length_to_the_entries_that_fit() {
        // Truncated index.bin: the lookup entry claims 10 postings but only
        // 4 whole entries follow the offset. Decode the 4, drop the rest.
        let tmp = TempDir::new().unwrap();
        let postings = make_postings(6);
        open_with_lookup(tmp.path(), 1, 2 * POSTING_ENTRY_SIZE as u64, 10, &postings);
        let reader = IndexReader::open(tmp.path()).unwrap();
        let ids: Vec<u32> = reader
            .lookup_trigram_with_masks(1)
            .into_iter()
            .map(|e| e.file_id)
            .collect();
        assert_eq!(ids, vec![2, 3, 4, 5]);
    }

    #[test]
    fn lookup_with_offset_inside_a_partial_trailing_entry_returns_empty() {
        // Offset lands 1 byte into the last entry, so no whole entry remains.
        let tmp = TempDir::new().unwrap();
        let postings = make_postings(2);
        let offset = postings.len() as u64 - (POSTING_ENTRY_SIZE as u64 - 1);
        open_with_lookup(tmp.path(), 1, offset, 4, &postings);
        let reader = IndexReader::open(tmp.path()).unwrap();
        assert!(reader.lookup_trigram_with_masks(1).is_empty());
    }

    #[test]
    fn lookup_still_returns_every_entry_of_a_well_formed_range() {
        let tmp = TempDir::new().unwrap();
        let postings = make_postings(10);
        open_with_lookup(tmp.path(), 1, 0, 10, &postings);
        let reader = IndexReader::open(tmp.path()).unwrap();
        let entries = reader.lookup_trigram_with_masks(1);
        let ids: Vec<u32> = entries.iter().map(|e| e.file_id).collect();
        assert_eq!(ids, (0..10).collect::<Vec<u32>>());
        assert!(
            entries
                .iter()
                .all(|e| e.loc_mask == 0xFF && e.next_mask == 0xFF)
        );
    }

    #[test]
    fn validate_lookup_reports_offset_that_overflows_the_range_math() {
        // The loud-error counterpart: callers that validate up front (as
        // `HybridIndex::open` does) get `IndexCorrupted` for the same entry
        // the query path silently skips.
        let tmp = TempDir::new().unwrap();
        open_with_lookup(tmp.path(), 1, u64::MAX, 5, &make_postings(10));
        let reader = IndexReader::open(tmp.path()).unwrap();
        let err = reader.validate_lookup().unwrap_err();
        assert!(err.contains("exceeds"), "expected bounds error, got: {err}");
    }
}
