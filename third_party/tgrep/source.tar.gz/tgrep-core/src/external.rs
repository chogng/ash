//! External merge sort for bootstrap index construction.
//!
//! The default in-memory builder accumulates one [`TrigramPosting`] (12 bytes)
//! for every (trigram, file) pair in the repository, then sorts the whole thing
//! at once. That vector is unbounded: a monorepo with ~500K files averaging a
//! few thousand distinct trigrams each needs well over 10 GB of heap before the
//! first byte is written.
//!
//! This module bounds peak heap to a fixed arena instead:
//!
//! 1. Postings accumulate in an arena sized by a byte budget.
//! 2. When the arena fills it is sorted, delta+varint encoded, and spilled to a
//!    segment file on disk; the arena's allocation is then reused.
//! 3. [`ExternalSorter::write_postings`] streams a k-way merge of the segments
//!    straight into `index.bin` / `lookup.bin`.
//!
//! Peak heap is `max(arena, merge read buffers) + largest posting list`,
//! independent of repository size. The merge shares one read-ahead budget
//! across all open segments rather than giving each a fixed buffer, so peak
//! stays tied to the caller's budget instead of growing with fan-in.
//!
//! Total sort work is unchanged: `k` sorts of `n/k` elements plus an `n·log k`
//! merge is still `O(n·log n)`, with better cache locality per sort. The added
//! cost is one spill write plus one merge read, and the segment encoding
//! roughly halves those bytes relative to the 6-byte on-disk posting layout.
//!
//! If the arena never fills — small and mid-size repositories — nothing is
//! spilled and `write_postings` degrades to exactly the in-memory path: one
//! sort followed by one streaming write.

use std::cmp::Reverse;
use std::collections::BinaryHeap;
use std::fs::File;
use std::io::{BufWriter, Read, Write};
use std::path::{Path, PathBuf};

use crate::ondisk::{
    self, LOOKUP_WRITE_CHUNK_ENTRIES, LookupEntry, POSTING_WRITE_CHUNK_ENTRIES, PostingEntry,
    flush_lookup_entries, write_lookup_entry, write_posting_entries,
};
use crate::{Error, Result};

/// A single (trigram, posting) pair prior to grouping.
#[derive(Clone, Copy)]
pub(crate) struct TrigramPosting {
    pub trigram: u32,
    pub entry: PostingEntry,
}

/// Default arena budget before spilling. Chosen so a spill segment is large
/// enough to amortize sequential write cost while keeping the merge fan-in
/// modest even for very large repositories.
pub const DEFAULT_BUFFER_BYTES: usize = 64 * 1024 * 1024;

/// Read-ahead buffer held per open segment during the merge, when fan-in is
/// low enough to afford it.
const SEGMENT_BUFFER_BYTES: usize = 256 * 1024;

/// Floor on a per-segment read buffer. Only `MAX_VARINT_LEN` bytes are ever
/// required for correctness; this is purely to keep the read syscall count
/// reasonable at high fan-in.
const MIN_SEGMENT_BUFFER_BYTES: usize = 4 * 1024;

/// Longest possible LEB128 encoding of a `u64`.
const MAX_VARINT_LEN: usize = 10;

/// Flush threshold for the encode scratch buffer while spilling a segment.
const SPILL_SCRATCH_FLUSH_BYTES: usize = 128 * 1024;

fn write_varint(buf: &mut Vec<u8>, mut value: u64) {
    while value >= 0x80 {
        buf.push((value as u8) | 0x80);
        value >>= 7;
    }
    buf.push(value as u8);
}

/// Temporary directory holding spill segments, removed on drop.
///
/// Segments are written next to the index rather than under the system temp
/// directory: they can total gigabytes for a large repository, and `TEMP` is
/// frequently on a smaller (or differently quota'd) volume than the workspace.
///
/// The name carries both the process ID and a per-process sequence number.
/// The PID separates concurrent processes; the sequence separates concurrent
/// sorters *within* a process. Without the latter, two sorters sharing an
/// `index_dir` would write the same `seg-NNNNN.bin` names into the same
/// directory, and each would merge whatever the other last wrote there —
/// silently, because a foreign segment is still a structurally valid segment.
struct SpillDir {
    path: PathBuf,
    managed: Option<crate::output::Output>,
}

/// Distinguishes spill directories created by different sorters in this
/// process. Only uniqueness matters, so `Relaxed` is sufficient.
static SPILL_SEQUENCE: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

impl SpillDir {
    fn create(index_dir: &Path) -> Result<Self> {
        Self::create_with_sequence(index_dir, &SPILL_SEQUENCE)
    }

    fn create_with_sequence(
        index_dir: &Path,
        sequence: &std::sync::atomic::AtomicU64,
    ) -> Result<Self> {
        std::fs::create_dir_all(index_dir)?;
        loop {
            let seq = sequence.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            let path = index_dir.join(format!("spill-{}-{seq}.tmp", std::process::id()));
            // A recycled PID can collide with output that startup cleanup could
            // not remove. Never reuse it or force-unlink a retained reader.
            match std::fs::create_dir(&path) {
                Ok(()) => {
                    return Ok(Self {
                        path,
                        managed: None,
                    });
                }
                Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {}
                Err(error) => return Err(error.into()),
            }
        }
    }

    fn for_output(output: &crate::output::Output) -> Result<Self> {
        match output.spill()? {
            Some(managed) => Ok(Self {
                path: managed.path().to_path_buf(),
                managed: Some(managed),
            }),
            None => Self::create(output.path()),
        }
    }

    fn output(&self) -> crate::output::Output {
        self.managed
            .clone()
            .unwrap_or_else(|| crate::output::Output::legacy(&self.path))
    }
}

impl Drop for SpillDir {
    fn drop(&mut self) {
        if self.managed.is_none() {
            let _ = std::fs::remove_dir_all(&self.path);
        }
    }
}

/// Accumulates postings, spilling sorted segments to disk when the arena fills.
pub(crate) struct ExternalSorter {
    arena: Vec<TrigramPosting>,
    /// Arena length that triggers a spill.
    capacity: usize,
    /// Caller's byte budget. Bounds the arena while accumulating, then the
    /// shared segment read-ahead while merging.
    budget_bytes: usize,
    spill: Option<SpillDir>,
    segments: Vec<PathBuf>,
    output: crate::output::Output,
    scratch: Vec<u8>,
    segment_memory: Option<crate::managed::work::MemoryCharge>,
}

impl ExternalSorter {
    /// Create a sorter that keeps at most `budget_bytes` of postings in heap.
    pub(crate) fn new(index_dir: &Path, budget_bytes: usize) -> Self {
        let entry_size = std::mem::size_of::<TrigramPosting>();
        // Always allow at least a small arena so a pathological budget can't
        // produce a zero-capacity arena that spills on every single posting.
        let capacity = (budget_bytes / entry_size).max(1024);
        Self {
            // Allocate the arena once, exactly. Letting `Vec` grow it would
            // overshoot the budget: for the 64 MB default it doubles past the
            // target and reserves 96 MB, half again the bound this type exists
            // to enforce. Reserving up front also avoids repeatedly copying a
            // multi-megabyte buffer while filling.
            arena: Vec::with_capacity(capacity),
            capacity,
            budget_bytes,
            spill: None,
            segments: Vec::new(),
            output: crate::output::Output::legacy(index_dir),
            scratch: Vec::new(),
            segment_memory: None,
        }
    }

    pub(crate) fn with_output(output: crate::output::Output, budget_bytes: usize) -> Self {
        let mut sorter = Self::new(output.path(), budget_bytes);
        sorter.output = output;
        sorter
    }

    /// Number of segments spilled so far, excluding the arena tail that
    /// `write_postings` spills last. Callers that want the merged total should
    /// use the count returned by `write_postings`.
    #[cfg(test)]
    pub(crate) fn spilled_segments(&self) -> usize {
        self.segments.len()
    }

    /// Append one posting, spilling first if the arena is full.
    pub(crate) fn push(&mut self, posting: TrigramPosting) -> Result<()> {
        if self.arena.len().is_multiple_of(4096) {
            self.output.check()?;
        }
        if self.arena.len() >= self.capacity {
            self.spill_arena()?;
        }
        self.arena.push(posting);
        Ok(())
    }

    /// Append every posting a file contributed.
    pub(crate) fn push_file<I>(&mut self, file_id: u32, per_trigram: I) -> Result<()>
    where
        I: IntoIterator<Item = (u32, crate::trigram::TrigramMasks)>,
    {
        for (trigram, masks) in per_trigram {
            self.push(TrigramPosting {
                trigram,
                entry: PostingEntry {
                    file_id,
                    loc_mask: masks.loc_mask,
                    next_mask: masks.next_mask,
                },
            })?;
        }
        Ok(())
    }

    fn sort_arena(&mut self) -> Result<()> {
        sort_controlled(
            &mut self.arena,
            |entry| (entry.trigram, entry.entry.file_id),
            &self.output,
        )
    }

    /// Sort the arena and write it out as a compact segment, then clear it.
    ///
    /// The arena's backing allocation is deliberately retained (`clear`, not
    /// `drop`) so steady-state indexing performs no further large allocations.
    fn spill_arena(&mut self) -> Result<()> {
        self.output.check()?;
        if self.arena.is_empty() {
            return Ok(());
        }
        self.sort_arena()?;

        let spill = match &self.spill {
            Some(dir) => dir,
            None => {
                self.spill = Some(SpillDir::for_output(&self.output)?);
                self.spill.as_ref().unwrap()
            }
        };
        let name = format!("seg-{:05}.bin", self.segments.len());
        let path = spill.path.join(&name);
        if let Some(permit) = self.output.control() {
            let memory = match &mut self.segment_memory {
                Some(memory) => memory,
                None => self.segment_memory.insert(permit.memory(0)?),
            };
            memory.grow(
                (path.as_os_str().as_encoded_bytes().len() as u64)
                    .checked_mul(4)
                    .and_then(|bytes| bytes.checked_add(128))
                    .ok_or_else(|| crate::managed::Error::pressure("spill-path-memory-overflow"))?,
            )?;
        }
        let mut writer =
            BufWriter::with_capacity(SEGMENT_BUFFER_BYTES, spill.output().create(&name)?);

        // Segment layout, groups ordered by ascending trigram:
        //   varint(trigram - prev_trigram)
        //   varint(posting_count)
        //   posting_count x { varint(file_id - prev_file_id), loc_mask, next_mask }
        // Both deltas are non-negative because the arena is sorted by
        // (trigram, file_id), which makes the encoding substantially smaller
        // than the 6-byte fixed on-disk posting record.
        let scratch = &mut self.scratch;
        scratch.clear();
        let mut prev_trigram: u32 = 0;
        let mut idx = 0usize;
        while idx < self.arena.len() {
            self.output.check()?;
            let trigram = self.arena[idx].trigram;
            let mut end = idx + 1;
            while end < self.arena.len() && self.arena[end].trigram == trigram {
                if end.is_multiple_of(4096) {
                    self.output.check()?;
                }
                end += 1;
            }

            write_varint(scratch, (trigram - prev_trigram) as u64);
            write_varint(scratch, (end - idx) as u64);
            prev_trigram = trigram;

            let mut prev_file_id: u32 = 0;
            for (index, posting) in self.arena[idx..end].iter().enumerate() {
                if index.is_multiple_of(4096) {
                    self.output.check()?;
                }
                let entry = posting.entry;
                write_varint(scratch, (entry.file_id - prev_file_id) as u64);
                scratch.push(entry.loc_mask);
                scratch.push(entry.next_mask);
                prev_file_id = entry.file_id;
            }

            if scratch.len() >= SPILL_SCRATCH_FLUSH_BYTES {
                writer.write_all(scratch)?;
                scratch.clear();
            }
            idx = end;
        }
        if !scratch.is_empty() {
            writer.write_all(scratch)?;
            scratch.clear();
        }
        writer.flush()?;
        writer.get_ref().sync()?;
        // Release the encode buffer's capacity — it is only needed during a
        // spill and holding it would count against the caller's budget.
        self.scratch = Vec::new();

        self.segments.push(path);
        self.arena.clear();
        Ok(())
    }

    /// Write `index.bin` and `lookup.bin`.
    ///
    /// Returns `(distinct trigram count, spill segments merged)`. Consumes the
    /// sorter so the arena and every spill segment are released before the
    /// caller proceeds.
    pub(crate) fn write_postings(self, index_dir: &Path) -> Result<(usize, usize)> {
        self.write_postings_to(&crate::output::Output::legacy(index_dir))
    }

    pub(crate) fn write_postings_to(
        mut self,
        output: &crate::output::Output,
    ) -> Result<(usize, usize)> {
        output.check()?;
        if self.segments.is_empty() {
            // Never exceeded the budget: identical to the in-memory path.
            self.sort_arena()?;
            let arena = std::mem::take(&mut self.arena);
            return Ok((write_sorted_arena_to(output, &arena)?, 0));
        }

        // Fold the tail into a final segment so the merge has a single
        // uniform input kind.
        self.spill_arena()?;
        self.arena = Vec::new();

        let segments = self.segments.len();
        eprintln!("Merging {segments} spill segment(s) into the index...");
        let source = self
            .spill
            .as_ref()
            .ok_or_else(|| Error::IndexCorrupted("spill segments have no owned source".into()))?
            .output();
        Ok((
            merge_segments(output, &source, &self.segments, self.budget_bytes)?,
            segments,
        ))
    }
}

fn sort_controlled<T: Copy, K: Ord>(
    values: &mut Vec<T>,
    key: impl Fn(&T) -> K,
    output: &crate::output::Output,
) -> Result<()> {
    let Some(permit) = output.control() else {
        values.sort_unstable_by_key(key);
        return Ok(());
    };
    const CHUNK: usize = 4096;
    for chunk in values.chunks_mut(CHUNK) {
        permit.check()?;
        chunk.sort_unstable_by_key(&key);
    }
    if values.len() <= CHUNK {
        return output.check();
    }
    let amount = values
        .capacity()
        .checked_mul(std::mem::size_of::<T>())
        .and_then(|bytes| {
            values
                .len()
                .div_ceil(CHUNK)
                .checked_mul(2 * std::mem::size_of::<(K, usize, usize)>())
                .and_then(|heap| bytes.checked_add(heap))
        })
        .ok_or_else(|| crate::managed::Error::pressure("sort-merge-memory-overflow"))?;
    let _memory = permit.memory(amount as u64)?;
    let mut ordered = Vec::with_capacity(values.capacity());
    let mut heap = BinaryHeap::with_capacity(values.len().div_ceil(CHUNK));
    for start in (0..values.len()).step_by(CHUNK) {
        permit.check()?;
        heap.push(Reverse((
            key(&values[start]),
            start,
            (start + CHUNK).min(values.len()),
        )));
    }
    while let Some(Reverse((_, index, end))) = heap.pop() {
        if ordered.len().is_multiple_of(CHUNK) {
            permit.check()?;
        }
        ordered.push(values[index]);
        let next = index + 1;
        if next < end {
            heap.push(Reverse((key(&values[next]), next, end)));
        }
    }
    *values = ordered;
    output.check()
}

/// Shared writer for `index.bin` + `lookup.bin`.
struct IndexWriter {
    postings: BufWriter<crate::output::OutputFile>,
    lookup: BufWriter<crate::output::OutputFile>,
    posting_scratch: Vec<u8>,
    lookup_scratch: Vec<u8>,
    offset: u64,
    trigram_count: usize,
}

impl IndexWriter {
    fn create(output: &crate::output::Output) -> Result<Self> {
        Ok(Self {
            postings: BufWriter::new(output.create(output.layout().postings())?),
            lookup: BufWriter::new(output.create(output.layout().lookup())?),
            posting_scratch: Vec::with_capacity(
                POSTING_WRITE_CHUNK_ENTRIES * ondisk::POSTING_ENTRY_SIZE,
            ),
            lookup_scratch: Vec::with_capacity(
                LOOKUP_WRITE_CHUNK_ENTRIES * ondisk::LOOKUP_ENTRY_SIZE,
            ),
            offset: 0,
            trigram_count: 0,
        })
    }

    /// Write one trigram's complete, file-id-sorted posting list.
    fn write_group(&mut self, trigram: u32, entries: &[PostingEntry]) -> Result<()> {
        if entries.is_empty() {
            return Ok(());
        }
        let length = u32::try_from(entries.len()).map_err(|_| {
            Error::IndexCorrupted(format!(
                "posting list for trigram {trigram} exceeds the u32 length limit"
            ))
        })?;

        write_lookup_entry(
            &mut self.lookup,
            LookupEntry {
                trigram,
                offset: self.offset,
                length,
            },
            &mut self.lookup_scratch,
        )?;
        write_posting_entries(&mut self.postings, entries, &mut self.posting_scratch)?;

        self.offset += length as u64 * ondisk::POSTING_ENTRY_SIZE as u64;
        self.trigram_count += 1;
        Ok(())
    }

    fn finish(mut self) -> Result<usize> {
        flush_lookup_entries(&mut self.lookup, &mut self.lookup_scratch)?;
        self.postings.flush()?;
        self.lookup.flush()?;
        self.postings.get_ref().sync()?;
        self.lookup.get_ref().sync()?;
        Ok(self.trigram_count)
    }
}

/// Write an already-sorted arena directly, without any spill round trip.
#[cfg(test)]
fn write_sorted_arena(index_dir: &Path, arena: &[TrigramPosting]) -> Result<usize> {
    write_sorted_arena_to(&crate::output::Output::legacy(index_dir), arena)
}

fn write_sorted_arena_to(
    output: &crate::output::Output,
    arena: &[TrigramPosting],
) -> Result<usize> {
    let mut writer = IndexWriter::create(output)?;
    let mut group: Vec<PostingEntry> = Vec::new();
    let mut idx = 0usize;
    while idx < arena.len() {
        output.check()?;
        let trigram = arena[idx].trigram;
        let mut end = idx + 1;
        while end < arena.len() && arena[end].trigram == trigram {
            if end.is_multiple_of(4096) {
                output.check()?;
            }
            end += 1;
        }
        group.clear();
        group.extend(arena[idx..end].iter().map(|p| p.entry));
        writer.write_group(trigram, &group)?;
        idx = end;
    }
    writer.finish()
}

/// Buffered byte reader with a sliding window, used to decode segments.
struct ByteSource {
    file: File,
    buf: Vec<u8>,
    pos: usize,
    filled: usize,
    permit: Option<std::sync::Arc<crate::managed::WorkPermit>>,
}

impl ByteSource {
    fn open(path: &Path, capacity: usize) -> Result<Self> {
        Ok(Self::from_file(File::open(path)?, capacity, None))
    }

    fn from_file(
        file: File,
        capacity: usize,
        permit: Option<std::sync::Arc<crate::managed::WorkPermit>>,
    ) -> Self {
        Self {
            file,
            buf: vec![0u8; capacity.max(MAX_VARINT_LEN)],
            pos: 0,
            filled: 0,
            permit,
        }
    }

    /// Make at least `want` bytes available if the file still has them.
    /// Returns the number actually available, which is short only at EOF.
    fn ensure(&mut self, want: usize) -> Result<usize> {
        debug_assert!(want <= self.buf.len());
        if self.filled - self.pos >= want {
            return Ok(self.filled - self.pos);
        }
        self.buf.copy_within(self.pos..self.filled, 0);
        self.filled -= self.pos;
        self.pos = 0;
        while self.filled < want {
            if let Some(permit) = &self.permit {
                permit.check()?;
            }
            let read = self.file.read(&mut self.buf[self.filled..])?;
            if read == 0 {
                break;
            }
            self.filled += read;
        }
        Ok(self.filled)
    }

    /// Decode one varint. `Ok(None)` means a clean end of segment.
    fn read_varint(&mut self) -> Result<Option<u64>> {
        if self.ensure(MAX_VARINT_LEN)? == 0 {
            return Ok(None);
        }
        let mut value = 0u64;
        let mut shift = 0u32;
        loop {
            if self.pos >= self.filled {
                return Err(Error::IndexCorrupted(
                    "spill segment truncated mid-varint".into(),
                ));
            }
            let byte = self.buf[self.pos];
            self.pos += 1;
            value |= u64::from(byte & 0x7F) << shift;
            if byte & 0x80 == 0 {
                return Ok(Some(value));
            }
            shift += 7;
            if shift >= 64 {
                return Err(Error::IndexCorrupted(
                    "spill segment contains an overlong varint".into(),
                ));
            }
        }
    }

    fn read_u8(&mut self) -> Result<u8> {
        if self.ensure(1)? == 0 {
            return Err(Error::IndexCorrupted(
                "spill segment truncated mid-posting".into(),
            ));
        }
        let byte = self.buf[self.pos];
        self.pos += 1;
        Ok(byte)
    }
}

/// Streaming cursor over one spill segment.
struct SegmentCursor {
    src: ByteSource,
    prev_trigram: u32,
    /// Postings remaining in the group whose header has been read.
    pending_count: usize,
}

impl SegmentCursor {
    fn open(path: &Path, buffer_bytes: usize) -> Result<Self> {
        Ok(Self {
            src: ByteSource::open(path, buffer_bytes)?,
            prev_trigram: 0,
            pending_count: 0,
        })
    }

    /// Read the next group header. `Ok(None)` means the segment is exhausted.
    fn advance(&mut self) -> Result<Option<u32>> {
        let Some(delta) = self.src.read_varint()? else {
            return Ok(None);
        };
        let trigram = u32::try_from(u64::from(self.prev_trigram) + delta)
            .map_err(|_| Error::IndexCorrupted("spill segment trigram delta overflow".into()))?;
        let count = self
            .src
            .read_varint()?
            .ok_or_else(|| Error::IndexCorrupted("spill segment missing group count".into()))?;
        self.prev_trigram = trigram;
        self.pending_count = usize::try_from(count)
            .map_err(|_| Error::IndexCorrupted("spill segment group count overflow".into()))?;
        Ok(Some(trigram))
    }

    /// Decode the pending group's postings, appending them to `out`.
    fn take_group(
        &mut self,
        out: &mut Vec<PostingEntry>,
        mut memory: Option<&mut crate::managed::work::MemoryCharge>,
    ) -> Result<()> {
        let mut prev_file_id: u32 = 0;
        for index in 0..self.pending_count {
            if index.is_multiple_of(4096)
                && let Some(permit) = &self.src.permit
            {
                permit.check()?;
            }
            let delta = self
                .src
                .read_varint()?
                .ok_or_else(|| Error::IndexCorrupted("spill segment truncated in group".into()))?;
            let file_id = u32::try_from(u64::from(prev_file_id) + delta)
                .map_err(|_| Error::IndexCorrupted("spill segment file id overflow".into()))?;
            let loc_mask = self.src.read_u8()?;
            let next_mask = self.src.read_u8()?;
            if out.len() == out.capacity()
                && let Some(memory) = &mut memory
            {
                let capacity = out.capacity().max(512).checked_mul(2).ok_or_else(|| {
                    crate::managed::Error::pressure("posting-group-capacity-overflow")
                })?;
                let bytes = capacity
                    .checked_mul(std::mem::size_of::<PostingEntry>())
                    .ok_or_else(|| {
                        crate::managed::Error::pressure("posting-group-memory-overflow")
                    })?;
                memory.resize(bytes as u64)?;
                out.try_reserve_exact(capacity - out.len())
                    .map_err(|_| crate::managed::Error::pressure("posting-group-allocation"))?;
            }
            out.push(PostingEntry {
                file_id,
                loc_mask,
                next_mask,
            });
            prev_file_id = file_id;
        }
        self.pending_count = 0;
        Ok(())
    }
}

/// Per-segment read-ahead when `read_budget_bytes` is shared across `segments`
/// open cursors.
///
/// Above the floor this keeps total merge memory at roughly the caller's
/// budget regardless of fan-in. Below it — a tiny budget against a very large
/// repository — total degrades to `segments * MIN_SEGMENT_BUFFER_BYTES`, still
/// 64x below a fixed 256 KiB buffer per segment. Bounding that last case
/// absolutely would need a multi-pass merge; at realistic budgets the floor is
/// never reached.
fn segment_buffer_bytes(read_budget_bytes: usize, segments: usize) -> usize {
    (read_budget_bytes / segments.max(1)).clamp(MIN_SEGMENT_BUFFER_BYTES, SEGMENT_BUFFER_BYTES)
}

/// k-way merge of sorted segments into `index.bin` / `lookup.bin`.
///
/// `read_budget_bytes` is shared across every open segment. A fixed per-segment
/// buffer would make merge memory grow with fan-in, which is backwards: a
/// smaller arena spills more segments, so it would make a *tighter* budget cost
/// *more* peak memory. Splitting one budget keeps peak tied to what was asked
/// for. The arena has already been released by this point, so the full budget
/// is available.
fn merge_segments(
    output: &crate::output::Output,
    source: &crate::output::Output,
    segments: &[PathBuf],
    read_budget_bytes: usize,
) -> Result<usize> {
    let per_segment = segment_buffer_bytes(read_budget_bytes, segments.len());
    let _memory = output
        .control()
        .map(|permit| -> Result<_> {
            let bytes = per_segment
                .checked_add(std::mem::size_of::<SegmentCursor>() + 64)
                .and_then(|bytes| bytes.checked_mul(segments.len()))
                .ok_or_else(|| crate::managed::Error::pressure("segment-cursor-memory-overflow"))?;
            Ok(permit.memory(bytes as u64)?)
        })
        .transpose()?;
    let mut group_memory = output
        .control()
        .map(|permit| permit.memory(0))
        .transpose()?;
    let mut cursors: Vec<SegmentCursor> = Vec::with_capacity(segments.len());
    // Min-heap keyed by (trigram, segment index). Ordering by segment index as
    // the tiebreak matters: file IDs are assigned in walk order and segments
    // are spilled in that same order, so visiting a trigram's groups in
    // ascending segment order yields globally ascending file IDs and the
    // concatenation below needs no re-sort.
    let mut heap: BinaryHeap<Reverse<(u32, usize)>> = BinaryHeap::with_capacity(segments.len());

    for (idx, path) in segments.iter().enumerate() {
        output.check()?;
        let mut cursor = if let Some(permit) = source.control() {
            let name = path
                .file_name()
                .and_then(|name| name.to_str())
                .ok_or_else(|| Error::IndexCorrupted("invalid segment member name".into()))?;
            SegmentCursor {
                src: ByteSource::from_file(
                    source.open_file(name)?,
                    per_segment,
                    Some(std::sync::Arc::clone(permit)),
                ),
                prev_trigram: 0,
                pending_count: 0,
            }
        } else {
            SegmentCursor::open(path, per_segment)?
        };
        if let Some(trigram) = cursor.advance()? {
            heap.push(Reverse((trigram, idx)));
        }
        cursors.push(cursor);
    }

    let mut writer = IndexWriter::create(output)?;
    let mut group: Vec<PostingEntry> = Vec::new();

    while let Some(&Reverse((trigram, _))) = heap.peek() {
        output.check()?;
        group.clear();
        let mut needs_sort = false;
        let mut last_file_id: Option<u32> = None;

        while let Some(&Reverse((next_trigram, idx))) = heap.peek() {
            if next_trigram != trigram {
                break;
            }
            heap.pop();

            let before = group.len();
            cursors[idx].take_group(&mut group, group_memory.as_mut())?;
            // Defensive: if the append-in-segment-order invariant is ever
            // broken (e.g. a caller assigns file IDs out of walk order), fall
            // back to sorting rather than emitting an unsorted posting list,
            // which query execution assumes is ascending.
            if let Some(last) = last_file_id
                && group.get(before).is_some_and(|first| first.file_id <= last)
            {
                needs_sort = true;
            }
            last_file_id = group.last().map(|entry| entry.file_id);

            if let Some(next) = cursors[idx].advance()? {
                heap.push(Reverse((next, idx)));
            }
        }

        if needs_sort {
            sort_controlled(&mut group, |entry| entry.file_id, output)?;
        }
        writer.write_group(trigram, &group)?;
    }

    writer.finish()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::reader::IndexReader;

    #[test]
    fn spill_allocation_preserves_colliding_files_and_directories() {
        let tmp = tempfile::tempdir().unwrap();
        let sequence = std::sync::atomic::AtomicU64::new(0);
        let old_file = tmp
            .path()
            .join(format!("spill-{}-0.tmp", std::process::id()));
        let old_dir = tmp
            .path()
            .join(format!("spill-{}-1.tmp", std::process::id()));
        std::fs::write(&old_file, b"retained legacy spill").unwrap();
        std::fs::create_dir(&old_dir).unwrap();
        std::fs::write(old_dir.join("seg-00000.bin"), b"retained segments").unwrap();

        let spill = SpillDir::create_with_sequence(tmp.path(), &sequence).unwrap();
        assert_eq!(
            spill.path,
            tmp.path()
                .join(format!("spill-{}-2.tmp", std::process::id()))
        );
        assert_eq!(std::fs::read(&old_file).unwrap(), b"retained legacy spill");
        assert_eq!(
            std::fs::read(old_dir.join("seg-00000.bin")).unwrap(),
            b"retained segments"
        );
        let created = spill.path.clone();
        drop(spill);
        assert!(!created.exists());
        assert!(old_file.exists());
        assert!(old_dir.exists());
    }

    fn posting(trigram: u32, file_id: u32) -> TrigramPosting {
        TrigramPosting {
            trigram,
            entry: PostingEntry {
                file_id,
                loc_mask: (file_id as u8) | 1,
                next_mask: (trigram as u8) | 1,
            },
        }
    }

    /// Trigram IDs present in a written index, read straight out of
    /// `lookup.bin` so no `meta.json` is required.
    fn trigram_ids(index_dir: &Path) -> Vec<u32> {
        std::fs::read(index_dir.join("lookup.bin"))
            .unwrap()
            .as_chunks::<{ ondisk::LOOKUP_ENTRY_SIZE }>()
            .0
            .iter()
            .map(|c| u32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect()
    }

    // `Vec`'s own doubling would reserve up to 2x the budget (96 MB for the
    // 64 MB default), so the arena could hold half again as much as the caller
    // asked for. The allocation must stay inside the budget, both on the first
    // fill and after a spill reuses the buffer.
    /// Two sorters sharing one `index_dir` in the same process must not see
    /// each other's spill segments.
    ///
    /// Before spill directories carried a per-sorter sequence number, both
    /// sorters wrote `seg-00000.bin`, `seg-00001.bin`, ... into the same
    /// `spill-<pid>.tmp`, so the second one's writes landed on the first one's
    /// recorded paths. The first then merged the second's postings without any
    /// error, because a foreign segment is still a structurally valid segment:
    /// a sorter fed only trigram 100 produced an index containing 100 *and*
    /// 777. That is silent index corruption, so assert on content.
    #[test]
    fn concurrent_sorters_in_one_index_dir_do_not_share_segments() {
        let dir = tempfile::tempdir().unwrap();

        let mut a = ExternalSorter::new(dir.path(), 1);
        for file_id in 0..5000u32 {
            a.push(posting(100, file_id)).unwrap();
        }
        assert!(a.segments.len() > 1, "A should have spilled");

        // B starts on the same index_dir while A is still live.
        let mut b = ExternalSorter::new(dir.path(), 1);
        for file_id in 0..5000u32 {
            b.push(posting(777, file_id)).unwrap();
        }

        assert_ne!(
            a.spill.as_ref().unwrap().path,
            b.spill.as_ref().unwrap().path,
            "each sorter needs its own spill directory"
        );

        let out_a = dir.path().join("out_a");
        let (trigrams_a, _) = a.write_postings(&out_a).unwrap();
        assert_eq!(trigrams_a, 1, "A should see only its own trigram");
        assert_eq!(trigram_ids(&out_a), vec![100]);

        // B still merges correctly afterwards; A's completion dropped only its
        // own spill directory.
        let out_b = dir.path().join("out_b");
        let (trigrams_b, _) = b.write_postings(&out_b).unwrap();
        assert_eq!(trigrams_b, 1, "B should see only its own trigram");
        assert_eq!(trigram_ids(&out_b), vec![777]);
    }

    #[test]
    fn arena_allocation_never_exceeds_the_budget() {
        let dir = tempfile::tempdir().unwrap();
        // 64 KB budget: large enough to exercise several fills, small enough
        // that the entry capacity is not clamped by the 1024-entry floor.
        let budget = 64 * 1024;
        let mut sorter = ExternalSorter::new(dir.path(), budget);
        let capacity = sorter.capacity;
        assert!(
            capacity > 1024,
            "budget should set capacity, not the floor: {capacity}"
        );
        assert_eq!(
            sorter.arena.capacity(),
            capacity,
            "arena should be reserved exactly once, up front"
        );

        // Push well past one full arena so growth and post-spill reuse are
        // both covered.
        for i in 0..(capacity as u32 * 3) {
            sorter.push(posting(i % 977, i)).unwrap();
            assert!(
                sorter.arena.capacity() <= capacity,
                "arena capacity {} exceeded budget capacity {capacity}",
                sorter.arena.capacity()
            );
        }
        assert!(sorter.spilled_segments() > 0, "expected at least one spill");
    }

    /// Build both ways and assert the resulting index files are byte-identical.
    fn assert_paths_match(postings: &[TrigramPosting], budget_bytes: usize) {
        let in_memory = tempfile::tempdir().unwrap();
        let external = tempfile::tempdir().unwrap();

        let mut direct: Vec<TrigramPosting> = postings.to_vec();
        direct.sort_unstable_by(|a, b| {
            a.trigram
                .cmp(&b.trigram)
                .then_with(|| a.entry.file_id.cmp(&b.entry.file_id))
        });
        let expected_trigrams = write_sorted_arena(in_memory.path(), &direct).unwrap();

        let mut sorter = ExternalSorter::new(external.path(), budget_bytes);
        for posting in postings {
            sorter.push(*posting).unwrap();
        }
        let spilled = sorter.spilled_segments();
        let (actual_trigrams, merged_segments) = sorter.write_postings(external.path()).unwrap();

        assert_eq!(expected_trigrams, actual_trigrams, "trigram count mismatch");
        assert!(
            merged_segments == 0 || merged_segments > spilled,
            "the arena tail should be folded into a final segment"
        );
        for name in ["index.bin", "lookup.bin"] {
            let a = std::fs::read(in_memory.path().join(name)).unwrap();
            let b = std::fs::read(external.path().join(name)).unwrap();
            assert_eq!(a, b, "{name} differs (spilled {spilled} segment(s))");
        }
    }

    #[test]
    fn external_matches_in_memory_without_spilling() {
        let postings: Vec<TrigramPosting> = (0..64u32)
            .flat_map(|file_id| (0..32u32).map(move |t| posting(t * 7 + 1, file_id)))
            .collect();
        assert_paths_match(&postings, DEFAULT_BUFFER_BYTES);
    }

    #[test]
    fn external_matches_in_memory_across_many_spills() {
        // A tiny budget still clamps to a 1024-entry arena, so use enough
        // postings to force a double-digit number of segments.
        let postings: Vec<TrigramPosting> = (0..400u32)
            .flat_map(|file_id| (0..64u32).map(move |t| posting(t * 3, file_id)))
            .collect();
        let sorter = ExternalSorter::new(Path::new("."), 1);
        assert_eq!(sorter.capacity, 1024, "budget should clamp to a floor");

        assert_paths_match(&postings, 1);
    }

    #[test]
    fn spilling_actually_happens_under_a_small_budget() {
        let dir = tempfile::tempdir().unwrap();
        let mut sorter = ExternalSorter::new(dir.path(), 1);
        for file_id in 0..50u32 {
            for t in 0..500u32 {
                sorter.push(posting(t, file_id)).unwrap();
            }
        }
        assert!(
            sorter.spilled_segments() >= 20,
            "expected many segments, got {}",
            sorter.spilled_segments()
        );
        sorter.write_postings(dir.path()).unwrap();
    }

    #[test]
    fn spill_directory_is_removed_after_write() {
        let dir = tempfile::tempdir().unwrap();
        let mut sorter = ExternalSorter::new(dir.path(), 1);
        for file_id in 0..20u32 {
            for t in 0..500u32 {
                sorter.push(posting(t, file_id)).unwrap();
            }
        }
        assert!(sorter.spilled_segments() > 0);
        sorter.write_postings(dir.path()).unwrap();

        let leftover: Vec<_> = std::fs::read_dir(dir.path())
            .unwrap()
            .filter_map(|e| e.ok())
            .filter(|e| e.file_name().to_string_lossy().starts_with("spill-"))
            .collect();
        assert!(leftover.is_empty(), "spill directory should be cleaned up");
    }

    #[test]
    fn merged_posting_lists_are_readable_and_sorted() {
        let dir = tempfile::tempdir().unwrap();
        let mut sorter = ExternalSorter::new(dir.path(), 1);
        // Interleave so each trigram's postings land across many segments.
        for file_id in 0..300u32 {
            for t in 0..40u32 {
                sorter.push(posting(t, file_id)).unwrap();
            }
        }
        assert!(sorter.spilled_segments() > 1);
        let (trigram_count, _) = sorter.write_postings(dir.path()).unwrap();
        assert_eq!(trigram_count, 40);

        // files.bin/meta.json are written by the builder; synthesize the
        // minimum the reader needs to resolve posting lists.
        let mut files = Vec::new();
        for id in 0..300u32 {
            ondisk::write_file_entry(&mut files, id, &format!("f{id}.txt")).unwrap();
        }
        std::fs::write(dir.path().join("files.bin"), files).unwrap();
        crate::meta::IndexMeta::new("/tmp/root", 300, trigram_count as u64)
            .save(dir.path())
            .unwrap();

        let reader = IndexReader::open(dir.path()).unwrap();
        for t in 0..40u32 {
            let entries = reader.lookup_trigram_with_masks(t);
            assert_eq!(entries.len(), 300, "trigram {t} should list every file");
            let ids: Vec<u32> = entries.iter().map(|e| e.file_id).collect();
            let mut sorted = ids.clone();
            sorted.sort_unstable();
            assert_eq!(ids, sorted, "posting list for {t} must be file-id sorted");
            for entry in &entries {
                assert_eq!(entry.loc_mask, (entry.file_id as u8) | 1);
                assert_eq!(entry.next_mask, (t as u8) | 1);
            }
        }
    }

    #[test]
    fn empty_input_writes_an_empty_index() {
        let dir = tempfile::tempdir().unwrap();
        let sorter = ExternalSorter::new(dir.path(), DEFAULT_BUFFER_BYTES);
        assert_eq!(sorter.write_postings(dir.path()).unwrap(), (0, 0));
        assert_eq!(
            std::fs::read(dir.path().join("index.bin")).unwrap().len(),
            0
        );
        assert_eq!(
            std::fs::read(dir.path().join("lookup.bin")).unwrap().len(),
            0
        );
    }

    #[test]
    fn varint_roundtrip_covers_boundaries() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("v.bin");
        let values = [0u64, 1, 127, 128, 300, 16_383, 16_384, u32::MAX as u64];
        let mut buf = Vec::new();
        for &v in &values {
            write_varint(&mut buf, v);
        }
        std::fs::write(&path, &buf).unwrap();

        let mut src = ByteSource::open(&path, SEGMENT_BUFFER_BYTES).unwrap();
        for &v in &values {
            assert_eq!(src.read_varint().unwrap(), Some(v));
        }
        assert_eq!(src.read_varint().unwrap(), None);
    }

    /// A tiny buffer must still decode correctly: `ensure` compacts its sliding
    /// window, so the only hard requirement is room for one varint.
    #[test]
    fn varint_roundtrip_survives_a_minimal_buffer() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("v.bin");
        let values = [0u64, 1, 127, 128, 300, 16_383, 16_384, u32::MAX as u64];
        let mut buf = Vec::new();
        for &v in &values {
            write_varint(&mut buf, v);
        }
        std::fs::write(&path, &buf).unwrap();

        let mut src = ByteSource::open(&path, 1).unwrap();
        for &v in &values {
            assert_eq!(src.read_varint().unwrap(), Some(v));
        }
        assert_eq!(src.read_varint().unwrap(), None);
    }

    /// Merge read-ahead is a shared budget, not a per-segment allocation.
    /// Without this, shrinking the arena raises segment count and drives peak
    /// memory *up*, defeating the point of a tighter budget. Measured on the
    /// Linux kernel: a 1 MiB arena spilled 1946 segments, and fixed 256 KiB
    /// buffers put 486 MiB of read-ahead on the heap.
    #[test]
    fn merge_read_ahead_is_bounded_by_the_budget_not_by_fan_in() {
        let budget = 64 * 1024 * 1024;

        // Low fan-in: each segment can afford the full read-ahead.
        assert_eq!(segment_buffer_bytes(budget, 31), SEGMENT_BUFFER_BYTES);

        // High fan-in: buffers shrink so the total tracks the budget.
        for segments in [64usize, 256, 1024, 4096] {
            let total = segment_buffer_bytes(budget, segments) * segments;
            assert!(
                total <= budget,
                "{segments} segments used {total} bytes against a {budget} budget"
            );
        }

        // Past the floor the total grows again, but 64x slower than a fixed
        // per-segment buffer would. This is the Linux 1 MiB case.
        let segments = 1946;
        let total = segment_buffer_bytes(1024 * 1024, segments) * segments;
        assert_eq!(
            segment_buffer_bytes(1024 * 1024, segments),
            MIN_SEGMENT_BUFFER_BYTES
        );
        assert!(
            total < 8 * 1024 * 1024,
            "floor regime should stay small, got {total}"
        );
    }

    /// The merge must stay correct when read buffers are squeezed to the floor
    /// across many segments.
    #[test]
    fn merge_is_correct_with_minimal_read_buffers() {
        let dir = tempfile::tempdir().unwrap();
        // Budget of 1 byte floors the arena at 1024 entries, forcing many spills.
        let mut sorter = ExternalSorter::new(dir.path(), 1);
        for trigram in 0..6_000u32 {
            sorter
                .push(TrigramPosting {
                    trigram,
                    entry: PostingEntry {
                        file_id: trigram / 4,
                        loc_mask: 1,
                        next_mask: 2,
                    },
                })
                .unwrap();
        }
        assert!(sorter.spilled_segments() > 1);

        let (trigrams, merged) = sorter.write_postings(dir.path()).unwrap();
        assert_eq!(trigrams, 6_000);
        assert!(merged > 1, "expected a real merge, got {merged} segment(s)");

        // files.bin/meta.json are written by the builder; synthesize the
        // minimum the reader needs to resolve posting lists.
        let file_count = 6_000u32 / 4;
        let mut files = Vec::new();
        for id in 0..file_count {
            ondisk::write_file_entry(&mut files, id, &format!("f{id}.txt")).unwrap();
        }
        std::fs::write(dir.path().join("files.bin"), files).unwrap();
        crate::meta::IndexMeta::new("/tmp/root", file_count as u64, trigrams as u64)
            .save(dir.path())
            .unwrap();

        let reader = IndexReader::open(dir.path()).unwrap();
        for trigram in 0..6_000u32 {
            assert_eq!(
                reader.lookup_trigram(trigram),
                vec![trigram / 4],
                "postings mismatch for trigram {trigram}"
            );
        }
    }
}
