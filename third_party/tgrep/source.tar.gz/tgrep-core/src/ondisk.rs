/// On-disk binary format for the trigram index.
///
/// Three files compose the searchable-content index. `files-extra.bin`, defined
/// in [`crate::path_index`], complements `files.bin` with paths used only by
/// `--files`.
///
/// ## `lookup.bin` — sorted trigram → postings pointer
/// Fixed-size 16-byte entries sorted by trigram hash for binary search.
/// ```text
/// ┌────────────────┬────────────────┬────────────────┐
/// │ trigram_hash   │ offset         │ length         │
/// │ u32 (4B LE)   │ u64 (8B LE)    │ u32 (4B LE)    │
/// └────────────────┴────────────────┴────────────────┘
/// ```
///
/// ## `index.bin` — concatenated posting lists
/// Each entry is 6 bytes: `file_id(u32) + loc_mask(u8) + next_mask(u8)`.
///
/// ## `files.bin` — file ID → path mapping
/// A versioned header followed by variable-length records:
/// `file_id(u32 LE) + path_len(u16 LE) + path_bytes`.
pub(crate) const LOOKUP_ENTRY_SIZE: usize = 16; // 4 + 8 + 4
pub(crate) const POSTING_ENTRY_SIZE: usize = 6; // 4 + 1 + 1
pub(crate) const POSTING_WRITE_CHUNK_ENTRIES: usize = 8192;
pub(crate) const LOOKUP_WRITE_CHUNK_ENTRIES: usize = 4096;
pub(crate) const INDEX_FORMAT_VERSION: u32 = 3;
pub(crate) const MANAGED_FILE_TABLE_VERSION: u32 = 0x4d32_0001;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum IndexLayout {
    Legacy,
    Managed,
}

impl IndexLayout {
    pub(crate) fn files(self) -> &'static str {
        match self {
            Self::Legacy => "files.bin",
            Self::Managed => "paths.tgm",
        }
    }

    pub(crate) fn lookup(self) -> &'static str {
        match self {
            Self::Legacy => "lookup.bin",
            Self::Managed => "lookup.tgm",
        }
    }

    pub(crate) fn postings(self) -> &'static str {
        match self {
            Self::Legacy => "index.bin",
            Self::Managed => "postings.tgm",
        }
    }

    pub(crate) fn meta(self) -> &'static str {
        match self {
            Self::Legacy => "meta.json",
            Self::Managed => "meta.tgm",
        }
    }
}
// Two duplicate reserved IDs make old dense-ID readers reject the table,
// rather than exposing a hidden-inclusive corpus without visibility filtering.
const FILE_TABLE_MAGIC: &[u8; 12] = b"\xff\xff\xff\xff\0\0\xff\xff\xff\xff\0\0";
pub(crate) const FILE_TABLE_HEADER_LEN: usize = FILE_TABLE_MAGIC.len() + size_of::<u32>();

pub(crate) fn write_file_table_header(writer: &mut impl std::io::Write) -> crate::Result<()> {
    write_file_table_header_for(writer, IndexLayout::Legacy)
}

pub(crate) fn write_file_table_header_for(
    writer: &mut impl std::io::Write,
    layout: IndexLayout,
) -> crate::Result<()> {
    writer.write_all(FILE_TABLE_MAGIC)?;
    let version = match layout {
        IndexLayout::Legacy => INDEX_FORMAT_VERSION,
        IndexLayout::Managed => MANAGED_FILE_TABLE_VERSION,
    };
    writer.write_all(&version.to_le_bytes())?;
    Ok(())
}

pub(crate) fn file_table_body(data: &[u8]) -> crate::Result<&[u8]> {
    file_table_body_for(data, IndexLayout::Legacy)
}

pub(crate) fn file_table_body_for(data: &[u8], layout: IndexLayout) -> crate::Result<&[u8]> {
    if !data.starts_with(FILE_TABLE_MAGIC) {
        return if layout == IndexLayout::Legacy {
            Ok(data)
        } else {
            Err(crate::Error::IndexCorrupted(
                "managed file table header is missing".into(),
            ))
        };
    }
    let version = data
        .get(FILE_TABLE_MAGIC.len()..FILE_TABLE_HEADER_LEN)
        .ok_or_else(|| crate::Error::IndexCorrupted("files.bin header is truncated".into()))?;
    let version = u32::from_le_bytes(version.try_into().unwrap());
    let expected = match layout {
        IndexLayout::Legacy => INDEX_FORMAT_VERSION,
        IndexLayout::Managed => MANAGED_FILE_TABLE_VERSION,
    };
    if version != expected {
        return Err(crate::Error::IndexCorrupted(format!(
            "unsupported files.bin format version {version}"
        )));
    }
    Ok(&data[FILE_TABLE_HEADER_LEN..])
}

/// A single entry in `lookup.bin`.
#[derive(Debug, Clone, Copy)]
pub(crate) struct LookupEntry {
    pub trigram: u32,
    pub offset: u64,
    pub length: u32,
}

/// A single posting entry in `index.bin` (v2 format with masks).
/// 6 bytes on disk: file_id(4) + loc_mask(1) + next_mask(1).
#[derive(Debug, Clone, Copy)]
pub struct PostingEntry {
    pub file_id: u32,
    /// Bit i is set if the trigram occurs at some byte offset where offset % 8 == i.
    pub loc_mask: u8,
    /// 8-bit Bloom filter of characters immediately following this trigram.
    pub next_mask: u8,
}

impl PostingEntry {
    pub fn encode(&self) -> [u8; POSTING_ENTRY_SIZE] {
        let mut buf = [0u8; POSTING_ENTRY_SIZE];
        buf[0..4].copy_from_slice(&self.file_id.to_le_bytes());
        buf[4] = self.loc_mask;
        buf[5] = self.next_mask;
        buf
    }

    pub fn decode(buf: &[u8; POSTING_ENTRY_SIZE]) -> Self {
        Self {
            file_id: u32::from_le_bytes(buf[0..4].try_into().unwrap()),
            loc_mask: buf[4],
            next_mask: buf[5],
        }
    }
}

impl LookupEntry {
    #[cfg(test)]
    pub fn encode(&self) -> [u8; LOOKUP_ENTRY_SIZE] {
        let mut buf = [0u8; LOOKUP_ENTRY_SIZE];
        buf[0..4].copy_from_slice(&self.trigram.to_le_bytes());
        buf[4..12].copy_from_slice(&self.offset.to_le_bytes());
        buf[12..16].copy_from_slice(&self.length.to_le_bytes());
        buf
    }

    pub fn decode(buf: &[u8; LOOKUP_ENTRY_SIZE]) -> Self {
        Self {
            trigram: u32::from_le_bytes(buf[0..4].try_into().unwrap()),
            offset: u64::from_le_bytes(buf[4..12].try_into().unwrap()),
            length: u32::from_le_bytes(buf[12..16].try_into().unwrap()),
        }
    }
}

pub(crate) fn write_posting_entries(
    writer: &mut impl std::io::Write,
    entries: &[PostingEntry],
    scratch: &mut Vec<u8>,
) -> crate::Result<()> {
    for chunk in entries.chunks(POSTING_WRITE_CHUNK_ENTRIES) {
        scratch.clear();
        for entry in chunk {
            scratch.extend_from_slice(&entry.file_id.to_le_bytes());
            scratch.push(entry.loc_mask);
            scratch.push(entry.next_mask);
        }
        writer.write_all(scratch)?;
    }
    Ok(())
}

pub(crate) fn write_lookup_entry(
    writer: &mut impl std::io::Write,
    entry: LookupEntry,
    scratch: &mut Vec<u8>,
) -> crate::Result<()> {
    if scratch.len() == scratch.capacity() {
        flush_lookup_entries(writer, scratch)?;
    }
    scratch.extend_from_slice(&entry.trigram.to_le_bytes());
    scratch.extend_from_slice(&entry.offset.to_le_bytes());
    scratch.extend_from_slice(&entry.length.to_le_bytes());
    Ok(())
}

pub(crate) fn flush_lookup_entries(
    writer: &mut impl std::io::Write,
    scratch: &mut Vec<u8>,
) -> crate::Result<()> {
    if !scratch.is_empty() {
        writer.write_all(scratch)?;
        scratch.clear();
    }
    Ok(())
}

/// Maximum supported path length (in bytes) for entries in `files.bin`.
///
/// Limited by the `u16` length prefix in the on-disk format.
pub(crate) const MAX_PATH_LEN: usize = u16::MAX as usize;

fn validate_file_path_len(path: &str) -> crate::Result<&[u8]> {
    let path_bytes = path.as_bytes();
    if path_bytes.len() > MAX_PATH_LEN {
        // Avoid embedding a 64KiB+ path into the error message (memory
        // pressure and log spam, and potentially echoes untrusted content).
        // Include only the length and a short prefix for diagnostics.
        const PREVIEW: usize = 80;
        let preview_end = path
            .char_indices()
            .take_while(|(i, _)| *i < PREVIEW)
            .last()
            .map(|(i, c)| i + c.len_utf8())
            .unwrap_or(0);
        return Err(crate::Error::IndexCorrupted(format!(
            "path too long for index ({} bytes, max {}): \"{}…\"",
            path_bytes.len(),
            MAX_PATH_LEN,
            &path[..preview_end],
        )));
    }
    Ok(path_bytes)
}

/// Encode a file entry for `files.bin`.
///
/// Returns `Error::IndexCorrupted` if the path exceeds [`MAX_PATH_LEN`] bytes,
/// since the on-disk format uses a `u16` length prefix and a silent truncation
/// here would corrupt the entire trailing portion of `files.bin` (the decoder
/// reads variable-length records sequentially).
#[cfg(test)]
pub(crate) fn encode_file_entry(file_id: u32, path: &str) -> crate::Result<Vec<u8>> {
    let path_bytes = validate_file_path_len(path)?;
    let path_len = path_bytes.len() as u16;
    let mut buf = Vec::with_capacity(4 + 2 + path_bytes.len());
    buf.extend_from_slice(&file_id.to_le_bytes());
    buf.extend_from_slice(&path_len.to_le_bytes());
    buf.extend_from_slice(path_bytes);
    Ok(buf)
}

/// Write a file entry directly to `files.bin` without allocating a temporary buffer.
pub(crate) fn write_file_entry(
    writer: &mut impl std::io::Write,
    file_id: u32,
    path: &str,
) -> crate::Result<()> {
    let path_bytes = validate_file_path_len(path)?;
    let path_len = path_bytes.len() as u16;
    writer.write_all(&file_id.to_le_bytes())?;
    writer.write_all(&path_len.to_le_bytes())?;
    writer.write_all(path_bytes)?;
    Ok(())
}

/// Decode file entries from `files.bin` data.
///
/// Returns `Error::IndexCorrupted` if `data` is truncated mid-record (i.e.
/// not enough bytes for a declared path or a partial header), or a path is not
/// valid UTF-8 and normalized relative to the indexed root.
pub(crate) fn decode_file_entries(data: &[u8]) -> crate::Result<Vec<(u32, String)>> {
    decode_file_entries_controlled(data, None)
}

pub(crate) fn decode_file_entries_controlled(
    data: &[u8],
    permit: Option<&std::sync::Arc<crate::managed::WorkPermit>>,
) -> crate::Result<Vec<(u32, String)>> {
    let mut entries = Vec::new();
    let mut pos = 0;
    while pos < data.len() {
        if let Some(permit) = permit {
            permit.check()?;
        }
        if pos + 6 > data.len() {
            return Err(crate::Error::IndexCorrupted(format!(
                "files.bin truncated: {} trailing bytes < 6-byte header",
                data.len() - pos
            )));
        }
        let file_id = u32::from_le_bytes(data[pos..pos + 4].try_into().unwrap());
        let path_len = u16::from_le_bytes(data[pos + 4..pos + 6].try_into().unwrap()) as usize;
        pos += 6;
        if pos + path_len > data.len() {
            return Err(crate::Error::IndexCorrupted(format!(
                "files.bin truncated: declared path_len {} exceeds remaining {} bytes",
                path_len,
                data.len() - pos
            )));
        }
        let path = std::str::from_utf8(&data[pos..pos + path_len]).map_err(|_| {
            crate::Error::IndexCorrupted(format!(
                "files.bin file_id {file_id} has a non-UTF-8 path"
            ))
        })?;
        crate::rooted::validate_index_path(path).map_err(|error| {
            crate::Error::IndexCorrupted(format!("files.bin file_id {file_id}: {error}"))
        })?;
        entries.push((file_id, path.to_string()));
        pos += path_len;
    }
    Ok(entries)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn file_tables_reject_unsafe_paths_in_every_format() {
        for path in [
            "",
            ".",
            "./file",
            "..",
            "../file",
            "dir/../../file",
            "/file",
            "dir/./file",
            "dir//file",
            "dir/",
            "\\file",
            "\\\\server\\share\\file",
            "//server/share/file",
            "\\\\?\\C:\\file",
            "dir\\file",
            "file\0suffix",
        ]
        .into_iter()
        .chain(["C:/file", "C:file"].into_iter().filter(|_| cfg!(windows)))
        {
            for versioned in [false, true] {
                let mut data = Vec::new();
                if versioned {
                    write_file_table_header(&mut data).unwrap();
                }
                data.extend_from_slice(&encode_file_entry(0, path).unwrap());
                assert!(
                    matches!(
                        decode_file_entries(file_table_body(&data).unwrap()),
                        Err(crate::Error::IndexCorrupted(_))
                    ),
                    "accepted {path:?}, versioned={versioned}"
                );
            }
        }
        let mut data = encode_file_entry(0, "file").unwrap();
        *data.last_mut().unwrap() = 0xff;
        assert!(matches!(
            decode_file_entries(&data),
            Err(crate::Error::IndexCorrupted(_))
        ));
    }

    #[test]
    fn versioned_file_table_rejects_legacy_readers() {
        let mut bytes = Vec::new();
        write_file_table_header(&mut bytes).unwrap();
        write_file_entry(&mut bytes, 0, ".secret.txt").unwrap();
        let entries = decode_file_entries(file_table_body(&bytes).unwrap()).unwrap();
        assert_eq!(entries, [(0, ".secret.txt".to_string())]);

        // The v1/v2 parser either rejects the header as malformed or reaches
        // the unchanged dense/unique-ID validation with duplicate reserved IDs.
        if let Ok(legacy) = decode_file_entries(&bytes) {
            let mut ids = std::collections::HashSet::new();
            assert!(
                legacy
                    .iter()
                    .any(|(id, _)| *id as usize >= legacy.len() || !ids.insert(*id))
            );
        }
        bytes[FILE_TABLE_MAGIC.len()..FILE_TABLE_HEADER_LEN].copy_from_slice(&99u32.to_le_bytes());
        assert!(file_table_body(&bytes).is_err());
    }

    #[test]
    fn test_lookup_roundtrip() {
        let entry = LookupEntry {
            trigram: 0x746865,
            offset: 1024,
            length: 42,
        };
        let encoded = entry.encode();
        let decoded = LookupEntry::decode(&encoded);
        assert_eq!(decoded.trigram, entry.trigram);
        assert_eq!(decoded.offset, entry.offset);
        assert_eq!(decoded.length, entry.length);
    }

    #[test]
    fn test_file_entry_roundtrip() {
        let encoded = encode_file_entry(7, "src/main.rs").unwrap();
        let mut all = Vec::new();
        all.extend_from_slice(&encoded);
        all.extend_from_slice(&encode_file_entry(12, "README.md").unwrap());
        let entries = decode_file_entries(&all).unwrap();
        assert_eq!(entries.len(), 2);
        assert_eq!(entries[0], (7, "src/main.rs".to_string()));
        assert_eq!(entries[1], (12, "README.md".to_string()));
    }

    #[test]
    fn test_write_file_entry_roundtrip() {
        let mut all = Vec::new();
        write_file_entry(&mut all, 7, "src/main.rs").unwrap();
        write_file_entry(&mut all, 12, "README.md").unwrap();
        let entries = decode_file_entries(&all).unwrap();
        assert_eq!(entries[0], (7, "src/main.rs".to_string()));
        assert_eq!(entries[1], (12, "README.md".to_string()));
    }

    #[test]
    fn test_encode_file_entry_rejects_oversized_path() {
        // A path longer than u16::MAX bytes must error rather than silently
        // truncate the on-disk `path_len` field.
        let huge = "a".repeat(MAX_PATH_LEN + 1);
        let err = encode_file_entry(0, &huge).unwrap_err();
        match err {
            crate::Error::IndexCorrupted(_) => {}
            other => panic!("expected IndexCorrupted, got {other:?}"),
        }
    }

    #[test]
    fn test_encode_file_entry_accepts_max_path() {
        let max = "a".repeat(MAX_PATH_LEN);
        let buf = encode_file_entry(0, &max).expect("max-length path should encode");
        let entries = decode_file_entries(&buf).unwrap();
        assert_eq!(entries.len(), 1);
        assert_eq!(entries[0].0, 0);
        assert_eq!(entries[0].1.len(), MAX_PATH_LEN);
    }

    #[test]
    fn test_decode_file_entries_rejects_truncated_header() {
        // Two well-formed entries followed by 3 stray bytes (incomplete header).
        let mut all = encode_file_entry(1, "a.rs").unwrap();
        all.extend_from_slice(&encode_file_entry(2, "b.rs").unwrap());
        all.extend_from_slice(&[0u8, 0, 0]);
        let err = decode_file_entries(&all).unwrap_err();
        assert!(matches!(err, crate::Error::IndexCorrupted(_)));
    }

    #[test]
    fn test_decode_file_entries_rejects_truncated_path() {
        // Header claims 100-byte path but only 5 bytes follow.
        let mut buf = Vec::new();
        buf.extend_from_slice(&7u32.to_le_bytes());
        buf.extend_from_slice(&100u16.to_le_bytes());
        buf.extend_from_slice(b"hello");
        let err = decode_file_entries(&buf).unwrap_err();
        assert!(matches!(err, crate::Error::IndexCorrupted(_)));
    }

    #[test]
    fn test_decode_file_entries_empty_ok() {
        let entries = decode_file_entries(&[]).unwrap();
        assert!(entries.is_empty());
    }

    #[test]
    fn test_posting_entry_roundtrip() {
        let entry = PostingEntry {
            file_id: 42,
            loc_mask: 0b10101010,
            next_mask: 0b11001100,
        };
        let encoded = entry.encode();
        let decoded = PostingEntry::decode(&encoded);
        assert_eq!(decoded.file_id, entry.file_id);
        assert_eq!(decoded.loc_mask, entry.loc_mask);
        assert_eq!(decoded.next_mask, entry.next_mask);
    }

    #[test]
    fn test_write_posting_entries_preserves_chunked_encoding() {
        for count in [
            0,
            1,
            POSTING_WRITE_CHUNK_ENTRIES,
            POSTING_WRITE_CHUNK_ENTRIES + 1,
        ] {
            let entries: Vec<PostingEntry> = (0..count)
                .map(|id| PostingEntry {
                    file_id: id as u32,
                    loc_mask: id as u8,
                    next_mask: !(id as u8),
                })
                .collect();
            let expected: Vec<u8> = entries.iter().flat_map(PostingEntry::encode).collect();
            let mut bytes = Vec::new();
            let mut scratch = Vec::with_capacity(POSTING_WRITE_CHUNK_ENTRIES * POSTING_ENTRY_SIZE);
            let capacity = scratch.capacity();

            write_posting_entries(&mut bytes, &entries, &mut scratch).unwrap();

            assert_eq!(bytes, expected);
            assert_eq!(scratch.capacity(), capacity);
        }
    }

    #[test]
    fn test_write_lookup_entries_flushes_at_capacity() {
        let mut bytes = Vec::new();
        let mut expected = Vec::new();
        let mut scratch = Vec::with_capacity(LOOKUP_WRITE_CHUNK_ENTRIES * LOOKUP_ENTRY_SIZE);
        let capacity = scratch.capacity();
        for trigram in 0..LOOKUP_WRITE_CHUNK_ENTRIES as u32 {
            let entry = LookupEntry {
                trigram,
                offset: u32::MAX as u64 + trigram as u64,
                length: trigram + 1,
            };
            write_lookup_entry(&mut bytes, entry, &mut scratch).unwrap();
            expected.extend_from_slice(&entry.encode());
        }
        assert!(bytes.is_empty());
        assert_eq!(scratch.len(), capacity);

        let next = LookupEntry {
            trigram: LOOKUP_WRITE_CHUNK_ENTRIES as u32,
            offset: u64::MAX,
            length: u32::MAX,
        };
        write_lookup_entry(&mut bytes, next, &mut scratch).unwrap();
        assert_eq!(bytes, expected);
        assert_eq!(scratch, next.encode());
        assert_eq!(scratch.capacity(), capacity);

        expected.extend_from_slice(&next.encode());
        flush_lookup_entries(&mut bytes, &mut scratch).unwrap();
        assert_eq!(bytes, expected);
        assert!(scratch.is_empty());
        flush_lookup_entries(&mut bytes, &mut scratch).unwrap();
        assert_eq!(bytes, expected);
    }

    #[test]
    fn test_buffered_writers_preserve_scratch_on_io_error() {
        let mut writer: &mut [u8] = &mut [];
        let posting = PostingEntry {
            file_id: 42,
            loc_mask: 0x12,
            next_mask: 0x34,
        };
        let mut posting_scratch = Vec::new();
        let err = write_posting_entries(&mut writer, &[posting], &mut posting_scratch).unwrap_err();
        assert!(matches!(
            err,
            crate::Error::Io(err) if err.kind() == std::io::ErrorKind::WriteZero
        ));
        assert_eq!(posting_scratch, posting.encode());

        let lookup = LookupEntry {
            trigram: 123,
            offset: 456,
            length: 789,
        };
        let mut lookup_scratch = lookup.encode().to_vec();
        let err = flush_lookup_entries(&mut writer, &mut lookup_scratch).unwrap_err();
        assert!(matches!(
            err,
            crate::Error::Io(err) if err.kind() == std::io::ErrorKind::WriteZero
        ));
        assert_eq!(lookup_scratch, lookup.encode());

        let next = LookupEntry {
            trigram: 124,
            ..lookup
        };
        let err = write_lookup_entry(&mut writer, next, &mut lookup_scratch).unwrap_err();
        assert!(matches!(
            err,
            crate::Error::Io(err) if err.kind() == std::io::ErrorKind::WriteZero
        ));
        assert_eq!(lookup_scratch, lookup.encode());
    }
}
