//! Integration tests for ripgrep-compatible CLI flags.
//!
//! Most tests use `--no-index` (brute-force) so no index setup is needed.
//! The `indexed_*` tests at the bottom build a trigram index first and verify
//! that the same search flags produce correct results through the index path.

use assert_cmd::Command;
use predicates::prelude::*;
use std::fs;
use std::io::{BufRead, BufReader, Write};
use std::net::TcpStream;
use std::process::{Command as ProcessCommand, Stdio};
use std::time::{Duration, Instant};
use tempfile::TempDir;

/// Create a temp directory with a few source files for testing.
fn setup_fixture() -> TempDir {
    let dir = TempDir::new().unwrap();

    // Create a visible subdirectory for test files so the parallel walker
    // (which respects hidden-directory filtering) always finds them, even
    // when TempDir creates a dot-prefixed path like /tmp/.tmpXXXXXX.
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();

    fs::write(
        sub.join("hello.rs"),
        "fn main() {\n    println!(\"hello world\");\n}\n",
    )
    .unwrap();

    fs::write(
        sub.join("lib.rs"),
        "pub fn add(a: i32, b: i32) -> i32 {\n    a + b\n}\n",
    )
    .unwrap();

    fs::write(
        sub.join("config.toml"),
        "[package]\nname = \"test\"\nversion = \"0.1.0\"\n",
    )
    .unwrap();

    fs::write(
        sub.join("notes.txt"),
        "This is a note.\nNothing important here.\nJust some text.\n",
    )
    .unwrap();

    dir
}

/// Returns the path to the test files inside the fixture.
fn fixture_path(dir: &TempDir) -> String {
    dir.path().join("testdata").to_str().unwrap().to_string()
}

fn tgrep() -> Command {
    Command::cargo_bin("tgrep").unwrap()
}

fn send_rpc_request(port: u16, request: &str) -> std::io::Result<String> {
    let mut stream = TcpStream::connect(format!("127.0.0.1:{port}"))?;
    stream.set_read_timeout(Some(Duration::from_secs(30)))?;
    writeln!(stream, "{request}")?;
    stream.flush()?;
    let mut reader = BufReader::new(stream);
    let mut response = String::new();
    reader.read_line(&mut response)?;
    Ok(response)
}

// ─── Multiple and normalized path arguments ───────────────────────────

#[test]
fn accepts_multiple_path_arguments() {
    let dir = setup_fixture();
    let root = dir.path().join("testdata");
    let hello = root.join("hello.rs").to_str().unwrap().to_string();
    let lib = root.join("lib.rs").to_str().unwrap().to_string();

    tgrep()
        .args(["--no-index", "--no-heading", "fn", &hello, &lib])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs"))
        .stdout(predicate::str::contains("lib.rs"));
}

#[test]
fn strips_extra_quotes_from_path_argument() {
    let dir = setup_fixture();
    let quoted = format!("\"{}\"", fixture_path(&dir));

    tgrep()
        .args(["--no-index", "--no-heading", "fn main", &quoted])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs"));
}

#[test]
fn missing_path_reports_error_and_exits_2() {
    let dir = setup_fixture();
    let missing = dir
        .path()
        .join("testdata")
        .join("does-not-exist.rs")
        .to_str()
        .unwrap()
        .to_string();

    // ripgrep reports unreadable paths on stderr and exits 2 rather than
    // silently pretending there were no matches.
    tgrep()
        .args(["--no-index", "--no-heading", "fn", &missing])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("does-not-exist.rs"));
}

#[test]
fn missing_path_stays_quiet_with_no_messages() {
    let dir = setup_fixture();
    let missing = dir
        .path()
        .join("testdata")
        .join("does-not-exist.rs")
        .to_str()
        .unwrap()
        .to_string();

    tgrep()
        .args([
            "--no-index",
            "--no-messages",
            "--no-heading",
            "fn",
            &missing,
        ])
        .assert()
        .code(2)
        .stderr(predicate::str::is_empty());
}

#[test]
fn missing_path_does_not_stop_remaining_paths() {
    let dir = setup_fixture();
    let missing = dir.path().join("nope").to_str().unwrap().to_string();

    // A bad path must not swallow results from the good ones.
    tgrep()
        .args([
            "--no-index",
            "--no-messages",
            "--no-heading",
            "fn main",
            &missing,
            &fixture_path(&dir),
        ])
        .assert()
        .code(2)
        .stdout(predicate::str::contains("hello.rs"));
}

#[test]
fn stats_follow_matches_on_a_combined_output_stream() {
    let dir = setup_fixture();
    let merged_path = dir.path().join("merged-output.txt");
    {
        let merged = fs::File::create(&merged_path).unwrap();
        let stdout = merged.try_clone().unwrap();

        let status = ProcessCommand::new(env!("CARGO_BIN_EXE_tgrep"))
            .args([
                "--no-index",
                "--stats",
                "--no-heading",
                "fn main",
                &fixture_path(&dir),
            ])
            .stdout(Stdio::from(stdout))
            .stderr(Stdio::from(merged))
            .status()
            .unwrap();
        assert!(status.success());
    }

    let output = fs::read_to_string(merged_path).unwrap();
    let match_at = output
        .find("fn main()")
        .expect("search result should be present");
    let stats_at = output
        .find("Brute-force search completed")
        .expect("stats should be present");
    assert!(
        match_at < stats_at,
        "stats must follow buffered matches on a combined stream: {output:?}"
    );
}

#[test]
fn indexed_stats_follow_matches_on_a_combined_output_stream() {
    let dir = setup_fixture();
    let root = fixture_path(&dir);

    let idx = dir.path().join("idx");
    let idx_str = idx.to_str().unwrap();
    tgrep()
        .args(["index", &root, "--index-path", idx_str])
        .assert()
        .success();

    let merged_path = dir.path().join("merged-indexed-output.txt");
    {
        let merged = fs::File::create(&merged_path).unwrap();
        let stdout = merged.try_clone().unwrap();

        let status = ProcessCommand::new(env!("CARGO_BIN_EXE_tgrep"))
            .args([
                "--stats",
                "--no-heading",
                "--index-path",
                idx_str,
                "fn main",
                &root,
            ])
            .stdout(Stdio::from(stdout))
            .stderr(Stdio::from(merged))
            .status()
            .unwrap();
        assert!(status.success());
    }

    let output = fs::read_to_string(merged_path).unwrap();
    let match_at = output
        .find("fn main()")
        .expect("search result should be present");
    let plan_at = output
        .find("Query plan:")
        .expect("query plan stats should be present");
    let elapsed_at = output
        .find("Search completed")
        .expect("elapsed stats should be present");
    assert!(
        match_at < plan_at && plan_at < elapsed_at,
        "stats must follow buffered matches on a combined stream: {output:?}"
    );
}

fn with_stats_backends(
    root: &std::path::Path,
    index_dir: &std::path::Path,
    mut check: impl FnMut(&[&str], &str),
) {
    check(&["--no-index"], "Brute-force search completed");
    let index = index_dir.to_str().unwrap();
    tgrep()
        .args(["index", root.to_str().unwrap(), "--index-path", index])
        .assert()
        .success();
    check(&["--index-path", index], "Search completed");
    let _server = start_passthru_server(root, index_dir);
    check(&["--index-path", index], "(via server)");
}

#[test]
fn reported_pattern_files_preserve_blank_lines_and_whitespace() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(
        root.join("input.txt"),
        "alpha\nbeta\n test \nplain test\n\ttab \t\n",
    )
    .unwrap();
    let cases = [
        (
            "alpha\n\n",
            false,
            "1:alpha\n2:beta\n3: test \n4:plain test\n5:\ttab \t\n",
        ),
        (
            "\n",
            false,
            "1:alpha\n2:beta\n3: test \n4:plain test\n5:\ttab \t\n",
        ),
        (" test \n", true, "3: test \n"),
        ("\ttab \t\n", true, "5:\ttab \t\n"),
        ("alpha\r\n", false, "1:alpha\n"),
        ("beta", false, "2:beta\n"),
    ];
    let pattern_files: Vec<_> = cases
        .iter()
        .enumerate()
        .map(|(i, (patterns, _, _))| {
            let path = dir.path().join(format!("patterns-{i}.txt"));
            fs::write(&path, patterns).unwrap();
            path
        })
        .collect();

    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for ((_, only_matching, expected), path) in cases.iter().zip(&pattern_files) {
            let mut cmd = tgrep();
            cmd.args(backend)
                .args([
                    "--stats",
                    "--color",
                    "never",
                    "--no-heading",
                    "--no-filename",
                    "-n",
                    "-f",
                ])
                .arg(path);
            if *only_matching {
                cmd.arg("-o");
            }
            let output = cmd.arg(&root).assert().success().get_output().clone();
            assert_eq!(
                String::from_utf8(output.stdout).unwrap(),
                *expected,
                "{marker}"
            );
            assert!(String::from_utf8_lossy(&output.stderr).contains(marker));
        }
    });
}

#[test]
fn reported_empty_pattern_file_is_not_an_empty_pattern() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("input.txt"), "alpha\nbeta\n").unwrap();
    let empty = dir.path().join("empty.txt");
    fs::write(&empty, "").unwrap();

    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for flags in [
            vec![],
            vec!["-F"],
            vec!["-P"],
            vec!["--count"],
            vec!["--count-matches"],
            vec!["--json"],
            vec!["--files-without-match"],
            vec!["--passthru"],
        ] {
            tgrep()
                .args(backend)
                .args(&flags)
                .arg("-f")
                .arg(&empty)
                .arg(&root)
                .assert()
                .code(1)
                .stdout("");
        }
        for engine in ["auto", "default", "pcre2"] {
            tgrep()
                .args(backend)
                .args([
                    "--engine",
                    engine,
                    "--stats",
                    "-F",
                    "-v",
                    "--no-filename",
                    "-n",
                    "-f",
                ])
                .arg(&empty)
                .arg(&root)
                .assert()
                .success()
                .stdout("1:alpha\n2:beta\n")
                .stderr(predicate::str::contains(marker));
        }
        tgrep()
            .args(backend)
            .args(["--stats", "--no-filename", "-n", "-e", "beta", "-f"])
            .arg(&empty)
            .arg(&root)
            .assert()
            .success()
            .stdout("2:beta\n")
            .stderr(predicate::str::contains(marker));
    });
}

#[test]
fn reported_inline_flags_are_scoped_to_each_pattern() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("bar.txt"), "bar\n").unwrap();
    let sensitive = dir.path().join("sensitive.txt");
    let insensitive = dir.path().join("insensitive.txt");
    fs::write(&sensitive, "(?-i)foo\nBAR\n").unwrap();
    fs::write(&insensitive, "(?i)foo\nBAR\n").unwrap();
    let cases: &[(&[&str], i32, &str)] = &[
        (&["-i", "-e", "(?-i)foo", "-e", "BAR"], 0, "bar\n"),
        (&["-e", "(?i)foo", "-e", "BAR"], 1, ""),
        (&["-e", "BAR", "-e", "(?i)foo"], 1, ""),
        (&["-i", "-f", sensitive.to_str().unwrap()], 0, "bar\n"),
        (&["-f", insensitive.to_str().unwrap()], 1, ""),
    ];
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for engine in ["auto", "default", "pcre2"] {
            for (flags, code, expected) in cases {
                tgrep()
                    .args(backend)
                    .args([
                        "--engine",
                        engine,
                        "--stats",
                        "--color",
                        "never",
                        "--no-filename",
                    ])
                    .args(*flags)
                    .arg(&root)
                    .assert()
                    .code(*code)
                    .stdout(*expected)
                    .stderr(predicate::str::contains(marker));
            }
        }
    });
}

#[test]
fn reported_smart_case_uses_literals_from_all_patterns() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("input.txt"), "abc\nABC\na-c\nA-C\n").unwrap();
    fs::write(root.join("literal.txt"), "a\\Sc\nA\\SC\n").unwrap();
    let patterns = dir.path().join("patterns.txt");
    fs::write(&patterns, "ABC\n").unwrap();
    let cases: &[(&[&str], &str)] = &[
        (&["-e", "ABC"], "ABC\n"),
        (&["-f", patterns.to_str().unwrap()], "ABC\n"),
        (&["-e", "abc", "-e", "XYZ"], "abc\n"),
        (&["-e", r"a\Sc"], "abc\nABC\na-c\nA-C\n"),
        (&["-e", r"a\Dc"], "abc\nABC\na-c\nA-C\n"),
        (&["-e", r"a\Wc"], "a-c\nA-C\n"),
        (&["-e", r"a\pLc"], "abc\nABC\n"),
        (&["-e", r"\x41BC"], "ABC\n"),
        (&["-e", r"\x61bc"], "abc\nABC\n"),
        (&["-e", "(?P<UPPER>abc)"], "abc\nABC\n"),
        (&["-F", "-e", r"a\Sc"], "a\\Sc\n"),
        (&["-s", "-e", "abc"], "abc\n"),
        (&["-i", "-e", "ABC"], "abc\nABC\n"),
    ];
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for engine in ["auto", "default", "pcre2"] {
            for (flags, expected) in cases {
                tgrep()
                    .args(backend)
                    .args([
                        "--engine",
                        engine,
                        "--stats",
                        "--color",
                        "never",
                        "--sort",
                        "path",
                        "--no-filename",
                        "-S",
                    ])
                    .args(*flags)
                    .arg(&root)
                    .assert()
                    .success()
                    .stdout(*expected)
                    .stderr(predicate::str::contains(marker));
            }
        }
    });
}

#[test]
fn reported_word_matching_accepts_nonword_pattern_edges() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(
        root.join("input.txt"),
        "a- x\nx -a\nxa- x\nx -ax\na-x\nx-a\n\u{e9}a- x\nx -a\u{e9}\n",
    )
    .unwrap();
    fs::write(root.join("punct.txt"), "---\na---\n---a\n").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for engine in ["auto", "default", "pcre2"] {
            for fixed in [false, true] {
                for (pattern, glob, expected) in [
                    ("a-", "input.txt", "1:a- x\n"),
                    ("-a", "input.txt", "2:x -a\n"),
                    ("---", "punct.txt", "1:---\n"),
                ] {
                    let mut cmd = tgrep();
                    cmd.args(backend).args([
                        "--engine",
                        engine,
                        "--stats",
                        "--color",
                        "never",
                        "-w",
                        "--no-filename",
                        "-n",
                        "-g",
                        glob,
                    ]);
                    if fixed {
                        cmd.arg("-F");
                    }
                    cmd.args(["--", pattern])
                        .arg(&root)
                        .assert()
                        .success()
                        .stdout(expected)
                        .stderr(predicate::str::contains(marker));
                }
            }
        }
    });
}

#[test]
fn reported_word_and_line_flags_use_the_last_occurrence() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("input.txt"), "foo bar\n").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, code, expected) in [
            (vec!["-x", "-w"], 0, "foo bar\n"),
            (vec!["-w", "-x"], 1, ""),
            (vec!["-xw"], 0, "foo bar\n"),
            (vec!["-wx"], 1, ""),
            (vec!["--line-regexp", "--word-regexp"], 0, "foo bar\n"),
            (vec!["--word-regexp", "--line-regexp"], 1, ""),
        ] {
            tgrep()
                .args(backend)
                .args(["--stats", "--color", "never", "--no-filename"])
                .args(flags)
                .args(["--", "foo"])
                .arg(&root)
                .assert()
                .code(code)
                .stdout(expected)
                .stderr(predicate::str::contains(marker));
        }
    });
}

#[test]
fn word_boundary_patterns_print_each_matching_line_once() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("words.txt"), "aaa\nbbb\n").unwrap();
    fs::write(root.join("punct.txt"), "!!\nbbb\n").unwrap();
    fs::write(root.join("tail.txt"), "x\nbbb").unwrap();

    tgrep()
        .args(["--no-index", "--color", "never", r"\b"])
        .arg(root.join("words.txt"))
        .assert()
        .success()
        .stdout("aaa\nbbb\n");

    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (pattern, glob, expected) in [
            // An empty match at offset 0.
            (r"\b", "words.txt", "1:aaa\n2:bbb\n"),
            // An empty match at the start of a later line.
            (r"\<", "punct.txt", "2:bbb\n"),
            // The `\<` before `bbb` is hidden behind the `\n` that `\s` matched.
            (r"\s|\<", "tail.txt", "1:x\n2:bbb\n"),
        ] {
            tgrep()
                .args(backend)
                .args([
                    "--stats",
                    "--color",
                    "never",
                    "--no-filename",
                    "-n",
                    "-g",
                    glob,
                    "--",
                    pattern,
                ])
                .arg(&root)
                .assert()
                .success()
                .stdout(expected)
                .stderr(predicate::str::contains(marker));
        }
    });
}

/// ripgrep 15.2.0 totals a file's `bytes_printed` from its `begin`, `match`
/// and `context` messages before writing that file's `end`, and the summary
/// sums those per-file totals. Neither `end` nor `summary` counts itself.
#[test]
fn json_bytes_printed_excludes_end_messages_on_every_backend() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(
        root.join("probe.cs"),
        "// ActivityScope\n// ActivityScope second\n",
    )
    .unwrap();
    fs::write(
        root.join("other.cs"),
        "before\nActivityScope three\nafter\n",
    )
    .unwrap();
    fs::write(root.join("miss.cs"), "no hit\n").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        let output = tgrep()
            .args(backend)
            .args(["--stats", "--json", "--color", "never", "-C", "1"])
            .args(["-e", "ActivityScope", "--"])
            .arg(&root)
            .assert()
            .success()
            .stderr(predicate::str::contains(marker))
            .get_output()
            .clone();
        let stdout = String::from_utf8(output.stdout).unwrap();
        let (mut printed, mut ends, mut summary) = (0, Vec::new(), Vec::new());
        for line in stdout.split_inclusive('\n') {
            let row: serde_json::Value = serde_json::from_str(line).unwrap();
            let reported = &row["data"]["stats"]["bytes_printed"];
            match row["type"].as_str().unwrap() {
                "begin" | "match" | "context" => printed += line.len() as u64,
                "end" => ends.push((reported.as_u64().unwrap(), std::mem::take(&mut printed))),
                "summary" => summary.push(reported.as_u64().unwrap()),
                kind => panic!("{marker}: unexpected {kind}: {stdout}"),
            }
        }
        assert_eq!(ends.len(), 2, "{marker}: {stdout}");
        for (reported, emitted) in &ends {
            assert_eq!(reported, emitted, "{marker}: {stdout}");
        }
        let total: u64 = ends.iter().map(|(reported, _)| reported).sum();
        assert_eq!(summary, [total], "{marker}: {stdout}");
    });
}

#[test]
fn json_backend_search_work_stats_include_candidates_without_output() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::create_dir(root.join("nested")).unwrap();
    let probe = "// ActivityScope\n// ActivityScope second\n";
    let other = "ActivityScope three\n";
    // The literal is present, but its word boundary never matches.
    let false_positive = "ActivityScopeExtra\n";
    let miss = "no hit\n";
    for (file, contents) in [
        ("probe.cs", probe),
        ("nested/other.cs", other),
        ("candidate.cs", false_positive),
        ("miss.cs", miss),
    ] {
        fs::write(root.join(file), contents).unwrap();
    }
    let assert_stats = |output: std::process::Output,
                        searches: u64,
                        bytes: u64,
                        matching_files: u64,
                        matches: u64| {
        let stdout = String::from_utf8(output.stdout).unwrap();
        let rows: Vec<serde_json::Value> = stdout
            .lines()
            .map(|line| serde_json::from_str(line).unwrap())
            .collect();
        for row in rows.iter().filter(|row| row["type"] == "end") {
            let path = row["data"]["path"]["text"].as_str().unwrap();
            let expected = if path.ends_with("probe.cs") {
                probe
            } else {
                other
            };
            assert_eq!(
                row["data"]["stats"]["bytes_searched"],
                expected.len(),
                "{stdout}"
            );
            assert_eq!(row["data"]["stats"]["searches"], 1, "{stdout}");
        }
        let summaries: Vec<_> = rows.iter().filter(|row| row["type"] == "summary").collect();
        assert_eq!(summaries.len(), 1, "{stdout}");
        let stats = &summaries[0]["data"]["stats"];
        assert_eq!(stats["searches"], searches, "{stdout}");
        assert_eq!(stats["bytes_searched"], bytes, "{stdout}");
        assert_eq!(stats["searches_with_match"], matching_files, "{stdout}");
        assert_eq!(stats["matches"], matches, "{stdout}");
        assert_eq!(stats["matched_lines"], matches, "{stdout}");
    };
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for diagnostics in [false, true] {
            for (paths, pattern, searches, bytes, matching_files, matches) in [
                (
                    vec![root.clone()],
                    r"ActivityScope\b",
                    if marker == "Brute-force search completed" {
                        4
                    } else {
                        3
                    },
                    probe.len()
                        + other.len()
                        + false_positive.len()
                        + if marker == "Brute-force search completed" {
                            miss.len()
                        } else {
                            0
                        },
                    2,
                    3,
                ),
                (
                    vec![root.join("nested")],
                    r"ActivityScope\b",
                    1,
                    other.len(),
                    1,
                    1,
                ),
                (
                    vec![root.join("nested"), root.join("nested")],
                    r"ActivityScope\b",
                    2,
                    2 * other.len(),
                    2,
                    2,
                ),
                (
                    vec![root.clone()],
                    "no-such-literal",
                    if marker == "Brute-force search completed" {
                        4
                    } else {
                        0
                    },
                    if marker == "Brute-force search completed" {
                        probe.len() + other.len() + false_positive.len() + miss.len()
                    } else {
                        0
                    },
                    0,
                    0,
                ),
            ] {
                let mut command = tgrep();
                command.args(backend).args(["--json", "--color", "never"]);
                if diagnostics {
                    command.arg("--stats");
                }
                let output = command
                    .args(["-e", pattern, "--"])
                    .args(paths)
                    .output()
                    .unwrap();
                assert_eq!(output.status.code(), Some(if matches == 0 { 1 } else { 0 }));
                let stderr = String::from_utf8_lossy(&output.stderr);
                assert!(!stderr.contains("falling back"), "{stderr}");
                if diagnostics {
                    assert!(stderr.contains(marker), "{stderr}");
                }
                assert_stats(output, searches, bytes as u64, matching_files, matches);
            }
        }
    });
}

#[test]
fn reported_multiline_preserves_adjacent_matches_in_every_output() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.txt"), "aa\n").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, expected) in [
            (vec!["-o", "-n", "--no-filename"], "1:a\n1:a\n".to_string()),
            (vec!["--count-matches", "--no-filename"], "2\n".to_string()),
            (
                vec!["--vimgrep"],
                format!("{0}:1:1:aa\n{0}:1:2:aa\n", root.join("a.txt").display()),
            ),
        ] {
            tgrep()
                .args(backend)
                .args(["--stats", "--color", "never", "-U"])
                .args(flags)
                .args(["--", "a"])
                .arg(&root)
                .assert()
                .success()
                .stdout(expected)
                .stderr(predicate::str::contains("2 matches (1 matched lines)"))
                .stderr(predicate::str::contains(marker));
        }

        for (pattern, spans) in [
            ("a", vec![(0, 1), (1, 2)]),
            ("", vec![(0, 0), (1, 1), (2, 2)]),
        ] {
            let output = tgrep()
                .args(backend)
                .args(["--stats", "-U", "--json", "-e", pattern])
                .arg(&root)
                .assert()
                .success()
                .stderr(predicate::str::contains(marker))
                .get_output()
                .clone();
            let rows: Vec<serde_json::Value> = String::from_utf8(output.stdout)
                .unwrap()
                .lines()
                .map(|line| serde_json::from_str(line).unwrap())
                .collect();
            let hits: Vec<_> = rows.iter().filter(|row| row["type"] == "match").collect();
            assert_eq!(hits.len(), 1);
            assert_eq!(hits[0]["data"]["lines"]["text"], "aa\n");
            let submatches: Vec<_> = spans
                .iter()
                .map(|&(start, end)| {
                    serde_json::json!({"match": {"text": pattern}, "start": start, "end": end})
                })
                .collect();
            assert_eq!(hits[0]["data"]["submatches"], serde_json::json!(submatches));
            for kind in ["end", "summary"] {
                let row = rows.iter().find(|row| row["type"] == kind).unwrap();
                assert_eq!(
                    row["data"]["stats"]["matches"],
                    spans.len(),
                    "{marker}: {kind}"
                );
                assert_eq!(row["data"]["stats"]["matched_lines"], 1, "{marker}: {kind}");
            }
        }
    });
}

#[test]
fn reported_patterns_accumulate_across_search_and_pattern_files() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("input.txt"), "foo\nbar\nbaz\n").unwrap();
    let pattern_file = |name: &str, patterns: &str| {
        let path = dir.path().join(name);
        fs::write(&path, patterns).unwrap();
        path.to_str().unwrap().to_string()
    };
    let p1 = pattern_file("p1.txt", "foo\n");
    let p2 = pattern_file("p2.txt", "bar\n");
    let empty = pattern_file("empty.txt", "");
    let (p1, p2, empty) = (p1.as_str(), p2.as_str(), empty.as_str());
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        // Flags before `search`, flags after it, and the lines they select.
        for (global, local, expected) in [
            (vec!["-e", "foo"], vec!["-e", "bar"], "foo\nbar\n"),
            (vec!["-f", p1], vec!["-f", p2], "foo\nbar\n"),
            (vec!["-e", "foo"], vec!["-f", p2], "foo\nbar\n"),
            (vec![], vec!["-f", p1, "-f", p2], "foo\nbar\n"),
            (vec!["-f", p1, "-f", p2], vec![], "foo\nbar\n"),
            (vec!["-f", empty, "-f", p2], vec![], "bar\n"),
            (vec!["-e", "baz", "-f", p1], vec![], "foo\nbaz\n"),
            (vec!["-f", p1, "-e", "baz"], vec![], "foo\nbaz\n"),
        ] {
            let mut cmd = tgrep();
            cmd.args(backend)
                .args(["--stats", "--color", "never", "--no-filename"])
                .args(&global);
            if !local.is_empty() {
                cmd.arg("search").args(&local);
            }
            cmd.arg("--")
                .arg(&root)
                .assert()
                .success()
                .stdout(expected)
                .stderr(predicate::str::contains(marker));
        }
    });
}

#[test]
fn reported_case_flags_use_the_last_occurrence() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.txt"), "foo\nFOO\n").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        // Flags before `search`, flags after it, the pattern and its lines.
        for (global, local, pattern, expected) in [
            (vec!["-i", "-s"], vec![], "foo", "foo\n"),
            (vec!["-i", "-S"], vec![], "FOO", "FOO\n"),
            (vec!["-i", "-S"], vec![], "foo", "foo\nFOO\n"),
            (vec!["-s", "-S"], vec![], "foo", "foo\nFOO\n"),
            (vec!["-s", "-i"], vec![], "foo", "foo\nFOO\n"),
            (vec!["-S", "-i"], vec![], "FOO", "foo\nFOO\n"),
            (
                vec!["--ignore-case", "--case-sensitive"],
                vec![],
                "foo",
                "foo\n",
            ),
            (
                vec!["--smart-case", "--ignore-case"],
                vec![],
                "FOO",
                "foo\nFOO\n",
            ),
            (vec!["-i"], vec!["-s"], "foo", "foo\n"),
            (vec!["-s"], vec!["-i"], "foo", "foo\nFOO\n"),
            (vec!["-i"], vec!["-S"], "FOO", "FOO\n"),
            (vec!["-S"], vec!["-i"], "FOO", "foo\nFOO\n"),
        ] {
            let mut cmd = tgrep();
            cmd.args(backend)
                .args(["--stats", "--color", "never", "--no-filename"])
                .args(&global);
            if !local.is_empty() {
                cmd.arg("search").args(&local);
            }
            cmd.args(["--", pattern])
                .arg(&root)
                .assert()
                .success()
                .stdout(expected)
                .stderr(predicate::str::contains(marker));
        }
    });
}

/// A Rust file and a text file with the same contents, plus the `-l` line
/// each one prints.
fn type_fixture() -> (TempDir, std::path::PathBuf, String, String) {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.rs"), "needle\n").unwrap();
    fs::write(root.join("a.txt"), "needle\n").unwrap();
    let rs = format!("{}\n", root.join("a.rs").display());
    let txt = format!("{}\n", root.join("a.txt").display());
    (dir, root, rs, txt)
}

/// Check that a content search and `--files` both select `expected`.
fn assert_selected_files(
    backend: &[&str],
    marker: &str,
    root: &std::path::Path,
    flags: &[&str],
    expected: &str,
) {
    tgrep()
        .args(backend)
        .args(["--stats", "--color", "never", "--sort", "path", "-l"])
        .args(flags)
        .args(["--", "needle"])
        .arg(root)
        .assert()
        .code(if expected.is_empty() { 1 } else { 0 })
        .stdout(expected.to_string())
        .stderr(predicate::str::contains(marker));
    // An empty `--files` listing exits 0, unlike ripgrep, so only the listing
    // is compared.
    tgrep()
        .args(backend)
        .args(["--sort", "path", "--files"])
        .args(flags)
        .arg(root)
        .assert()
        .stdout(expected.to_string());
}

#[test]
fn reported_positive_globs_override_type_filters() {
    let (dir, root, rs, txt) = type_fixture();
    let both = format!("{rs}{txt}");
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, expected) in [
            (vec!["-t", "rust", "-g", "*.txt"], txt.as_str()),
            (vec!["-t", "rust", "-g", "!*.txt"], rs.as_str()),
            (
                vec!["-t", "rust", "-g", "*.txt", "-g", "*.rs"],
                both.as_str(),
            ),
            (vec!["-t", "rust", "--iglob", "*.TXT"], txt.as_str()),
            (vec!["-T", "rust", "-g", "*.rs"], rs.as_str()),
        ] {
            assert_selected_files(backend, marker, &root, &flags, expected);
        }
    });
}

#[test]
fn reported_type_selections_follow_argument_order() {
    let (dir, root, rs, _) = type_fixture();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, expected) in [
            (vec!["-T", "rust", "-t", "rust"], rs.as_str()),
            (vec!["-t", "rust", "-T", "rust"], ""),
            (vec!["--type-not", "rust", "--type", "rust"], rs.as_str()),
            (vec!["-t", "rust", "-T", "rust", "-t", "rust"], rs.as_str()),
            (vec!["-T", "rust", "-t", "rust", "-T", "rust"], ""),
        ] {
            assert_selected_files(backend, marker, &root, &flags, expected);
        }
        // `search` appends its flags after the ones before it.
        for (global, local, expected) in [
            (["-T", "rust"], ["-t", "rust"], rs.as_str()),
            (["-t", "rust"], ["-T", "rust"], ""),
        ] {
            tgrep()
                .args(backend)
                .args(["--stats", "--color", "never", "-l"])
                .args(global)
                .arg("search")
                .args(local)
                .args(["--", "needle"])
                .arg(&root)
                .assert()
                .code(if expected.is_empty() { 1 } else { 0 })
                .stdout(expected.to_string())
                .stderr(predicate::str::contains(marker));
        }
    });
}

#[test]
fn reported_type_definitions_follow_argument_order() {
    let (dir, root, _, txt) = type_fixture();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        tgrep()
            .args(backend)
            .args(["--type-add", "rust:*.txt", "--type-clear", "rust"])
            .args(["-t", "rust", "--", "needle"])
            .arg(&root)
            .assert()
            .code(2)
            .stdout("")
            .stderr(predicate::str::contains("unrecognized file type: rust"));
        // Flags before `search` and flags after it.
        for (global, local) in [
            (
                vec!["--type-clear", "rust", "--type-add", "rust:*.txt"],
                vec![],
            ),
            (
                vec!["--type-clear", "rust"],
                vec!["--type-add", "rust:*.txt"],
            ),
        ] {
            let mut cmd = tgrep();
            cmd.args(backend)
                .args(["--stats", "--color", "never", "-l"])
                .args(&global);
            if !local.is_empty() {
                cmd.arg("search").args(&local);
            }
            cmd.args(["-t", "rust", "--", "needle"])
                .arg(&root)
                .assert()
                .success()
                .stdout(txt.clone())
                .stderr(predicate::str::contains(marker));
        }
    });
    for (flags, rust) in [
        (
            vec!["--type-clear", "rust", "--type-add", "rust:*.txt"],
            Some("rust: *.txt"),
        ),
        (
            vec!["--type-add", "rust:*.txt", "--type-clear", "rust"],
            None,
        ),
        (vec!["--type-add", "rust:*.txt"], Some("rust: *.rs, *.txt")),
        // `--type-list` preempts any subcommand, and reads the type flags on
        // both sides of it in command-line order.
        (
            vec!["--type-clear", "rust", "index", "--type-add", "rust:*.txt"],
            Some("rust: *.txt"),
        ),
        (
            vec!["--type-add", "rust:*.txt", "status", "--type-clear", "rust"],
            None,
        ),
    ] {
        let output = tgrep()
            .current_dir(dir.path())
            .args(&flags)
            .arg("--type-list")
            .assert()
            .success()
            .get_output()
            .stdout
            .clone();
        let listing = String::from_utf8(output).unwrap();
        assert_eq!(
            listing.lines().find(|line| line.starts_with("rust:")),
            rust,
            "{flags:?}"
        );
    }
}

/// ripgrep rejects an invalid `--type-add` before searching, even one that no
/// `-t`/`-T` uses, and definitions that nothing selects leave every file in.
/// A server is not sent unselected definitions, so the client has to reject
/// them itself rather than report a server failure and fall back.
#[test]
fn unselected_type_definitions_are_validated_but_do_not_filter() {
    let (dir, root, rs, txt) = type_fixture();
    let both = format!("{rs}{txt}");
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for flags in [
            vec!["--type-add", "foo:*.x", "--type-clear", "foo"],
            vec!["--type-add", "foo:include:rust", "--type-clear", "rust"],
            // Only a selected type's globs are compiled.
            vec!["--type-add", "foo:["],
        ] {
            assert_selected_files(backend, marker, &root, &flags, &both);
        }
        for (flags, error) in [
            (
                vec!["--type-add", "bogus"],
                "invalid --type-add value `bogus`: expected `name:glob`",
            ),
            (
                vec!["--type-clear", "rust", "--type-add", "foo:include:rust"],
                "invalid --type-add value `foo:include:rust`: unrecognized file type `rust`",
            ),
        ] {
            for listing in [&["-l", "--", "needle"][..], &["--files"][..]] {
                tgrep()
                    .args(backend)
                    .args(["--color", "never"])
                    .args(&flags)
                    .args(listing)
                    .arg(&root)
                    .assert()
                    .code(2)
                    .stdout("")
                    .stderr(format!("tgrep: {error}\n"));
            }
        }
    });
}

#[test]
fn reported_multiline_replace_rewrites_cross_line_matches() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.txt"), "hello\nworld\n").unwrap();
    fs::write(root.join("c.txt"), "x\nhello\nworld\ny\nz\nhello\nworld\n").unwrap();
    let a = root.join("a.txt").display().to_string();
    let c = root.join("c.txt").display().to_string();
    let (pair, lines, o_w) = (r"hello\nworld", r"hello\nworld\n", r"(o\nw)");
    // ripgrep numbers the rewritten lines from the start of the block and
    // repeats its starting column on each of them.
    let blocks = "1:3:heA\n2:3:BA\n3:3:Bo\n4:3:worA\n5:3:Bd\n\
                  2:3:heA\n3:3:BA\n4:3:Bo\n5:3:worA\n6:3:Bd\n\
                  6:3:heA\n7:3:BA\n8:3:Bo\n9:3:worA\n10:3:Bd\n";
    let only = "1:3:A\n2:3:B\n2:6:A\n3:6:B\n4:14:A\n5:14:B\n\
                2:3:A\n3:3:B\n3:6:A\n4:6:B\n5:14:A\n6:14:B\n\
                6:3:A\n7:3:B\n7:6:A\n8:6:B\n9:14:A\n10:14:B\n";
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, pattern, expected) in [
            (
                vec!["-I", "-n", "-r", "X"],
                pair,
                "1:X\n2:X\n6:X\n".to_string(),
            ),
            (
                vec!["-I", "-n", "-o", "-r", "${2}/${1}"],
                r"(hello)\n(world)",
                "1:world/hello\n2:world/hello\n6:world/hello\n".to_string(),
            ),
            (
                vec!["-I", "-n", "-C1", "-r", "X"],
                pair,
                "1:X\n--\n1-x\n2:X\n4-y\n5-z\n6:X\n".to_string(),
            ),
            // Every printed line of the first file is empty, so no separator
            // precedes the second one.
            (
                vec!["-I", "-n", "-A1", "-r", ""],
                lines,
                "4-y\n--\n".to_string(),
            ),
            (
                vec!["-n", "--heading", "-A1", "-r", ""],
                lines,
                format!("{a}\n\n{c}\n4-y\n--\n"),
            ),
            (
                vec!["--vimgrep", "-r", "X"],
                pair,
                format!("{a}:1:1:X\n{c}:2:1:X\n{c}:6:1:X\n"),
            ),
            (
                vec!["-I", "-n", "--passthru", "-r", "X"],
                pair,
                "1:X\n1-x\n2:X\n4-y\n5-z\n6:X\n".to_string(),
            ),
            (
                vec!["-I", "-n", "-m1", "-r", "X"],
                pair,
                "1:X\n2:X\n".to_string(),
            ),
            (
                vec!["-I", "-n", "-b", "-r", "X"],
                pair,
                "1:0:X\n2:2:X\n6:18:X\n".to_string(),
            ),
            (vec!["-I", "-r", ""], lines, String::new()),
            (
                vec!["-I", "-n", "--column", "-r", "<$1>"],
                o_w,
                "1:5:hell<o\n2:5:w>orld\n2:5:hell<o\n3:5:w>orld\n6:5:hell<o\n7:5:w>orld\n"
                    .to_string(),
            ),
            (
                vec!["-I", "-n", "--column", "-o", "-r", "<$1>"],
                o_w,
                "1:5:<o\n2:5:w>\n2:5:<o\n3:5:w>\n6:5:<o\n7:5:w>\n".to_string(),
            ),
            (
                vec!["--vimgrep", "-r", "<$1>"],
                o_w,
                format!("{a}:1:5:hell<o\n{c}:2:5:hell<o\n{c}:6:5:hell<o\n"),
            ),
            // `\s` can match a line terminator, so matches on adjacent lines
            // form one block even though none of them crosses a line.
            (
                vec!["-I", "-n", "--column", "-r", "A\nB"],
                r"l\s?",
                blocks.to_string(),
            ),
            (
                vec!["-I", "-n", "--column", "-o", "-r", "A\nB"],
                r"l\s?",
                only.to_string(),
            ),
        ] {
            // `--passthru` must print every file, so it never asks the server.
            let marker = if flags.contains(&"--passthru") && marker == "(via server)" {
                "Search completed"
            } else {
                marker
            };
            tgrep()
                .args(backend)
                .args(["--stats", "--color", "never", "--sort", "path", "-U"])
                .args(&flags)
                .args(["--", pattern])
                .arg(&root)
                .assert()
                .success()
                .stdout(expected)
                .stderr(predicate::str::contains(marker));
        }
    });
}

/// ripgrep reports no match in an empty file, not even a zero-width one, so
/// `-U --replace` has no block to rewrite and context has nothing to surround.
#[test]
fn multiline_replace_never_matches_an_empty_file() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("empty.txt"), "").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for pattern in ["^", r"\A", "(?s).*"] {
            for context in [&[][..], &["-C1"], &["-A1"], &["-B1"]] {
                tgrep()
                    .args(backend)
                    .args(["--stats", "--color", "never", "-U", "-r", "X"])
                    .args(context)
                    .args(["--", pattern])
                    .arg(&root)
                    .assert()
                    .code(1)
                    .stdout("")
                    .stderr(predicate::str::contains(marker));
            }
        }
    });
}

/// Searching one file at a time, as it does under `--sort`, ripgrep writes a
/// file's separator (its path, with `--heading`) before it renders the file's
/// first block, and a context break before any block that does not follow on
/// from the last one, without knowing whether the rewrite will leave a row to
/// print. A hidden block after printed output therefore keeps its `--`, even
/// when nothing follows it.
#[test]
fn multiline_replace_hidden_blocks_keep_their_separators() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.txt"), "xx\nzz\n").unwrap();
    fs::write(root.join("b.txt"), "yy\n").unwrap();
    fs::write(root.join("c.txt"), "m\nyy\nm\nxx\nm\nm\nm\nyy\n").unwrap();
    fs::write(root.join("d.txt"), "yy\n").unwrap();
    let path = |name: &str| root.join(name).display().to_string();
    let (a, b, c, d) = (path("a.txt"), path("b.txt"), path("c.txt"), path("d.txt"));
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, expected) in [
            (
                vec!["-I", "-n", "-C1"],
                "1:xx\n2-zz\n--\n--\n1-m\n3-m\n4:xx\n5-m\n--\n7-m\n--\n".to_string(),
            ),
            (
                vec!["-I", "-n", "-A1"],
                "1:xx\n2-zz\n--\n--\n3-m\n4:xx\n5-m\n--\n--\n".to_string(),
            ),
            (
                vec!["-n", "--heading", "-C1"],
                format!("{a}\n1:xx\n2-zz\n\n{b}\n\n{c}\n1-m\n3-m\n4:xx\n5-m\n--\n7-m\n\n{d}\n"),
            ),
        ] {
            tgrep()
                .args(backend)
                .args(["--stats", "--color", "never", "--sort", "path"])
                .args(["-U", "-r", "$1"])
                .args(&flags)
                .args(["--", r"(x+)\n|y+\n"])
                .arg(&root)
                .assert()
                .success()
                .stdout(expected)
                .stderr(predicate::str::contains(marker));
        }
    });
}

/// Searching in parallel, ripgrep buffers each file's output and writes the
/// separator between files only before a buffer that holds some, so a file
/// whose rewrites all print nothing adds no `--`. With `--heading`, the path
/// it printed still earns a blank line. A gap within a file is still marked,
/// even right before a hidden block, so it can follow the file's own `--`.
#[test]
fn multiline_replace_hidden_files_add_no_parallel_separator() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    for (name, text) in [
        ("a.txt", "xx\nzz\n"),
        ("b.txt", "yy\n"),
        ("c.txt", "m\nyy\nm\nxx\nm\nm\nm\nyy\n"),
        ("d.txt", "yy\n"),
        ("e.txt", "xx\n"),
        ("f.txt", "yy\nm\nxx\n"),
        ("g.txt", "yy\nm\nm\nyy\n"),
    ] {
        fs::write(root.join(name), text).unwrap();
    }
    let path = |stem: &str| root.join(format!("{stem}.txt")).display().to_string();
    let [a, b, c, d, e, f, g] = ["a", "b", "c", "d", "e", "f", "g"].map(path);
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, joiner, mut files) in [
            (
                vec!["-n", "-C1"],
                "--\n",
                vec![
                    (&a, format!("{a}:1:xx\n{a}-2-zz\n")),
                    (
                        &c,
                        format!("{c}-1-m\n{c}-3-m\n{c}:4:xx\n{c}-5-m\n--\n{c}-7-m\n"),
                    ),
                    (&e, format!("{e}:1:xx\n")),
                    (&f, format!("{f}-2-m\n{f}:3:xx\n")),
                    (&g, format!("{g}-2-m\n{g}-3-m\n")),
                ],
            ),
            (
                vec!["-n", "-A1"],
                "--\n",
                vec![
                    (&a, format!("{a}:1:xx\n{a}-2-zz\n")),
                    (&c, format!("{c}-3-m\n{c}:4:xx\n{c}-5-m\n--\n")),
                    (&e, format!("{e}:1:xx\n")),
                    (&f, format!("{f}-2-m\n{f}:3:xx\n")),
                    (&g, format!("{g}-2-m\n--\n")),
                ],
            ),
            (
                vec!["-n", "-B1"],
                "--\n",
                vec![
                    (&a, format!("{a}:1:xx\n")),
                    (&c, format!("{c}-1-m\n{c}-3-m\n{c}:4:xx\n--\n{c}-7-m\n")),
                    (&e, format!("{e}:1:xx\n")),
                    (&f, format!("{f}-2-m\n{f}:3:xx\n")),
                    (&g, format!("--\n{g}-3-m\n")),
                ],
            ),
            (
                vec!["-n", "--heading", "-C1"],
                "\n",
                vec![
                    (&a, format!("{a}\n1:xx\n2-zz\n")),
                    (&b, format!("{b}\n")),
                    (&c, format!("{c}\n1-m\n3-m\n4:xx\n5-m\n--\n7-m\n")),
                    (&d, format!("{d}\n")),
                    (&e, format!("{e}\n1:xx\n")),
                    (&f, format!("{f}\n2-m\n3:xx\n")),
                    (&g, format!("{g}\n2-m\n3-m\n")),
                ],
            ),
        ] {
            // `-j2` keeps ripgrep's parallel behaviour on a single-CPU host.
            let output = tgrep()
                .args(backend)
                .args(["--stats", "--color", "never", "-j2"])
                .args(["-U", "-r", "$1"])
                .args(&flags)
                .args(["--", r"(x+)\n|y+\n"])
                .arg(&root)
                .assert()
                .success()
                .stderr(predicate::str::contains(marker))
                .get_output()
                .stdout
                .clone();
            let output = String::from_utf8(output).unwrap();
            // The file order is unspecified, so take it from the output.
            files.sort_by_key(|(path, _)| output.find(path.as_str()));
            let rows: Vec<&str> = files.iter().map(|(_, rows)| rows.as_str()).collect();
            assert_eq!(output, rows.join(joiner), "{marker} {flags:?}");
        }
    });
}

#[test]
fn reported_json_replace_keeps_source_text_beside_replacements() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.txt"), "hello\n").unwrap();
    fs::write(root.join("b.txt"), "say hello, hello\nbye\n").unwrap();
    let hit = |text: &str, replacement: &str, start: usize, end: usize| {
        serde_json::json!({
            "match": {"text": text}, "replacement": {"text": replacement},
            "start": start, "end": end,
        })
    };
    let event = |kind: &str, line: u64, offset: u64, text: &str, hits: Vec<serde_json::Value>| {
        serde_json::json!({"type": kind, "data": {
            "lines": {"text": text}, "line_number": line, "absolute_offset": offset,
            "submatches": hits,
        }})
    };
    let cases = [
        (
            vec!["-g", "a.txt", "-r", "R"],
            "(hello)",
            vec![event(
                "match",
                1,
                0,
                "hello\n",
                vec![hit("hello", "R", 0, 5)],
            )],
        ),
        (
            vec!["-g", "a.txt", "-r", "[$1]"],
            "(l+)",
            vec![event(
                "match",
                1,
                0,
                "hello\n",
                vec![hit("ll", "[ll]", 2, 4)],
            )],
        ),
        (
            vec!["-g", "a.txt", "-r", "XYZ"],
            "l|o",
            vec![event(
                "match",
                1,
                0,
                "hello\n",
                vec![
                    hit("l", "XYZ", 2, 3),
                    hit("l", "XYZ", 3, 4),
                    hit("o", "XYZ", 4, 5),
                ],
            )],
        ),
        (
            vec!["-g", "a.txt", "-r", ""],
            "hello",
            vec![event(
                "match",
                1,
                0,
                "hello\n",
                vec![hit("hello", "", 0, 5)],
            )],
        ),
        (
            vec!["-g", "b.txt", "-C1", "-r", "<$0>"],
            "hello",
            vec![
                event(
                    "match",
                    1,
                    0,
                    "say hello, hello\n",
                    vec![
                        hit("hello", "<hello>", 4, 9),
                        hit("hello", "<hello>", 11, 16),
                    ],
                ),
                event("context", 2, 17, "bye\n", vec![]),
            ],
        ),
    ];
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, pattern, expected) in &cases {
            let output = tgrep()
                .args(backend)
                .args(["--stats", "--json"])
                .args(flags)
                .arg("--")
                .arg(pattern)
                .arg(&root)
                .assert()
                .success()
                .stderr(predicate::str::contains(marker))
                .get_output()
                .stdout
                .clone();
            let events: Vec<serde_json::Value> = String::from_utf8(output)
                .unwrap()
                .lines()
                .map(|line| serde_json::from_str::<serde_json::Value>(line).unwrap())
                .filter(|event| event["type"] == "match" || event["type"] == "context")
                .map(|mut event| {
                    event["data"].as_object_mut().unwrap().remove("path");
                    event
                })
                .collect();
            assert_eq!(&events, expected, "{marker}: {flags:?}");
        }
    });
}

#[test]
fn indexed_json_preserves_utf8_match_and_context_offsets() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(
        root.join("offsets.txt"),
        "pr\u{e9}face\nbefore\ncaf\u{e9} needle needle\napr\u{e8}s\nneedle last\n",
    )
    .unwrap();
    let mut direct = Vec::new();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        let output = tgrep()
            .args(backend)
            .args(["--json", "--stats", "-F", "-C", "1", "--", "needle"])
            .arg(&root)
            .assert()
            .success()
            .get_output()
            .clone();
        assert!(String::from_utf8_lossy(&output.stderr).contains(marker));
        let rows: Vec<serde_json::Value> = String::from_utf8(output.stdout)
            .unwrap()
            .lines()
            .map(|line| serde_json::from_str(line).unwrap())
            .filter(|row: &serde_json::Value| row["type"] == "match" || row["type"] == "context")
            .collect();
        assert_eq!(rows.len(), 4);
        for (row, (kind, line, offset, text, spans)) in rows.iter().zip([
            ("context", 2, 9, "before\n", vec![]),
            (
                "match",
                3,
                16,
                "caf\u{e9} needle needle\n",
                vec![(6, 12), (13, 19)],
            ),
            ("context", 4, 36, "apr\u{e8}s\n", vec![]),
            ("match", 5, 43, "needle last\n", vec![(0, 6)]),
        ]) {
            assert_eq!(row["type"], kind);
            assert_eq!(row["data"]["line_number"], line);
            assert_eq!(row["data"]["absolute_offset"], offset);
            assert_eq!(row["data"]["lines"]["text"], text);
            let actual: Vec<_> = row["data"]["submatches"]
                .as_array()
                .unwrap()
                .iter()
                .map(|span| {
                    assert_eq!(span["match"]["text"], "needle");
                    (
                        span["start"].as_u64().unwrap(),
                        span["end"].as_u64().unwrap(),
                    )
                })
                .collect();
            assert_eq!(actual, spans);
        }
        if backend == ["--no-index"] {
            direct = rows;
        } else {
            assert_eq!(rows, direct, "{marker}");
        }
    });
}

#[test]
fn indexed_inline_case_flags_keep_candidates_selective() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(
        root.join("alpha.txt"),
        "SHELLSHOCK\n\u{17f}hell\u{17f}hoc\u{212a}\nPREFIXhelloSUFFIX\nprefixHELLOsuffix\n(?i)HeLLo\n",
    )
    .unwrap();
    fs::write(
        root.join("beta.txt"),
        "BaShDoOr\nba\u{17f}hdoor\nprefix\u{c9}suffix\nprefix\u{e9}suffix\n",
    )
    .unwrap();
    for i in 0..256 {
        fs::write(root.join(format!("decoy-{i}.txt")), "unrelated content\n").unwrap();
    }
    let cases: &[(&[&str], &str, usize)] = &[
        (&[], "(?i)shellshock|bashdoor", 2),
        (&["-i"], "shellshock|bashdoor", 2),
        (&["-P"], "(?i)shellshock|bashdoor", 2),
        (&["-i", "-P"], "shellshock|bashdoor", 2),
        (&["-P"], "(?i)(?<!//)shellshock|bashdoor", 2),
        (&[], "(?im)^shellshock|bashdoor", 2),
        (&[], "(?i:shellshock)|(?i:bashdoor)", 2),
        (&[], "PREFIX(?i:hello)SUFFIX", 1),
        (&[], "(?i)prefix(?-i:HELLO)suffix", 1),
        (&["-i"], "(?-i)HELLO", 1),
        (&[], "(?i)prefix\u{e9}suffix", 2),
        (&["-F"], "(?i)HeLLo", 1),
    ];
    let mut direct = Vec::new();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (i, &(flags, pattern, candidates)) in cases.iter().enumerate() {
            let output = tgrep()
                .args(backend)
                .args(flags)
                .args(["--stats", "--sort", "path", "--color", "never", "-c"])
                .args(["--", pattern, root.to_str().unwrap()])
                .assert()
                .success()
                .get_output()
                .clone();
            let stderr = String::from_utf8(output.stderr).unwrap();
            assert!(stderr.contains(marker), "{flags:?} {pattern}: {stderr}");
            if backend == ["--no-index"] {
                direct.push(output.stdout);
            } else {
                assert_eq!(output.stdout, direct[i], "{flags:?} {pattern}");
                // At most two of 258 files: exercise actual posting lookup and
                // masks, not just the existence of a non-MatchAll plan.
                assert!(
                    stderr.contains(&format!("raw candidates: {candidates}/258")),
                    "{flags:?} {pattern}: {stderr}"
                );
                assert!(!stderr.contains("no index narrowing"), "{stderr}");
            }
        }
    });
}

#[test]
fn indexed_fixed_strings_preserve_unicode_case_folds() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    for (name, content) in [
        ("upper_accent.txt", "CAF\u{c9}\n"),
        ("upper_fullwidth.txt", "\u{ff29}\u{ff24}\n"),
        ("long_s_kelvin.txt", "\u{17f}hell\u{17f}hoc\u{212a}\n"),
        ("short_fold.txt", "\u{17f}\u{212a}\u{17f}\n"),
        ("lower.txt", "caf\u{e9} \u{ff49}\u{ff44} shellshock sks\n"),
        ("literal.txt", "HELLO[.+](?i)\\END\n"),
        ("decoy.txt", "unrelated content\n"),
    ] {
        fs::write(root.join(name), content).unwrap();
    }
    let cases: &[(&[&str], &str, &[&str])] = &[
        (&["-i"], "caf\u{e9}", &["lower.txt", "upper_accent.txt"]),
        (&["-i"], "CAF\u{c9}", &["lower.txt", "upper_accent.txt"]),
        (
            &["-i"],
            "\u{ff49}\u{ff44}",
            &["lower.txt", "upper_fullwidth.txt"],
        ),
        (
            &["-i"],
            "\u{ff29}\u{ff24}",
            &["lower.txt", "upper_fullwidth.txt"],
        ),
        (&["-i"], "shellshock", &["long_s_kelvin.txt", "lower.txt"]),
        (&["-i"], "sks", &["lower.txt", "short_fold.txt"]),
        (&["-S"], "caf\u{e9}", &["lower.txt", "upper_accent.txt"]),
        (
            &["-S"],
            "\u{ff49}\u{ff44}",
            &["lower.txt", "upper_fullwidth.txt"],
        ),
        (&["-S"], "shellshock", &["long_s_kelvin.txt", "lower.txt"]),
        (&["-S"], "CAF\u{c9}", &["upper_accent.txt"]),
        (&[], "CAF\u{c9}", &["upper_accent.txt"]),
        (&[], "\u{ff29}\u{ff24}", &["upper_fullwidth.txt"]),
        (&["-i", "--no-unicode"], "shellshock", &["lower.txt"]),
        (&["-i"], r"hello[.+](?i)\end", &["literal.txt"]),
        (
            &["-i", "-e", "caf\u{e9}"],
            "shellshock",
            &["long_s_kelvin.txt", "lower.txt", "upper_accent.txt"],
        ),
        (
            &["-i", "-e", "\u{ff49}\u{ff44}"],
            "caf\u{e9}",
            &["lower.txt", "upper_accent.txt", "upper_fullwidth.txt"],
        ),
    ];
    let mut direct = Vec::new();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (i, &(flags, pattern, files)) in cases.iter().enumerate() {
            let mut cmd = tgrep();
            cmd.args(backend)
                .args(flags)
                .args(["-F", "-l", "--stats", "--sort", "path", "--color", "never"]);
            if flags.contains(&"-e") {
                cmd.args(["-e", pattern, "--", root.to_str().unwrap()]);
            } else {
                cmd.args(["--", pattern, root.to_str().unwrap()]);
            }
            let output = cmd.assert().success().get_output().clone();
            let stderr = String::from_utf8(output.stderr).unwrap();
            assert!(stderr.contains(marker), "{flags:?} {pattern}: {stderr}");
            let stdout = String::from_utf8(output.stdout).unwrap();
            let names: Vec<_> = stdout
                .lines()
                .map(|line| {
                    std::path::Path::new(line)
                        .file_name()
                        .unwrap()
                        .to_str()
                        .unwrap()
                })
                .collect();
            assert_eq!(names, files, "{backend:?} {flags:?} {pattern}");
            if backend == ["--no-index"] {
                direct.push(stdout);
            } else {
                assert_eq!(stdout, direct[i], "{backend:?} {flags:?} {pattern}");
            }
        }
    });
}

#[test]
fn indexed_stats_distinguish_full_corpus_candidates_from_server_transport() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(root.join("one.txt"), "common needle\n").unwrap();
    fs::write(root.join("two.txt"), "common haystack\n").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        if backend == ["--no-index"] {
            return;
        }
        for (pattern, raw, no_narrowing) in [
            (".", 2, true),
            ("common", 2, true),
            ("needle", 1, false),
            ("absent", 0, false),
        ] {
            for flags in [&[][..], &["-g", "one.txt"][..]] {
                let output = tgrep()
                    .args(backend)
                    .args(flags)
                    .args(["--stats", "--", pattern, root.to_str().unwrap()])
                    .assert()
                    .code(if raw == 0 { 1 } else { 0 })
                    .get_output()
                    .clone();
                let stderr = String::from_utf8(output.stderr).unwrap();
                assert!(stderr.contains(marker), "{stderr}");
                assert!(
                    stderr.contains(&format!("raw candidates: {raw}/2")),
                    "{stderr}"
                );
                assert_eq!(
                    stderr.contains("no index narrowing"),
                    no_narrowing,
                    "{stderr}"
                );
            }
        }
        tgrep()
            .args(backend)
            .args(["--", ".", root.to_str().unwrap()])
            .assert()
            .success()
            .stderr("");
    });
}

#[test]
fn indexed_candidate_stats_precede_query_size_limit() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    let scope = root.join("scope");
    fs::create_dir_all(scope.join("nested")).unwrap();
    for path in [
        root.join("outside.rs"),
        scope.join("small.rs"),
        scope.join("excluded.rs"),
        scope.join("wrong.txt"),
        scope.join(".hidden.rs"),
        scope.join("nested").join("deep.rs"),
    ] {
        fs::write(path, "needle\n").unwrap();
    }
    fs::write(scope.join("large.rs"), "needle\n".repeat(8)).unwrap();
    fs::write(scope.join("decoy.rs"), "haystack\n").unwrap();

    let cases: &[(&[&str], u64, usize)] = &[
        (&["--no-max-filesize"], 9, 2),
        (&["--max-filesize", "7"], 1, 1),
        (&["--max-filesize", "1"], 0, 0),
    ];
    let mut direct = Vec::new();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (i, &(size_flags, matched_lines, matched_files)) in cases.iter().enumerate() {
            let output = tgrep()
                .args(backend)
                .args(size_flags)
                .args([
                    "--stats",
                    "--sort",
                    "path",
                    "--color",
                    "never",
                    "-c",
                    "-t",
                    "rust",
                    "--glob",
                    "!excluded.rs",
                    "--max-depth",
                    "1",
                ])
                .args(["--", "needle", scope.to_str().unwrap()])
                .assert()
                .code(if matched_files == 0 { 1 } else { 0 })
                .get_output()
                .clone();
            let stderr = String::from_utf8_lossy(&output.stderr);
            assert!(stderr.contains(marker), "{size_flags:?}: {stderr}");
            assert_eq!(
                stats_totals(&output.stderr),
                [(matched_lines, matched_lines)]
            );
            assert_eq!(
                String::from_utf8_lossy(&output.stdout).lines().count(),
                matched_files
            );
            if backend == ["--no-index"] {
                direct.push(output.stdout);
            } else {
                assert_eq!(output.stdout, direct[i], "{backend:?} {size_flags:?}");
                assert!(
                    stderr.contains("(candidates: 2/8; raw candidates: 7/8)"),
                    "{backend:?} {size_flags:?}: {stderr}"
                );
            }
        }
    });
}

#[test]
fn indexed_server_returns_candidate_stats_only_when_requested() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(root.join("hit.txt"), "HeLLo\n").unwrap();
    fs::write(root.join("decoy.txt"), "unrelated\n").unwrap();
    let index_dir = dir.path().join("idx");
    let _server = start_passthru_server(&root, &index_dir);
    let info: serde_json::Value =
        serde_json::from_slice(&fs::read(index_dir.join("serve.json")).unwrap()).unwrap();
    let port = info["port"].as_u64().unwrap() as u16;
    for stats in [false, true] {
        let request = serde_json::json!({
            "jsonrpc": "2.0",
            "method": "search",
            "params": { "pattern": "(?i)hello", "stats": stats },
            "id": 1,
        });
        let response = send_rpc_request(port, &request.to_string()).unwrap();
        let response: serde_json::Value = serde_json::from_str(&response).unwrap();
        assert!(response.get("error").is_none(), "{response}");
        let result = &response["result"];
        assert_eq!(result["num_matches"], 1);
        if stats {
            assert_eq!(result["index_stats"]["raw_candidates"], 1);
            assert_eq!(result["index_stats"]["candidates"], 1);
            assert_eq!(result["index_stats"]["total_files"], 2);
            assert_eq!(result["index_stats"]["query_plan"], "AND(3 trigrams)");
        } else {
            assert!(result.get("index_stats").is_none(), "{result}");
        }
    }
}

#[test]
fn indexed_hidden_copilot_modes_keep_visibility_and_ignore_parity() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    let prefix = format!("{}/", root.to_string_lossy().replace('\\', "/"));
    let normalize = |path: &str| {
        let path = path.replace('\\', "/");
        path.strip_prefix(&prefix).unwrap().to_string()
    };
    for path in [".git", ".github/.nested", "ignored-dir"] {
        fs::create_dir_all(root.join(path)).unwrap();
    }
    fs::write(
        root.join(".gitignore"),
        "ignored.txt\n.ignored.txt\nignored-dir/\n",
    )
    .unwrap();
    let included = [
        "visible.txt",
        ".secret.txt",
        ".github/settings.txt",
        ".github/.nested/inner.txt",
    ];
    for path in
        included
            .iter()
            .copied()
            .chain(["ignored.txt", ".ignored.txt", "ignored-dir/child.txt"])
    {
        fs::write(root.join(path), "needle\n").unwrap();
    }

    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for hidden in [false, true] {
            for mode in [
                "content",
                "--files-with-matches",
                "--count",
                "--json",
                "--files",
            ] {
                let mut cmd = tgrep();
                cmd.current_dir(&root).args(backend).args([
                    "--stats",
                    "--glob",
                    "!.git",
                    "--with-filename",
                    "--no-heading",
                    "--color",
                    "never",
                ]);
                if hidden {
                    cmd.arg("--hidden");
                }
                if mode != "content" {
                    cmd.arg(mode);
                }
                cmd.arg("--");
                if mode != "--files" {
                    cmd.arg("needle");
                }
                let output = cmd.arg(&root).assert().success().get_output().clone();
                let diagnostic = if mode == "--files" {
                    match marker {
                        "Search completed" => "(via local index)",
                        "(via server)" => "(via server)",
                        _ => "(via filesystem walk)",
                    }
                } else {
                    marker
                };
                let stderr = String::from_utf8_lossy(&output.stderr);
                assert!(stderr.contains(diagnostic), "{backend:?} {mode}: {stderr}");
                if marker == "Search completed" && mode != "--files" {
                    assert!(stderr.contains("Query plan:"), "{stderr}");
                }

                let stdout = String::from_utf8_lossy(&output.stdout);
                let mut actual: Vec<String> = if mode == "--json" {
                    stdout
                        .lines()
                        .map(|line| serde_json::from_str::<serde_json::Value>(line).unwrap())
                        .filter(|row| row["type"] == "match")
                        .map(|row| normalize(row["data"]["path"]["text"].as_str().unwrap()))
                        .collect()
                } else {
                    stdout.lines().map(normalize).collect()
                };
                let mut expected: Vec<String> = included
                    .iter()
                    .filter(|path| hidden || **path == "visible.txt")
                    .map(|path| match mode {
                        "content" => format!("{path}:needle"),
                        "--count" => format!("{path}:1"),
                        _ => path.to_string(),
                    })
                    .collect();
                if hidden && mode == "--files" {
                    expected.push(".gitignore".to_string());
                }
                actual.sort();
                expected.sort();
                assert_eq!(actual, expected, "{backend:?} {mode}, hidden={hidden}");
            }
        }
    });
}

#[test]
fn indexed_hidden_legacy_and_partial_coverage_scan_until_server_upgrade() {
    let dir = setup_fixture();
    let root = dir.path().join("testdata");
    let prefix = format!("{}/", root.to_string_lossy().replace('\\', "/"));
    let normalize = |path: &str| {
        let path = path.replace('\\', "/");
        path.strip_prefix(&prefix).unwrap().to_string()
    };
    let index = dir.path().join("idx");
    fs::write(root.join("visible.txt"), "needle\n").unwrap();
    tgrep()
        .args([
            "index",
            root.to_str().unwrap(),
            "--index-path",
            index.to_str().unwrap(),
        ])
        .assert()
        .success();
    let meta_path = index.join("meta.json");
    let original: serde_json::Value =
        serde_json::from_slice(&fs::read(&meta_path).unwrap()).unwrap();
    assert_eq!(original["hidden_complete"], true);
    fs::write(root.join(".late.txt"), "needle\n").unwrap();

    for coverage in ["mismatched", "missing", "false", "partial"] {
        let mut meta = original.clone();
        match coverage {
            "mismatched" => {
                meta["file_table_id"] = serde_json::to_value([0u8; 32]).unwrap();
            }
            "missing" => {
                meta.as_object_mut().unwrap().remove("hidden_complete");
                meta.as_object_mut().unwrap().remove("visibility");
            }
            "false" => meta["hidden_complete"] = serde_json::json!(false),
            _ => meta["complete"] = serde_json::json!(false),
        }
        fs::write(&meta_path, serde_json::to_vec(&meta).unwrap()).unwrap();
        let output = tgrep()
            .args(["--index-path", index.to_str().unwrap()])
            .args([
                "--files-with-matches",
                "--hidden",
                "--glob",
                "!.git",
                "--with-filename",
                "--stats",
                "--",
                "needle",
            ])
            .arg(&root)
            .assert()
            .success()
            .stderr(predicate::str::contains("Brute-force search completed"))
            .get_output()
            .clone();
        let mut paths: Vec<_> = String::from_utf8(output.stdout)
            .unwrap()
            .lines()
            .map(normalize)
            .collect();
        paths.sort();
        assert_eq!(paths, [".late.txt", "visible.txt"], "{coverage}");
        tgrep()
            .args(["--index-path", index.to_str().unwrap()])
            .args(["--files", "--hidden", "--glob", "!.git", "--stats", "--"])
            .arg(&root)
            .assert()
            .success()
            .stdout(predicate::str::contains(".late.txt"))
            .stderr(predicate::str::contains("(via filesystem walk)"));
    }

    let server = start_passthru_server(&root, &index);
    let info: serde_json::Value =
        serde_json::from_slice(&fs::read(index.join("serve.json")).unwrap()).unwrap();
    let port = info["port"].as_u64().unwrap() as u16;
    let deadline = Instant::now() + Duration::from_secs(30);
    loop {
        let response =
            send_rpc_request(port, r#"{"jsonrpc":"2.0","method":"status","id":0}"#).unwrap();
        let status: serde_json::Value = serde_json::from_str(&response).unwrap();
        if status["result"]["hidden_complete"] == true {
            break;
        }
        assert!(
            Instant::now() < deadline,
            "coverage did not upgrade: {status}"
        );
        std::thread::sleep(Duration::from_millis(50));
    }
    let mut server = Some(server);
    for marker in ["(via server)", "Query plan:"] {
        if marker == "Query plan:" {
            drop(server.take());
        }
        let output = tgrep()
            .args(["--index-path", index.to_str().unwrap()])
            .args([
                "--files-with-matches",
                "--hidden",
                "--glob",
                "!.git",
                "--with-filename",
                "--sort",
                "path",
                "--stats",
                "--",
                "needle",
            ])
            .arg(&root)
            .assert()
            .success()
            .stderr(predicate::str::contains(marker))
            .stderr(predicate::str::contains("Brute-force search completed").not())
            .get_output()
            .clone();
        assert_eq!(
            String::from_utf8(output.stdout)
                .unwrap()
                .lines()
                .map(normalize)
                .collect::<Vec<_>>(),
            [".late.txt", "visible.txt"]
        );
    }
    let upgraded: serde_json::Value =
        serde_json::from_slice(&fs::read(meta_path).unwrap()).unwrap();
    assert_eq!(upgraded["complete"], true);
    assert_eq!(upgraded["hidden_complete"], true);
}

fn stats_totals(stderr: &[u8]) -> Vec<(u64, u64)> {
    let stderr = String::from_utf8_lossy(stderr);
    regex::Regex::new(r"(\d+) matches \((\d+) matched lines\)")
        .unwrap()
        .captures_iter(&stderr)
        .map(|c| (c[1].parse().unwrap(), c[2].parse().unwrap()))
        .collect()
}

fn stable_json_output(stdout: &[u8]) -> Vec<serde_json::Value> {
    String::from_utf8_lossy(stdout)
        .lines()
        .map(|line| {
            let mut event: serde_json::Value = serde_json::from_str(line).unwrap();
            if let Some(stats) = event["data"]["stats"].as_object_mut() {
                stats.remove("elapsed");
            }
            event["data"]
                .as_object_mut()
                .unwrap()
                .remove("elapsed_total");
            event
        })
        .collect()
}

#[test]
fn stats_count_matches_independently_of_count_and_file_output() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(root.join("counts.txt"), "hello hello\nhello\nbye\n").unwrap();

    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, expected, stdout) in [
            (vec!["-c"], (3, 2), Some("2")),
            (vec!["--count-matches"], (3, 2), Some("3")),
            (vec!["-l"], (3, 2), None),
            (vec!["-q"], (2, 1), Some("")),
            (vec!["-c", "-v"], (0, 1), Some("1")),
            (vec!["--count-matches", "-v"], (0, 1), Some("1")),
            (vec!["-l", "-v"], (0, 1), None),
            (vec!["-c", "-m", "1"], (2, 1), Some("1")),
            (vec!["--count-matches", "-m", "1"], (2, 1), Some("2")),
            (vec!["-l", "-m", "1"], (2, 1), None),
        ] {
            let output = tgrep()
                .args(backend)
                .args(["--stats", "--no-filename", "--color", "never"])
                .args(&flags)
                .args(["--", "hello", root.to_str().unwrap()])
                .assert()
                .success()
                .stderr(predicate::str::contains(marker))
                .get_output()
                .clone();
            assert_eq!(
                stats_totals(&output.stderr),
                [expected],
                "{backend:?} {flags:?}"
            );
            if let Some(stdout) = stdout {
                assert_eq!(String::from_utf8_lossy(&output.stdout).trim(), stdout);
            } else {
                assert!(String::from_utf8_lossy(&output.stdout).contains("counts.txt"));
            }
        }

        // This mode deliberately bypasses the server and stops after one hit
        // in each file, even though matching files produce no output.
        let output = tgrep()
            .args(backend)
            .args(["--stats", "--files-without-match", "--", "hello"])
            .arg(&root)
            .assert()
            .code(1)
            .stdout("")
            .get_output()
            .clone();
        assert_eq!(stats_totals(&output.stderr), [(2, 1)]);
    });
}

#[test]
fn stats_files_only_server_rpc_returns_one_marker_per_file() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(root.join("many.txt"), "hello hello\n".repeat(4096)).unwrap();
    fs::write(root.join("none.txt"), "goodbye\n").unwrap();
    let index_dir = dir.path().join("idx");
    let _server = start_passthru_server(&root, &index_dir);
    let info: serde_json::Value =
        serde_json::from_slice(&fs::read(index_dir.join("serve.json")).unwrap()).unwrap();
    let port = info["port"].as_u64().unwrap() as u16;
    for (limit, matches, lines) in [(None, 8192, 4096), (Some(1), 2, 1), (Some(0), 0, 0)] {
        let request = serde_json::json!({
            "jsonrpc": "2.0",
            "method": "search",
            "params": {
                "pattern": "hello",
                "files_only": true,
                "stats": true,
                "detail": true,
                "max_count": limit,
            },
            "id": 1,
        });
        let response = send_rpc_request(port, &request.to_string()).unwrap();
        let response: serde_json::Value = serde_json::from_str(&response).unwrap();
        assert!(response.get("error").is_none(), "{response}");
        let result = &response["result"];
        if matches == 0 {
            assert_eq!(result["matches"], serde_json::json!([]));
            assert_eq!(result["file_stats"], serde_json::json!([]));
        } else {
            assert_eq!(
                result["matches"],
                serde_json::json!([{"type": "match", "file": "many.txt"}])
            );
            assert_eq!(
                result["file_stats"],
                serde_json::json!([{
                    "file": "many.txt",
                    "matches": matches,
                    "matched_lines": lines,
                }])
            );
        }
        assert_eq!(result["num_matches"], if matches == 0 { 0 } else { 1 });
    }
    tgrep()
        .args(["--index-path", index_dir.to_str().unwrap(), "-l", "--stats"])
        .args(["--", "hello", root.to_str().unwrap()])
        .assert()
        .success()
        .stdout(format!("{}\n", root.join("many.txt").display()))
        .stderr(predicate::str::contains(
            "8192 matches (4096 matched lines)",
        ))
        .stderr(predicate::str::contains("(via server)"));
}

#[test]
fn stats_binary_file_counts_matches_on_both_sides_of_nul() {
    let dir = TempDir::new().unwrap();
    let file = dir.path().join("binary.txt");
    fs::write(&file, b"hello\0hello").unwrap();
    // ripgrep 15.2.0 reports both matches for a memory-mapped explicit file,
    // even though its JSON bytes_searched reports the NUL offset (5).
    for flags in [
        vec![],
        vec!["--count-matches"],
        vec!["--json"],
        vec!["--text"],
    ] {
        let output = tgrep()
            .args(["--no-index", "--stats"])
            .args(&flags)
            .args(["--", "hello"])
            .arg(&file)
            .assert()
            .success()
            .get_output()
            .clone();
        assert_eq!(stats_totals(&output.stderr), [(2, 1)], "{flags:?}");
    }
}

#[test]
fn stats_explicit_files_and_binary_notes_count_unrendered_matches() {
    let dir = TempDir::new().unwrap();
    for (name, contents) in [
        ("counts.txt", "hello hello\nhello\n"),
        ("binary.txt", "hello hello\nhello\n\0tail\n"),
    ] {
        let file = dir.path().join(name);
        fs::write(&file, contents).unwrap();
        for (flags, expected) in [
            (vec![], (3, 2)),
            (vec!["-c"], (3, 2)),
            (vec!["--count-matches"], (3, 2)),
            (vec!["-l"], (3, 2)),
            (vec!["-q"], (2, 1)),
            (vec!["--json"], (3, 2)),
        ] {
            let output = tgrep()
                .args(["--no-index", "--stats"])
                .args(&flags)
                .args(["--", "hello"])
                .arg(&file)
                .assert()
                .success()
                .get_output()
                .clone();
            assert_eq!(stats_totals(&output.stderr), [expected], "{name} {flags:?}");
            if name == "binary.txt" && flags.is_empty() {
                let stdout = String::from_utf8_lossy(&output.stdout);
                assert!(stdout.contains("binary file matches"));
                assert!(!stdout.contains("hello"));
            }
        }
    }
}

#[test]
fn stats_are_scoped_to_each_root_without_colliding_relative_paths() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    for (name, contents) in [
        ("one", "hello\n"),
        ("two", "hello\n"),
        ("empty", "goodbye\n"),
    ] {
        fs::create_dir_all(root.join(name)).unwrap();
        fs::write(root.join(name).join("a.txt"), contents).unwrap();
    }
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for json in [false, true] {
            let mut cmd = tgrep();
            cmd.args(backend).args(["--stats", "--color", "never"]);
            if json {
                cmd.arg("--json");
            }
            let output = cmd
                .args(["--", "hello"])
                .arg(root.join("one"))
                .arg(root.join("two"))
                .arg(root.join("empty"))
                .assert()
                .success()
                .stderr(predicate::str::contains(marker))
                .get_output()
                .clone();
            assert_eq!(stats_totals(&output.stderr), [(1, 1), (1, 1), (0, 0)]);
            if json {
                let stdout = String::from_utf8_lossy(&output.stdout);
                let events: Vec<serde_json::Value> = stdout
                    .lines()
                    .map(|line| serde_json::from_str(line).unwrap())
                    .collect();
                let summaries: Vec<_> = events.iter().filter(|e| e["type"] == "summary").collect();
                assert_eq!(summaries.len(), 1, "{stdout}");
                assert_eq!(events.last().unwrap()["type"], "summary");
                assert_eq!(summaries[0]["data"]["stats"]["matches"], 2);
                assert_eq!(summaries[0]["data"]["stats"]["matched_lines"], 2);
            }
        }
    });
}

#[test]
fn multiline_count_matches_uses_original_per_file_totals() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    for (name, contents) in [
        ("a.txt", "hello\nworld\n"),
        ("b.txt", "hello\nworld hello\nworld\nmiss\nhello\nworld\n"),
        ("adjacent.txt", "aa\n"),
        ("none.txt", "miss\n"),
        (
            "unicode.txt",
            "pr\u{e9}face\ncaf\u{e9}\n\u{4e16}\ncaf\u{e9}\n\u{4e16}\n",
        ),
    ] {
        fs::write(root.join(name), contents).unwrap();
    }
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for engine in ["default", "pcre2"] {
            for (pattern, flags, counts, totals) in [
                (r"hello\nworld", vec!["-g", "a.txt"], "a.txt:1\n", (1, 2)),
                (r"hello\nworld", vec![], "a.txt:1\nb.txt:3\n", (4, 7)),
                (r"hello\nworld", vec!["-m", "0"], "", (0, 0)),
                (
                    r"hello\nworld",
                    vec!["-m", "1"],
                    "a.txt:1\nb.txt:2\n",
                    (3, 5),
                ),
                (
                    r"hello\nworld",
                    vec!["-m", "2"],
                    "a.txt:1\nb.txt:3\n",
                    (4, 7),
                ),
                (r"hello\nworld", vec!["-o"], "a.txt:1\nb.txt:3\n", (4, 7)),
                (
                    r"hello\nworld",
                    vec!["--vimgrep"],
                    "a.txt:1\nb.txt:3\n",
                    (4, 7),
                ),
                (
                    r"hello\nworld",
                    vec!["--replace", ""],
                    "a.txt:1\nb.txt:3\n",
                    (4, 7),
                ),
                ("hello", vec!["-g", "a.txt"], "a.txt:1\n", (1, 1)),
                ("hello|world", vec!["-g", "a.txt"], "a.txt:2\n", (2, 2)),
                ("a", vec!["-g", "adjacent.txt"], "adjacent.txt:2\n", (2, 1)),
                (
                    "hello|world",
                    vec!["-g", "b.txt", "-m", "2"],
                    "b.txt:3\n",
                    (3, 2),
                ),
                (
                    "hello|world",
                    vec!["-g", "b.txt", "-v"],
                    "b.txt:1\n",
                    (0, 1),
                ),
                (
                    "hello",
                    vec!["-g", "b.txt", "-v", "-m", "2"],
                    "b.txt:2\n",
                    (0, 2),
                ),
                (r"\n", vec!["-g", "a.txt"], "a.txt:2\n", (2, 2)),
                ("caf\u{e9}\\n\u{4e16}", vec![], "unicode.txt:2\n", (2, 4)),
                ("unfindable", vec![], "", (0, 0)),
            ] {
                let expected: String = counts
                    .lines()
                    .map(|line| format!("{}/{line}\n", root.to_string_lossy().replace('\\', "/")))
                    .collect();
                for stats in [false, true] {
                    let mut cmd = tgrep();
                    cmd.args(backend)
                        .args(["-U", "--count-matches", "--engine", engine])
                        .args([
                            "--sort",
                            "path",
                            "--color",
                            "never",
                            "--path-separator",
                            "/",
                        ])
                        .args(&flags);
                    if stats {
                        cmd.arg("--stats");
                    }
                    let output = cmd
                        .args(["--", pattern])
                        .arg(&root)
                        .assert()
                        .code(if counts.is_empty() { 1 } else { 0 })
                        .get_output()
                        .clone();
                    assert_eq!(
                        String::from_utf8_lossy(&output.stdout),
                        expected,
                        "{backend:?} {engine} {pattern:?} {flags:?} stats={stats}"
                    );
                    let stderr = String::from_utf8_lossy(&output.stderr);
                    if stats {
                        assert!(stderr.contains(marker), "{stderr}");
                        assert_eq!(stats_totals(&output.stderr), [totals], "{stderr}");
                        if marker != "Brute-force search completed" {
                            assert!(!stderr.contains("Brute-force"), "{stderr}");
                        }
                        if marker == "Search completed" {
                            assert!(!stderr.contains("(via server)"), "{stderr}");
                        }
                        assert!(!stderr.contains("falling back"), "{stderr}");
                    } else {
                        assert!(stderr.is_empty(), "{stderr}");
                    }
                }
            }
        }
    });
}

#[test]
fn server_count_matches_returns_totals_without_stats() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.txt"), "hello\nworld\n").unwrap();
    fs::write(root.join("b.txt"), "hello\nworld\nhello\nworld\n").unwrap();
    let repeats = 32 * 1024;
    fs::write(
        root.join("count-heavy.txt"),
        format!("{}\nb\n", "a".repeat(repeats)),
    )
    .unwrap();
    fs::write(
        root.join("line-heavy.txt"),
        "return return return\nmiss\n".repeat(4096),
    )
    .unwrap();
    let index_dir = dir.path().join("idx");
    let _server = start_passthru_server(&root, &index_dir);
    let info: serde_json::Value =
        serde_json::from_slice(&fs::read(index_dir.join("serve.json")).unwrap()).unwrap();
    let port = info["port"].as_u64().unwrap() as u16;
    for stats in [false, true] {
        for count_field in [None, Some("count"), Some("count_matches")] {
            let mut request = serde_json::json!({
                "jsonrpc": "2.0", "method": "search", "id": 1,
                "params": {
                    "pattern": "hello\\nworld", "multiline": true,
                    "stats": stats, "detail": false,
                },
            });
            if let Some(field) = count_field {
                request["params"][field] = serde_json::json!(true);
            }
            let response: serde_json::Value =
                serde_json::from_str(&send_rpc_request(port, &request.to_string()).unwrap())
                    .unwrap();
            assert!(response.get("error").is_none(), "{response}");
            let result = &response["result"];
            assert_eq!(result["hidden_complete"], true);
            assert_eq!(
                result["num_matches"],
                if count_field.is_some() { 2 } else { 6 }
            );
            assert_eq!(result.get("index_stats").is_some(), stats);
            if stats || count_field == Some("count_matches") {
                let mut totals = result["file_stats"].as_array().unwrap().clone();
                totals.sort_by_key(|s| s["file"].as_str().unwrap().to_string());
                assert_eq!(
                    totals,
                    [
                        serde_json::json!({"file":"a.txt","matches":1,"matched_lines":2}),
                        serde_json::json!({"file":"b.txt","matches":2,"matched_lines":4}),
                    ]
                );
            } else {
                assert!(result.get("file_stats").is_none());
            }
        }
    }
    for engine in ["default", "pcre2"] {
        for stats in [false, true] {
            for (path, pattern, multiline, matches, lines, field) in [
                ("count-heavy.txt", "a", false, repeats, 1, "count_matches"),
                (
                    "count-heavy.txt",
                    r"a|\nb",
                    true,
                    repeats + 1,
                    2,
                    "count_matches",
                ),
                ("line-heavy.txt", "return", false, 3 * 4096, 4096, "count"),
                (
                    "line-heavy.txt",
                    "return",
                    false,
                    3 * 4096,
                    4096,
                    "count_matches",
                ),
            ] {
                let request = serde_json::json!({
                    "jsonrpc": "2.0", "method": "search", "id": 1,
                    "params": {
                        "pattern": pattern, "multiline": multiline, "engine": engine,
                        "glob": [path], field: true,
                        "stats": stats, "detail": false,
                    },
                });
                let raw = send_rpc_request(port, &request.to_string()).unwrap();
                assert!(raw.len() < 4 * 1024, "count response: {} bytes", raw.len());
                let response: serde_json::Value = serde_json::from_str(&raw).unwrap();
                assert!(response.get("error").is_none(), "{response}");
                let result = &response["result"];
                assert_eq!(result["hidden_complete"], true);
                assert_eq!(result.get("index_stats").is_some(), stats);
                if stats || field == "count_matches" {
                    assert_eq!(
                        result["file_stats"],
                        serde_json::json!([{
                            "file":path,"matches":matches,"matched_lines":lines,
                        }])
                    );
                } else {
                    assert!(result.get("file_stats").is_none());
                }
                let rows = result["matches"].as_array().unwrap();
                let expected = if field == "count" {
                    serde_json::json!({"type":"count","file":path,"lines":lines})
                } else {
                    serde_json::json!({"type":"match","file":path})
                };
                assert_eq!(rows, &[expected]);
            }
        }
    }
    let legacy = serde_json::json!({
        "jsonrpc":"2.0","method":"search","id":1,
        "params":{"pattern":"a","glob":["count-heavy.txt"]},
    });
    let raw = send_rpc_request(port, &legacy.to_string()).unwrap();
    assert!(raw.len() > 40 * 1024);
    let response: serde_json::Value = serde_json::from_str(&raw).unwrap();
    assert!(response.get("error").is_none(), "{response}");
    assert!(response["result"].get("file_stats").is_none());
    assert_eq!(
        response["result"]["matches"][0]["spans"]
            .as_array()
            .unwrap()
            .len(),
        repeats
    );
}

#[test]
fn count_matches_rejects_old_or_incomplete_server_totals_before_output() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.txt"), "hello\nworld\n").unwrap();
    fs::write(root.join("b.txt"), "hello\nworld\nhello\nworld\n").unwrap();
    let index_dir = dir.path().join("idx");
    tgrep()
        .args([
            "index",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
        ])
        .assert()
        .success();
    let mut cases: Vec<_> = [
        ("-c", None),
        ("--count-matches", None),
        ("--count-matches", Some(serde_json::json!(null))),
        ("--count-matches", Some(serde_json::json!([]))),
        (
            "--count-matches",
            Some(serde_json::json!([
                {"file":"a.txt","matches":1,"matched_lines":2},
            ])),
        ),
        (
            "--count-matches",
            Some(serde_json::json!([
                {"file":"a.txt","matches":1,"matched_lines":2},
                {"file":"b.txt","matches":2},
            ])),
        ),
        (
            "--count-matches",
            Some(serde_json::json!([
                {"file":"a.txt","matches":1,"matched_lines":2},
                {"file":"a.txt","matches":1,"matched_lines":2},
                {"file":"b.txt","matches":2,"matched_lines":4},
            ])),
        ),
    ]
    .into_iter()
    .map(|(flag, metadata)| (flag, metadata, None))
    .collect();
    for invalid in [
        serde_json::json!({"type":"count","file":"b.txt"}),
        serde_json::json!({"type":"count","file":"b.txt","lines":-1}),
        serde_json::json!({"type":"count","lines":4}),
        serde_json::json!({"type":"count","file":"a.txt","lines":4}),
        serde_json::json!({"type":"match","file":"b.txt","line":1}),
    ] {
        cases.push((
            "-c",
            None,
            Some(vec![
                serde_json::json!({"type":"count","file":"a.txt","lines":999}),
                invalid,
            ]),
        ));
    }
    for (flag, metadata, projected) in cases {
        for stats in [false, true] {
            let listener = std::net::TcpListener::bind(("127.0.0.1", 0)).unwrap();
            listener.set_nonblocking(true).unwrap();
            fs::write(
                index_dir.join("serve.json"),
                serde_json::json!({"pid":std::process::id(),"port":listener.local_addr().unwrap().port()})
                    .to_string(),
            )
            .unwrap();
            let output = std::thread::scope(|scope| {
                let server = scope.spawn(|| {
                    let deadline = Instant::now() + Duration::from_secs(30);
                    let mut stream = loop {
                        match listener.accept() {
                            Ok((stream, _)) => break stream,
                            Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => {
                                assert!(Instant::now() < deadline, "client did not contact server");
                                std::thread::sleep(Duration::from_millis(10));
                            }
                            Err(error) => panic!("accept: {error}"),
                        }
                    };
                    stream.set_nonblocking(false).unwrap();
                    stream.set_read_timeout(Some(Duration::from_secs(30))).unwrap();
                    stream.set_write_timeout(Some(Duration::from_secs(30))).unwrap();
                    let mut line = String::new();
                    BufReader::new(&stream).read_line(&mut line).unwrap();
                    let request: serde_json::Value = serde_json::from_str(&line).unwrap();
                    assert_eq!(request["params"].get("count_matches").is_some(), flag != "-c");
                    assert_eq!(request["params"].get("count").is_some(), flag == "-c");
                    assert_eq!(request["params"]["stats"], stats);
                    assert_eq!(request["params"]["detail"], flag == "-c" && stats);
                    let rows = projected.clone().unwrap_or_else(|| {
                        [("a.txt", 2), ("b.txt", 4)]
                            .into_iter()
                            .flat_map(|(file, lines)| (1..=lines).map(move |line| {
                                serde_json::json!({"file":file,"line":line,"spans":[[0,5]],"type":"match"})
                            }))
                            .collect()
                    });
                    let mut result = serde_json::json!({
                        "hidden_complete":true,"matches":rows,"elapsed_ms":1,
                    });
                    if let Some(metadata) = &metadata {
                        result["file_stats"] = metadata.clone();
                    }
                    writeln!(stream, "{}", serde_json::json!({"jsonrpc":"2.0","id":1,"result":result})).unwrap();
                });
                let mut cmd = tgrep();
                cmd.timeout(Duration::from_secs(30))
                    .args(["--index-path", index_dir.to_str().unwrap()])
                    .args(["-U", flag, "--no-filename", "--sort", "path"]);
                if stats {
                    cmd.arg("--stats");
                }
                if projected.is_some() {
                    cmd.args(["--max-depth", "1"]);
                }
                let output = cmd
                    .args(["--", r"hello\nworld"])
                    .arg(&root)
                    .output()
                    .unwrap();
                server.join().unwrap();
                output
            });
            assert!(output.status.success(), "{output:?}");
            assert_eq!(
                String::from_utf8_lossy(&output.stdout),
                if flag == "-c" { "2\n4\n" } else { "1\n2\n" },
                "{flag} {metadata:?} stats={stats}"
            );
            let stderr = String::from_utf8_lossy(&output.stderr);
            if flag == "-c" && projected.is_none() {
                assert!(!stderr.contains("falling back"), "{stderr}");
                if stats {
                    assert_eq!(stats_totals(&output.stderr), [(6, 6)]);
                }
            } else {
                assert!(
                    stderr.contains(if projected.is_some() {
                        "count"
                    } else {
                        "match totals"
                    }),
                    "{stderr}"
                );
                assert!(stderr.contains("falling back to local index"), "{stderr}");
                assert!(!stderr.contains("(via server)"), "{stderr}");
                if stats {
                    assert_eq!(stats_totals(&output.stderr), [(3, 6)]);
                    assert!(stderr.contains("Search completed"), "{stderr}");
                }
            }
        }
    }
}

#[test]
fn ordered_filters_and_replacements_reject_servers_without_support() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("a.rs"), "needle\n").unwrap();
    fs::write(root.join("a.txt"), "needle\n").unwrap();
    fs::write(root.join("m.txt"), "hello\nworld\n").unwrap();
    let index_dir = dir.path().join("idx");
    tgrep()
        .args([
            "index",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
        ])
        .assert()
        .success();
    let rs = format!("{}\n", root.join("a.rs").display());
    let txt = format!("{}\n", root.join("a.txt").display());
    let stale = "STALE hello needle\n".repeat(3);
    // Flags, pattern, the request fields the result depends on, why the
    // client rejects a reply that does not acknowledge them (`None` when an
    // older server's reply is just as good), and the output (`None` for JSON).
    for (flags, pattern, fields, reason, expected) in [
        (
            vec!["-l", "-T", "rust", "-t", "rust"],
            "needle",
            &["type_ops", "ordered_filters"][..],
            Some("ordered type and glob filters"),
            Some(rs.as_str()),
        ),
        (
            vec!["-l", "-t", "rust", "-g", "*.txt"],
            "needle",
            &["ordered_filters"][..],
            Some("ordered type and glob filters"),
            Some(txt.as_str()),
        ),
        (
            vec!["--no-filename", "-U", "-r", "X"],
            r"hello\nworld",
            &["multiline_replace"][..],
            Some("multiline replacement blocks"),
            Some("X\n"),
        ),
        (
            vec!["--json", "-g", "m.txt", "-r", "R"],
            "(hello)",
            &["report_replacements"][..],
            Some("JSON replacements"),
            None,
        ),
        (
            vec!["--json"],
            "needle",
            &[][..],
            Some("JSON search statistics"),
            None,
        ),
        // Definitions that no `-t`/`-T` consumes are not sent at all, so an
        // older server cannot rebuild them in its own order and reject them.
        (
            vec![
                "--no-filename",
                "--type-add",
                "foo:include:rust",
                "--type-clear",
                "rust",
            ],
            "needle",
            &[][..],
            None,
            Some(stale.as_str()),
        ),
        // A pattern that cannot match a line terminator prints line by line
        // either way, and JSON without submatches has nothing to report.
        (
            vec!["--no-filename", "-U", "-r", "X"],
            "needle",
            &[][..],
            None,
            Some(stale.as_str()),
        ),
        (
            vec!["--json", "-v", "-r", "R"],
            "needle",
            &[][..],
            None,
            None,
        ),
        (
            vec!["--json", "-q", "-r", "R"],
            "needle",
            &[][..],
            None,
            None,
        ),
    ] {
        let listener = std::net::TcpListener::bind(("127.0.0.1", 0)).unwrap();
        listener.set_nonblocking(true).unwrap();
        fs::write(
            index_dir.join("serve.json"),
            serde_json::json!({"pid":std::process::id(),"port":listener.local_addr().unwrap().port()})
                .to_string(),
        )
        .unwrap();
        let output = std::thread::scope(|scope| {
            let server = scope.spawn(|| {
                let deadline = Instant::now() + Duration::from_secs(30);
                let mut stream = loop {
                    match listener.accept() {
                        Ok((stream, _)) => break stream,
                        Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => {
                            assert!(Instant::now() < deadline, "client did not contact server");
                            std::thread::sleep(Duration::from_millis(10));
                        }
                        Err(error) => panic!("accept: {error}"),
                    }
                };
                stream.set_nonblocking(false).unwrap();
                stream
                    .set_read_timeout(Some(Duration::from_secs(30)))
                    .unwrap();
                stream
                    .set_write_timeout(Some(Duration::from_secs(30)))
                    .unwrap();
                let mut line = String::new();
                BufReader::new(&stream).read_line(&mut line).unwrap();
                let request: serde_json::Value = serde_json::from_str(&line).unwrap();
                // New fields are sent only when the result depends on them.
                for name in [
                    "type_ops",
                    "ordered_filters",
                    "multiline_replace",
                    "report_replacements",
                ] {
                    assert_eq!(
                        request["params"].get(name).is_some(),
                        fields.contains(&name),
                        "{name}: {request}"
                    );
                }
                if !flags.iter().any(|flag| matches!(*flag, "-t" | "-T")) {
                    for name in ["types", "types_not", "type_add", "type_clear"] {
                        assert_eq!(
                            request["params"][name],
                            serde_json::json!([]),
                            "{name}: {request}"
                        );
                    }
                }
                // A server that predates them ignores the fields and answers
                // the old way, without acknowledging them. Inverted lines
                // carry no spans.
                let spans = if request["params"]["invert_match"] == true {
                    serde_json::json!([])
                } else {
                    serde_json::json!([[6, 11]])
                };
                let rows: Vec<_> = ["a.rs", "a.txt", "m.txt"]
                    .into_iter()
                    .map(|file| {
                        serde_json::json!({
                            "file":file,"line":1,"content":"STALE hello needle",
                            "spans":spans,"type":"match",
                        })
                    })
                    .collect();
                let mut result = serde_json::json!({
                    "hidden_complete":true,"matches":rows,"elapsed_ms":1,
                });
                assert_eq!(
                    request["params"].get("search_stats").is_some(),
                    flags.contains(&"--json")
                );
                if flags.contains(&"--json") && reason != Some("JSON search statistics") {
                    result["search_stats"] = serde_json::json!([
                        {"file":"a.rs","bytes_searched":7,"binary_offset":null},
                        {"file":"a.txt","bytes_searched":7,"binary_offset":null},
                        {"file":"m.txt","bytes_searched":12,"binary_offset":null}
                    ]);
                }
                writeln!(
                    stream,
                    "{}",
                    serde_json::json!({"jsonrpc":"2.0","id":1,"result":result})
                )
                .unwrap();
            });
            let output = tgrep()
                .timeout(Duration::from_secs(30))
                .args(["--index-path", index_dir.to_str().unwrap()])
                .args(["--stats", "--color", "never", "--sort", "path"])
                .args(&flags)
                .args(["--", pattern])
                .arg(&root)
                .output()
                .unwrap();
            server.join().unwrap();
            output
        });
        assert!(output.status.success(), "{flags:?}: {output:?}");
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        let Some(reason) = reason else {
            assert!(!stderr.contains("falling back"), "{flags:?}: {stderr}");
            assert!(stderr.contains("(via server)"), "{flags:?}: {stderr}");
            match expected {
                Some(expected) => assert_eq!(stdout, expected, "{flags:?}"),
                None => {
                    assert!(stdout.contains(r#""type":"summary""#), "{stdout}");
                    assert!(!stdout.contains("replacement"), "{stdout}");
                    // `-q` prints only the summary.
                    assert_eq!(stdout.contains("STALE"), !flags.contains(&"-q"), "{stdout}");
                }
            }
            continue;
        };
        assert!(stderr.contains(reason), "{flags:?}: {stderr}");
        assert!(
            stderr.contains("falling back to local index"),
            "{flags:?}: {stderr}"
        );
        assert!(stderr.contains("Search completed"), "{flags:?}: {stderr}");
        assert!(!stderr.contains("(via server)"), "{flags:?}: {stderr}");
        assert!(!stdout.contains("STALE"), "{flags:?}: {stdout}");
        match expected {
            Some(expected) => assert_eq!(stdout, expected, "{flags:?}"),
            None if reason == "JSON search statistics" => {
                let rows = stable_json_output(&output.stdout);
                let summary = rows.iter().find(|row| row["type"] == "summary").unwrap();
                assert_eq!(summary["data"]["stats"]["searches"], 2);
                assert_eq!(summary["data"]["stats"]["bytes_searched"], 14);
                assert_eq!(summary["data"]["stats"]["matches"], 2);
            }
            None => assert!(stdout.contains(r#""replacement":{"text":"R"}"#), "{stdout}"),
        }
    }
}

#[test]
fn stats_multiline_counts_original_matches_before_rendering() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(
        root.join("multiline.txt"),
        "hello\nworld hello\nworld\nmiss\nhello\nworld\n",
    )
    .unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, expected) in [
            (vec![], (3, 5)),
            (vec!["-o"], (3, 5)),
            (vec!["--json"], (3, 5)),
            (vec!["--vimgrep"], (3, 5)),
            (vec!["--replace", ""], (3, 5)),
            (vec!["--trim"], (3, 5)),
            (vec!["-C", "1"], (3, 5)),
            (vec!["-m", "1", "-C", "2"], (2, 3)),
            (vec!["-m", "1", "--vimgrep"], (2, 3)),
            (vec!["-c"], (3, 5)),
            (vec!["--count-matches"], (3, 5)),
            (vec!["--count-matches", "-m", "1"], (2, 3)),
            (vec!["-l"], (3, 5)),
            (vec!["-q"], (2, 3)),
        ] {
            let output = tgrep()
                .args(backend)
                .args(["--stats", "-U", "--color", "never"])
                .args(&flags)
                .args(["--", r"hello\r?\nworld", root.to_str().unwrap()])
                .assert()
                .success()
                .stderr(predicate::str::contains(marker))
                .get_output()
                .clone();
            assert_eq!(
                stats_totals(&output.stderr),
                [expected],
                "{backend:?} {flags:?}"
            );
            let without_stats = tgrep()
                .args(backend)
                .args(["-U", "--color", "never"])
                .args(&flags)
                .args(["--", r"hello\r?\nworld", root.to_str().unwrap()])
                .assert()
                .success()
                .get_output()
                .stdout
                .clone();
            if flags.contains(&"--json") {
                assert_eq!(
                    stable_json_output(&output.stdout),
                    stable_json_output(&without_stats)
                );
            } else {
                assert_eq!(output.stdout, without_stats, "{backend:?} {flags:?}");
                let count = if flags.contains(&"--count-matches") {
                    Some(expected.0)
                } else if flags.contains(&"-c") {
                    Some(expected.1)
                } else {
                    None
                };
                if let Some(count) = count {
                    assert_eq!(
                        String::from_utf8_lossy(&output.stdout),
                        format!("{}:{count}\n", root.join("multiline.txt").display())
                    );
                }
            }
        }
        let output = tgrep()
            .args(backend)
            .args(["--stats", "-U", "-m", "0", "--", r"hello\r?\nworld"])
            .arg(&root)
            .assert()
            .code(1)
            .stdout("")
            .get_output()
            .clone();
        assert_eq!(stats_totals(&output.stderr), [(0, 0)]);
    });
}

#[test]
fn stats_scope_depth_filters_and_quiet_early_exit_apply_to_server_totals() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    let scope = root.join("scope");
    fs::create_dir_all(scope.join("nested")).unwrap();
    fs::write(scope.join("a.txt"), "hello hello\nbye\nhello\n").unwrap();
    fs::write(scope.join("b.txt"), "hello\n").unwrap();
    fs::write(scope.join("zero.txt"), "bye\n").unwrap();
    fs::write(scope.join("nested").join("deep.txt"), "hello\n").unwrap();
    fs::write(root.join("outside.txt"), "hello\n").unwrap();
    fs::write(scope.join("binary.txt"), "hello\0hello\n").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (flags, expected) in [
            (vec!["--max-depth", "1"], (4, 3)),
            (vec!["--max-depth", "1", "-q"], (2, 1)),
            (
                vec![
                    "-g",
                    "!b.txt",
                    "-g",
                    "!zero.txt",
                    "-g",
                    "!nested",
                    "-g",
                    "!binary.txt",
                    "--stop-on-nonmatch",
                ],
                (2, 1),
            ),
            (
                vec![
                    "-g",
                    "!a.txt",
                    "-g",
                    "!b.txt",
                    "-g",
                    "!nested",
                    "-g",
                    "!binary.txt",
                ],
                (0, 0),
            ),
        ] {
            let output = tgrep()
                .args(backend)
                .args(["--stats", "--sort", "path", "--color", "never"])
                .args(&flags)
                .args(["--", "hello"])
                .arg(&scope)
                .assert()
                .code(if expected.1 == 0 { 1 } else { 0 })
                .stderr(predicate::str::contains(marker))
                .get_output()
                .clone();
            assert_eq!(
                stats_totals(&output.stderr),
                [expected],
                "{backend:?} {flags:?}"
            );
        }
        // `--include-zero` deliberately bypasses the server.
        let output = tgrep()
            .args(backend)
            .args([
                "--stats",
                "-c",
                "--include-zero",
                "-g",
                "zero.txt",
                "--",
                "hello",
            ])
            .arg(&scope)
            .assert()
            .code(1)
            .stdout(predicate::str::contains("zero.txt:0"))
            .get_output()
            .clone();
        assert_eq!(stats_totals(&output.stderr), [(0, 0)]);
    });
}

#[test]
fn stats_ignore_trim_replacement_and_adjacent_span_merging() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(root.join("spans.txt"), "  hello hello\n").unwrap();
    with_stats_backends(&root, &dir.path().join("idx"), |backend, marker| {
        for (pattern, flags, expected) in [
            (" +", vec!["--trim"], (2, 1)),
            (" +", vec!["--trim", "--json"], (2, 1)),
            ("hello", vec!["-o", "--replace", ""], (2, 1)),
            ("hello", vec!["--replace", ""], (2, 1)),
            ("hello", vec!["--max-columns", "1"], (2, 1)),
            ("l", vec!["-U"], (4, 1)),
            ("l", vec!["-U", "-o"], (4, 1)),
            ("l", vec!["-U", "--vimgrep"], (4, 1)),
        ] {
            let output = tgrep()
                .args(backend)
                .args(["--stats", "--color", "never"])
                .args(&flags)
                .args(["--", pattern, root.to_str().unwrap()])
                .assert()
                .success()
                .stderr(predicate::str::contains(marker))
                .get_output()
                .clone();
            assert_eq!(
                stats_totals(&output.stderr),
                [expected],
                "{backend:?} {flags:?}"
            );
        }
    });
}

#[test]
fn supports_negative_lookahead_fallback() {
    let dir = setup_fixture();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "hello(?! world)",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "hello(?! there)",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello world"));
}

#[test]
fn files_mode_accepts_single_file_path() {
    let dir = setup_fixture();
    let hello = dir
        .path()
        .join("testdata")
        .join("hello.rs")
        .to_str()
        .unwrap()
        .to_string();

    tgrep()
        .args(["--files", &hello])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs"))
        .stdout(predicate::str::contains("lib.rs").not());
}

#[test]
fn files_mode_preserves_single_file_relative_path_for_globs() {
    let dir = setup_fixture();

    tgrep()
        .current_dir(dir.path())
        .args(["--files", "-g", "testdata/*", "testdata/hello.rs"])
        .assert()
        .success()
        .stdout(predicate::str::contains("testdata/hello.rs"))
        .stdout(predicate::str::contains("lib.rs").not());
}

#[test]
fn explicit_file_search_bypasses_hidden_walk_filter() {
    let dir = setup_fixture();
    let hidden = dir.path().join("testdata").join(".hidden.rs");
    fs::write(&hidden, "fn hidden_entry() {}\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-H",
            "hidden_entry",
            hidden.to_str().unwrap(),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains(".hidden.rs"));
}

// ─── --glob / -g (multiple) ───────────────────────────────────────────

#[test]
fn glob_single_pattern() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-g",
            "*.rs",
            "fn",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs"))
        .stdout(predicate::str::contains("lib.rs"))
        .stdout(predicate::str::contains("config.toml").not());
}

#[test]
fn glob_multiple_patterns() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-g",
            "*.rs",
            "-g",
            "*.toml",
            "fn|name",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs"))
        .stdout(predicate::str::contains("lib.rs"))
        .stdout(predicate::str::contains("config.toml"))
        .stdout(predicate::str::contains("notes.txt").not());
}

#[test]
fn glob_no_matches() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-g",
            "*.xyz",
            "fn",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1); // no files match glob, so no matches
}

// ─── -H / --with-filename (no-op, should be accepted) ────────────────

#[test]
fn with_filename_accepted() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-H",
            "fn main",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs"));
}

#[test]
fn with_filename_long_accepted() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--with-filename",
            "fn main",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs"));
}

// ─── --no-filename ───────────────────────────────────────────────────

#[test]
fn no_filename_flat() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main()"));
    // filename should not appear in any output line
    assert!(!stdout.contains("hello.rs"));
}

#[test]
fn no_filename_count() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-c",
            "fn",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Should print counts without file prefixes
    assert!(!stdout.contains("hello.rs"));
    assert!(!stdout.contains("lib.rs"));
    // Counts should be present as bare numbers
    for line in stdout.lines() {
        assert!(
            line.trim().parse::<usize>().is_ok(),
            "expected bare count, got: {line}"
        );
    }
}

// ─── -n / --line-number (no-op, should be accepted) ──────────────────

#[test]
fn line_number_short_accepted() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-n",
            "fn main",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains(":1:"));
}

#[test]
fn line_number_long_accepted() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--line-number",
            "fn main",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains(":1:"));
}

// ─── -N / --no-line-number ──────────────────────────────────────────

#[test]
fn no_line_number_flat() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-N",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Should have file:content (no line number between them). The fixture path
    // is absolute, so split on the file suffix rather than the first colon.
    for line in stdout.lines() {
        let content = line
            .rsplit_once(".rs:")
            .map(|(_, c)| c)
            .unwrap_or_else(|| panic!("expected file:content, got: {line}"));
        assert!(
            content.starts_with("fn main"),
            "content should follow filename directly, got: {line}"
        );
    }
}

#[test]
fn no_line_number_long() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-line-number",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    for line in stdout.lines() {
        let content = line.rsplit_once(".rs:").map(|(_, c)| c).unwrap();
        assert!(content.starts_with("fn main"));
    }
}

#[test]
fn no_filename_and_no_line_number() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Should be just the content, no file prefix, no line number
    for line in stdout.lines() {
        assert_eq!(line.trim(), "fn main() {");
    }
}

// ─── -L / --files-without-match ─────────────────────────────────────

#[test]
fn files_without_match_short() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--files-without-match",
            "fn",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // hello.rs and lib.rs contain "fn", so they should NOT appear
    assert!(!stdout.contains("hello.rs"));
    assert!(!stdout.contains("lib.rs"));
    // config.toml and notes.txt do NOT contain "fn", so they should appear
    assert!(stdout.contains("config.toml"));
    assert!(stdout.contains("notes.txt"));
}

#[test]
fn files_without_match_long() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--files-without-match",
            "fn",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!stdout.contains("hello.rs"));
    assert!(!stdout.contains("lib.rs"));
    assert!(stdout.contains("config.toml"));
    assert!(stdout.contains("notes.txt"));
}

#[test]
fn files_without_match_all_match() {
    let dir = setup_fixture();
    // Every file contains a newline, so "." (any char) matches all files
    tgrep()
        .args([
            "--no-index",
            "--files-without-match",
            ".",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1) // no files without matches → exit 1
        .stdout(predicate::str::is_empty());
}

#[test]
fn files_without_match_none_match() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--files-without-match",
            "zzz_nonexistent_pattern_zzz",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // No file matches, so all files should be printed
    assert!(stdout.contains("hello.rs"));
    assert!(stdout.contains("lib.rs"));
    assert!(stdout.contains("config.toml"));
    assert!(stdout.contains("notes.txt"));
}

#[test]
fn files_without_match_with_glob() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--files-without-match",
            "-g",
            "*.rs",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Only .rs files considered; hello.rs matches "fn main", lib.rs does not
    assert!(!stdout.contains("hello.rs"));
    assert!(stdout.contains("lib.rs"));
    // Non-.rs files should not appear (filtered by glob)
    assert!(!stdout.contains("config.toml"));
    assert!(!stdout.contains("notes.txt"));
}

#[test]
fn files_without_match_handles_explicit_files_and_quiet_mode() {
    let dir = setup_fixture();
    let root = dir.path().join("testdata");
    fs::write(root.join("empty.txt"), "").unwrap();
    fs::write(root.join("binary.txt"), b"other\0text\n").unwrap();

    for (name, code) in [
        ("hello.rs", 1),
        ("notes.txt", 0),
        ("empty.txt", 0),
        ("binary.txt", 0),
    ] {
        let path = root.join(name);
        for quiet in [false, true] {
            let mut command = tgrep();
            command
                .args(["--no-index", "--files-without-match", "fn"])
                .arg(&path);
            if quiet {
                command.arg("--quiet");
            }
            let result = command.assert().code(code);
            if quiet || code == 1 {
                result.stdout(predicate::str::is_empty());
            } else {
                result.stdout(format!("{}\n", path.display()));
            }
        }
    }
}

// ─── -q / --quiet ───────────────────────────────────────────────────

#[test]
fn quiet_match_exits_zero() {
    let dir = setup_fixture();
    tgrep()
        .args(["--no-index", "-q", "fn main", &fixture_path(&dir)])
        .assert()
        .success()
        .stdout(predicate::str::is_empty());
}

#[test]
fn quiet_no_match_exits_one() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "-q",
            "zzz_nonexistent_zzz",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1)
        .stdout(predicate::str::is_empty());
}

#[test]
fn quiet_long_form() {
    let dir = setup_fixture();
    tgrep()
        .args(["--no-index", "--quiet", "fn", &fixture_path(&dir)])
        .assert()
        .success()
        .stdout(predicate::str::is_empty());
}

#[test]
fn quiet_no_stderr_on_match() {
    let dir = setup_fixture();
    tgrep()
        .args(["--no-index", "-q", "fn", &fixture_path(&dir)])
        .assert()
        .success()
        .stdout(predicate::str::is_empty())
        .stderr(predicate::str::is_empty());
}

// ─── Flag combinations ──────────────────────────────────────────────

#[test]
fn quiet_with_files_without_match() {
    let dir = setup_fixture();
    // -q -L: exit 0 if any file doesn't match, no output
    tgrep()
        .args([
            "--no-index",
            "-q",
            "--files-without-match",
            "fn main",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::is_empty());
}

#[test]
fn quiet_with_files_without_match_all_match() {
    let dir = setup_fixture();
    // Every file matches "." so -L finds nothing → exit 1
    tgrep()
        .args([
            "--no-index",
            "-q",
            "--files-without-match",
            ".",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1)
        .stdout(predicate::str::is_empty());
}

#[test]
fn no_filename_with_no_line_number_and_context() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-A",
            "1",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Should get content lines without file or line number prefixes
    assert!(stdout.contains("fn main() {"));
    assert!(stdout.contains("println!"));
    assert!(!stdout.contains("hello.rs"));
}

#[test]
fn glob_multiple_with_files_only() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "-l",
            "-g",
            "*.rs",
            "-g",
            "*.toml",
            ".",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello.rs"));
    assert!(stdout.contains("lib.rs"));
    assert!(stdout.contains("config.toml"));
    assert!(!stdout.contains("notes.txt"));
}

#[test]
fn files_without_match_exit_code_success() {
    let dir = setup_fixture();
    // "fn main" only matches hello.rs; lib.rs, config.toml, notes.txt don't
    tgrep()
        .args([
            "--no-index",
            "--files-without-match",
            "fn main",
            &fixture_path(&dir),
        ])
        .assert()
        .success(); // exit 0 because files without matches were found
}

#[test]
fn with_filename_and_no_filename_last_wins() {
    let dir = setup_fixture();
    // When both are specified, --no-filename should take effect
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-H",
            "--no-filename",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!stdout.contains("hello.rs"));
    assert!(stdout.contains("fn main()"));
}

// ─── count-files ────────────────────────────────────────────────────

#[test]
fn count_files_reports_correct_count() {
    let dir = setup_fixture();
    let output = tgrep()
        .args(["count-files", &fixture_path(&dir)])
        .output()
        .unwrap();
    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Fixture has 4 text files: hello.rs, lib.rs, config.toml, notes.txt
    assert_eq!(stdout.trim(), "4");
}

#[test]
fn count_files_stderr_has_details() {
    let dir = setup_fixture();
    let output = tgrep()
        .args(["count-files", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("4 text files"));
    assert!(stderr.contains("binary skipped"));
}

#[test]
fn count_files_skips_binary() {
    let dir = setup_fixture();
    // Add a binary file (by extension)
    fs::write(
        dir.path().join("testdata").join("image.png"),
        b"\x89PNG\r\n",
    )
    .unwrap();
    let output = tgrep()
        .args(["count-files", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Still 4 text files — png is skipped
    assert_eq!(stdout.trim(), "4");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("1 binary skipped"));
}

// ─── --exclude (index) ─────────────────────────────────────────────

/// Create a fixture with subdirectories to test --exclude during indexing.
fn setup_exclude_fixture() -> TempDir {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(root.join("src")).unwrap();
    fs::create_dir_all(root.join("vendor")).unwrap();
    fs::create_dir_all(root.join("third_party")).unwrap();
    fs::write(root.join("src/main.rs"), "fn main() { hello(); }").unwrap();
    fs::write(root.join("vendor/dep.rs"), "fn hello() { dep(); }").unwrap();
    fs::write(root.join("third_party/lib.rs"), "fn hello() { lib(); }").unwrap();
    fs::write(root.join("README.md"), "# hello project").unwrap();
    dir
}

#[test]
fn index_exclude_single_dir() {
    let dir = setup_exclude_fixture();
    let root = dir.path().join("testdata");
    let index_dir = dir.path().join("idx");

    // Build index excluding vendor
    tgrep()
        .args([
            "index",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
            "--exclude",
            "vendor",
        ])
        .assert()
        .success();

    // Search the index for "hello" — should find src/main.rs and third_party/lib.rs
    // but not vendor/dep.rs
    let output = tgrep()
        .args([
            "hello",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
            "-l",
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("src/main.rs") || stdout.contains("src\\main.rs"));
    assert!(stdout.contains("third_party/lib.rs") || stdout.contains("third_party\\lib.rs"));
    assert!(!stdout.contains("vendor"));
}

#[test]
fn index_exclude_multiple_dirs() {
    let dir = setup_exclude_fixture();
    let root = dir.path().join("testdata");
    let index_dir = dir.path().join("idx");

    // Build index excluding both vendor and third_party
    tgrep()
        .args([
            "index",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
            "--exclude",
            "vendor",
            "--exclude",
            "third_party",
        ])
        .assert()
        .success();

    // Search the index for "hello" — should only find src/main.rs and README.md
    let output = tgrep()
        .args([
            "hello",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
            "-l",
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("src/main.rs") || stdout.contains("src\\main.rs"));
    assert!(!stdout.contains("vendor"));
    assert!(!stdout.contains("third_party"));
}

// ─── serve lock ─────────────────────────────────────────────────────

#[test]
fn serve_rejects_second_server_on_same_index() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(root.join("hello.txt"), "hello world").unwrap();

    let index_dir = dir.path().join("idx");

    // Start first server in background using std::process::Command
    let tgrep_bin = assert_cmd::cargo::cargo_bin("tgrep");
    let mut server1 = std::process::Command::new(&tgrep_bin)
        .args([
            "serve",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
            "--no-watch",
        ])
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .unwrap();

    // Wait for server1 to be ready (serve.json written)
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
    while !index_dir.join("serve.json").exists() {
        assert!(
            std::time::Instant::now() < deadline,
            "server1 did not start in time"
        );
        std::thread::sleep(std::time::Duration::from_millis(100));
    }

    // Try to start second server on the same index — should fail
    tgrep()
        .args([
            "serve",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
            "--no-watch",
        ])
        .assert()
        .failure()
        .stderr(predicate::str::contains(
            "another tgrep server is already running",
        ));

    // Clean up: kill server1
    server1.kill().ok();
    server1.wait().ok();
}

#[test]
fn serve_rebuilds_when_existing_index_is_corrupted() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(&root).unwrap();
    fs::write(root.join("hello.txt"), "hello world").unwrap();

    let index_dir = dir.path().join("idx");
    fs::create_dir_all(&index_dir).unwrap();
    fs::write(index_dir.join("lookup.bin"), vec![0u8; 15]).unwrap();
    fs::write(index_dir.join("index.bin"), vec![0u8; 6]).unwrap();
    fs::write(index_dir.join("files.bin"), b"").unwrap();

    let tgrep_bin = assert_cmd::cargo::cargo_bin("tgrep");
    let mut server = std::process::Command::new(&tgrep_bin)
        .args([
            "serve",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
            "--no-watch",
        ])
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .unwrap();

    let serve_json = index_dir.join("serve.json");
    let deadline = Instant::now() + Duration::from_secs(10);
    let port = loop {
        if let Some(status) = server.try_wait().unwrap() {
            panic!("server exited before recovering corrupted index: {status}");
        }
        assert!(
            Instant::now() < deadline,
            "server did not start after corrupted index recovery"
        );
        if let Ok(data) = fs::read_to_string(&serve_json)
            && let Ok(info) = serde_json::from_str::<serde_json::Value>(&data)
            && let Some(port) = info.get("port").and_then(|v| v.as_u64())
            && TcpStream::connect(format!("127.0.0.1:{port}")).is_ok()
        {
            break port as u16;
        }
        std::thread::sleep(Duration::from_millis(100));
    };

    let deadline = Instant::now() + Duration::from_secs(30);
    loop {
        assert!(
            Instant::now() < deadline,
            "server did not finish rebuilding corrupted index"
        );
        let response = send_rpc_request(port, r#"{"jsonrpc":"2.0","method":"status","id":0}"#)
            .expect("status request failed");
        let status: serde_json::Value =
            serde_json::from_str(&response).expect("invalid status JSON");
        let indexing = status
            .pointer("/result/indexing")
            .and_then(|v| v.as_bool())
            .unwrap_or(true);
        if !indexing {
            break;
        }
        std::thread::sleep(Duration::from_millis(100));
    }

    let search_request = serde_json::json!({
        "jsonrpc": "2.0",
        "method": "search",
        "id": 1,
        "params": { "pattern": "hello" }
    })
    .to_string();
    let response = send_rpc_request(port, &search_request).expect("search request failed");
    let search: serde_json::Value = serde_json::from_str(&response).expect("invalid search JSON");
    assert!(
        search.get("error").is_none(),
        "search returned error: {search}"
    );
    assert_eq!(
        search
            .pointer("/result/num_matches")
            .and_then(|v| v.as_u64()),
        Some(1)
    );
    assert!(
        search
            .pointer("/result/matches")
            .and_then(|v| v.as_array())
            .is_some_and(|matches| matches.iter().any(|m| m
                .get("file")
                .and_then(|v| v.as_str())
                .is_some_and(|path| path == "hello.txt"))),
        "expected rebuilt index to find hello.txt, got: {search}"
    );

    server.kill().ok();
    let output = server.wait_with_output().unwrap();
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("existing index failed to load")
            && stderr.contains("rebuilding in background"),
        "expected corrupted-index recovery trace, got: {stderr}"
    );
}

// ─── Case-insensitive matching (-i / --ignore-case) ─────────────────

#[test]
fn case_insensitive_short_flag() {
    let dir = setup_fixture();
    // "FN" should not match without -i; should match with -i
    tgrep()
        .args(["--no-index", "--no-heading", "FN", &fixture_path(&dir)])
        .assert()
        .code(1);

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-i",
            "FN",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("fn main"))
        .stdout(predicate::str::contains("fn add"));
}

#[test]
fn case_insensitive_long_flag() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--ignore-case",
            "HELLO",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello world"));
}

// ─── Smart case (-S / --smart-case) ─────────────────────────────────

#[test]
fn smart_case_all_lowercase_is_insensitive() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    // Add a file with uppercase "FN" so we can verify smart-case actually
    // enables case-insensitive matching (lowercase pattern matches uppercase text).
    fs::write(sub.join("upper.rs"), "FN UPPER() {}\n").unwrap();

    // All-lowercase pattern → smart-case triggers case-insensitive mode,
    // so "fn" should match both lowercase "fn" and uppercase "FN".
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-S",
            "fn",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main"));
    assert!(stdout.contains("fn add"));
    assert!(
        stdout.contains("FN UPPER"),
        "smart-case should match uppercase FN with lowercase pattern, got: {stdout}"
    );
}

#[test]
fn smart_case_with_uppercase_is_sensitive() {
    let dir = setup_fixture();
    // Pattern has uppercase → case-sensitive; "FN" won't match "fn"
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-S",
            "FN",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
}

#[test]
fn smart_case_long_flag() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--smart-case",
            "fn",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("fn main"));
}

// ─── Fixed strings (-F / --fixed-strings) ───────────────────────────

#[test]
fn fixed_strings_short_flag() {
    let dir = setup_fixture();
    // "i32" is also valid regex, but let's test that regex metacharacters
    // are treated literally with -F.
    // "(a" is invalid regex but valid literal
    let sub = dir.path().join("testdata");
    fs::write(sub.join("parens.txt"), "call(a, b)\nno match\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-F",
            "(a",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("call(a, b)"));
}

#[test]
fn fixed_strings_long_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("special.txt"), "price is $10.00\nother line\n").unwrap();

    // "$10.00" contains regex metacharacters ($ and .)
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--fixed-strings",
            "$10.00",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("price is $10.00"));
}

#[test]
fn fixed_strings_dot_not_wildcard() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("dots.txt"), "a.b\nacb\naXb\n").unwrap();

    // Without -F, "a.b" matches "acb" and "aXb" too (. is wildcard)
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "a.b",
            sub.join("dots.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("a.b"));
    assert!(stdout.contains("acb"));

    // With -F, only literal "a.b" matches
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-F",
            "a.b",
            sub.join("dots.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("a.b"));
    assert!(!stdout.contains("acb"));
    assert!(!stdout.contains("aXb"));
}

// ─── Word boundary (-w / --word-regexp) ─────────────────────────────

#[test]
fn word_regexp_short_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(
        sub.join("words.txt"),
        "add the numbers\nadditional info\nadd\n",
    )
    .unwrap();

    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-w",
            "add",
            sub.join("words.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("add the numbers"));
    assert!(!stdout.contains("additional"));
}

#[test]
fn word_regexp_long_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("words2.txt"), "main function\nremainly\nmain\n").unwrap();

    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--word-regexp",
            "main",
            sub.join("words2.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("main function"));
    assert!(stdout.contains("main"));
    assert!(!stdout.contains("remainly"));
}

// ─── Invert match (-v / --invert-match) ─────────────────────────────

#[test]
fn invert_match_short_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-v",
            "fn",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Lines NOT containing "fn" should be printed
    assert!(stdout.contains("println!"));
    assert!(stdout.contains("}"));
    assert!(!stdout.contains("fn main"));
}

#[test]
fn invert_match_long_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--invert-match",
            "fn",
            sub.join("lib.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("a + b"));
    assert!(!stdout.contains("fn add"));
}

// ─── Only matching (-o / --only-matching) ───────────────────────────

#[test]
fn only_matching_short_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-o",
            "fn [a-z]+",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main"));
    // Should NOT print the full line including "() {"
    assert!(!stdout.contains("() {"));
}

#[test]
fn only_matching_long_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "--only-matching",
            r"\d+\.\d+\.\d+",
            sub.join("config.toml").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert_eq!(stdout.trim(), "0.1.0");
}

// ─── Max count (-m / --max-count) ───────────────────────────────────

#[test]
fn max_count_limits_matches_per_file() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(
        sub.join("many.txt"),
        "line1 match\nline2 match\nline3 match\nline4 match\n",
    )
    .unwrap();

    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-m",
            "2",
            "match",
            sub.join("many.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let match_lines: Vec<&str> = stdout.lines().collect();
    assert_eq!(match_lines.len(), 2, "expected 2 matches, got: {stdout}");
}

#[test]
fn max_count_long_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("many2.txt"), "a\nb\nc\nd\ne\n").unwrap();

    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "--max-count",
            "1",
            ".",
            sub.join("many2.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert_eq!(stdout.lines().count(), 1);
}

// ─── Count (-c / --count) ──────────────────────────────────────────

#[test]
fn count_short_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-c",
            "fn",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // hello.rs has 1 line with "fn"
    assert!(stdout.contains("1"), "expected count of 1, got: {stdout}");
}

#[test]
fn count_long_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--count",
            ".",
            sub.join("notes.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // notes.txt has 3 non-empty lines
    assert!(stdout.contains("3"), "expected count of 3, got: {stdout}");
}

// ─── Files with matches (-l / --files-with-matches) ─────────────────

#[test]
fn files_with_matches_short_flag() {
    let dir = setup_fixture();
    let output = tgrep()
        .args(["--no-index", "-l", "fn", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello.rs"));
    assert!(stdout.contains("lib.rs"));
    assert!(!stdout.contains("config.toml"));
    assert!(!stdout.contains("notes.txt"));
}

#[test]
fn files_with_matches_long_flag() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--files-with-matches",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello.rs"));
    assert!(!stdout.contains("lib.rs"));
}

// ─── Multiple patterns (-e / --regexp) ──────────────────────────────

#[test]
fn multiple_patterns_with_e_flag() {
    let dir = setup_fixture();
    // With -e in play, every positional is a path, so both patterns need -e.
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-e",
            "fn add",
            "-e",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main"));
    assert!(stdout.contains("fn add"));
}

#[test]
fn multiple_patterns_long_flag() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--regexp",
            "version",
            "--regexp",
            "hello",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello world"));
    assert!(stdout.contains("version"));
}

// ─── Pattern file (-f / --file) ─────────────────────────────────────

#[test]
fn pattern_file_short_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let pattern_file = sub.join("patterns.txt");
    // -f also makes every positional a path, so both patterns come from here.
    fs::write(&pattern_file, "version\nfn main\n").unwrap();

    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-f",
            pattern_file.to_str().unwrap(),
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main"));
    assert!(stdout.contains("version"));
}

// ─── Context lines (-A, -B, -C) ────────────────────────────────────

#[test]
fn after_context_short_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-A",
            "1",
            "fn main",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main() {"));
    assert!(stdout.contains("println!"));
}

#[test]
fn before_context_short_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-B",
            "1",
            "println",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main() {"));
    assert!(stdout.contains("println!"));
}

#[test]
fn context_short_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-C",
            "1",
            "println",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Should have before and after context
    assert!(stdout.contains("fn main() {"));
    assert!(stdout.contains("println!"));
    assert!(stdout.contains("}"));
}

#[test]
fn after_context_long_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "--after-context",
            "2",
            "fn main",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main() {"));
    assert!(stdout.contains("println!"));
    assert!(stdout.contains("}"));
}

#[test]
fn context_separator_between_disjoint_matches() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(
        sub.join("separated.txt"),
        "alpha\nbravo\ncharlie\ndelta\necho\nfoxtrot\n",
    )
    .unwrap();

    // Use -C 1 so context mode is triggered; matches at lines 1 and 6 are
    // far enough apart that a "--" separator should appear between groups.
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-C",
            "1",
            "alpha|foxtrot",
            sub.join("separated.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // There should be a "--" separator between the two disjoint match groups
    assert!(
        stdout.contains("--"),
        "expected context separator, got: {stdout}"
    );
    assert!(stdout.contains("alpha"));
    assert!(stdout.contains("foxtrot"));
}

// ─── JSON output (--json) ──────────────────────────────────────────

#[test]
fn json_output_flag() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--json",
            "fn main",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // ripgrep emits a begin/match.../end envelope per file, then a summary.
    let msgs: Vec<serde_json::Value> = stdout
        .lines()
        .map(|line| {
            serde_json::from_str(line).unwrap_or_else(|_| panic!("invalid JSON line: {line}"))
        })
        .collect();
    let kinds: Vec<&str> = msgs.iter().map(|m| m["type"].as_str().unwrap()).collect();
    assert_eq!(kinds.first(), Some(&"begin"), "stream: {kinds:?}");
    assert_eq!(kinds.last(), Some(&"summary"), "stream: {kinds:?}");
    assert!(kinds.contains(&"match"), "stream: {kinds:?}");
    assert!(kinds.contains(&"end"), "stream: {kinds:?}");

    for m in msgs.iter().filter(|m| m["type"] == "match") {
        assert!(m["data"]["line_number"].is_number());
        assert!(m["data"]["lines"]["text"].is_string());
        assert!(m["data"]["absolute_offset"].is_number());
        assert!(m["data"]["submatches"].is_array());
    }
}

#[test]
fn json_output_includes_file_and_line() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--json",
            "fn main",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let first_match: serde_json::Value = stdout
        .lines()
        .map(|l| serde_json::from_str::<serde_json::Value>(l).unwrap())
        .find(|m| m["type"] == "match")
        .expect("expected a match message");

    assert_eq!(first_match["data"]["line_number"], 1);
    let text = first_match["data"]["lines"]["text"].as_str().unwrap();
    assert!(text.contains("fn main"));
    // ripgrep includes the trailing newline in `lines.text`.
    assert!(text.ends_with('\n'), "expected trailing newline: {text:?}");

    let file = first_match["data"]["path"]["text"].as_str().unwrap();
    assert!(
        file.contains("hello.rs"),
        "expected hello.rs in path, got: {file}"
    );

    let submatches = first_match["data"]["submatches"].as_array().unwrap();
    assert_eq!(submatches.len(), 1);
    assert_eq!(submatches[0]["match"]["text"], "fn main");
    assert!(submatches[0]["start"].is_number());
    assert!(submatches[0]["end"].is_number());
}

#[test]
fn json_context_lines_have_context_type() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--json",
            "-A",
            "1",
            "fn main",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let kinds: Vec<String> = stdout
        .lines()
        .map(|l| {
            serde_json::from_str::<serde_json::Value>(l).unwrap()["type"]
                .as_str()
                .unwrap()
                .to_string()
        })
        .collect();
    assert_eq!(kinds[0], "begin", "stream: {kinds:?}");
    assert_eq!(kinds[1], "match", "stream: {kinds:?}");
    assert_eq!(kinds[2], "context", "stream: {kinds:?}");
}

// ─── Vimgrep output (--vimgrep) ────────────────────────────────────

#[test]
fn vimgrep_output_format() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    // Use current_dir so output paths are relative (avoids Windows C: colon issues)
    let output = tgrep()
        .current_dir(&sub)
        .args(["--no-index", "--vimgrep", "fn main", "hello.rs"])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Vimgrep format: file:line:col:content
    for line in stdout.lines() {
        assert!(
            line.contains("hello.rs"),
            "expected filename in vimgrep output, got: {line}"
        );
        // Extract line:col:content after the filename
        let after_file = line
            .strip_prefix("hello.rs:")
            .expect("expected hello.rs: prefix");
        let parts: Vec<&str> = after_file.splitn(3, ':').collect();
        assert_eq!(
            parts.len(),
            3,
            "expected line:col:content after filename, got: {after_file}"
        );
        assert!(
            parts[0].parse::<usize>().is_ok(),
            "expected line number, got: {}",
            parts[0]
        );
        assert!(
            parts[1].parse::<usize>().is_ok(),
            "expected column number, got: {}",
            parts[1]
        );
    }
}

#[test]
fn vimgrep_column_is_one_based() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("col.txt"), "hello world\n").unwrap();

    // Use current_dir so output paths are relative
    let output = tgrep()
        .current_dir(&sub)
        .args(["--no-index", "--vimgrep", "world", "col.txt"])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let line = stdout.lines().next().unwrap();
    let after_file = line
        .strip_prefix("col.txt:")
        .expect("expected col.txt: prefix");
    let parts: Vec<&str> = after_file.splitn(3, ':').collect();
    // "world" starts at column 7 (1-based)
    assert_eq!(parts[1], "7", "expected column 7, got: {}", parts[1]);
}

// ─── Trim (--trim) ────────────────────────────────────────────────

#[test]
fn trim_strips_whitespace() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(
        sub.join("indented.txt"),
        "    indented line\n  another indented\n",
    )
    .unwrap();

    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "--trim",
            "indented",
            sub.join("indented.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    for line in stdout.lines() {
        assert!(
            !line.starts_with(' '),
            "expected trimmed line, got: '{line}'"
        );
    }
    assert!(stdout.contains("indented line"));
    assert!(stdout.contains("another indented"));
}

// ─── Null separator (-0 / --null) ──────────────────────────────────

#[test]
fn null_separator_in_files_mode() {
    let dir = setup_fixture();
    let output = tgrep()
        .args(["--no-index", "-l", "-0", "fn", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Files should be separated by NUL bytes
    assert!(
        stdout.contains('\0'),
        "expected NUL separator in output, got: {stdout}"
    );
    // And should NOT have newlines as separators between filenames
    let filenames: Vec<&str> = stdout.split('\0').filter(|s| !s.is_empty()).collect();
    assert!(
        filenames.len() >= 2,
        "expected at least 2 files, got: {filenames:?}"
    );
}

#[test]
fn null_separator_long_flag() {
    let dir = setup_fixture();
    let output = tgrep()
        .args(["--no-index", "-l", "--null", "fn", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains('\0'));
}

// ─── Heading (--heading / --no-heading) ─────────────────────────────

#[test]
fn no_heading_outputs_flat_format() {
    let dir = setup_fixture();
    // Run from inside the fixture so printed paths are relative. An absolute
    // path would carry a drive-letter colon on Windows and silently supply the
    // extra field this test is looking for.
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .current_dir(&sub)
        .args(["--no-index", "--no-heading", "fn", "hello.rs", "lib.rs"])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!stdout.is_empty(), "expected matches");
    // Flat format prefixes every match with its filename rather than printing
    // the name once as a heading. ripgrep omits line numbers when stdout is not
    // a terminal and `-n` was not asked for, so the shape here is file:content.
    for line in stdout.lines() {
        let (file, content) = line
            .split_once(':')
            .unwrap_or_else(|| panic!("expected file:content in flat mode, got: {line}"));
        assert!(
            file == "hello.rs" || file == "lib.rs",
            "expected a filename prefix on every line, got: {line}"
        );
        assert!(
            content.contains("fn"),
            "expected the matching content after the filename, got: {line}"
        );
    }
}

#[test]
fn no_heading_with_line_numbers_is_file_line_content() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    // Two file arguments: naming exactly one file would suppress the filename,
    // leaving line:content.
    let output = tgrep()
        .current_dir(&sub)
        .args([
            "--no-index",
            "--no-heading",
            "-n",
            "fn",
            "hello.rs",
            "lib.rs",
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!stdout.is_empty(), "expected matches");
    for line in stdout.lines() {
        let parts: Vec<&str> = line.splitn(3, ':').collect();
        assert_eq!(
            parts.len(),
            3,
            "expected file:line:content once -n is given, got: {line}"
        );
        assert!(
            parts[0] == "hello.rs" || parts[0] == "lib.rs",
            "expected a filename prefix, got: {line}"
        );
        assert!(
            parts[1].parse::<usize>().is_ok(),
            "expected a line number, got: {}",
            parts[1]
        );
    }
}

// ─── Color (--color never) ─────────────────────────────────────────

#[test]
fn color_never_has_no_ansi_codes() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--color",
            "never",
            "fn",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        !stdout.contains("\x1b["),
        "expected no ANSI codes with --color never"
    );
}

// ─── Hidden files (--hidden) ───────────────────────────────────────

#[test]
fn hidden_flag_includes_dotfiles() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join(".hidden_file.txt"), "secret hidden content\n").unwrap();

    // Without --hidden, dot-files should be skipped
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "secret hidden",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);

    // With --hidden, dot-files should be found
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--hidden",
            "secret hidden",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("secret hidden content"));
}

// ─── No-ignore (--no-ignore) ───────────────────────────────────────

#[test]
fn no_ignore_includes_gitignored_files() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");

    // Initialize a git repo so .gitignore is respected
    let git_status = std::process::Command::new("git")
        .args(["init"])
        .current_dir(&sub)
        .output();
    let git_ok = git_status
        .as_ref()
        .map(|o| o.status.success())
        .unwrap_or(false);
    if !git_ok {
        eprintln!("skipping no_ignore test: git init failed or git not available");
        return;
    }

    fs::write(sub.join(".gitignore"), "ignored.txt\n").unwrap();
    fs::write(sub.join("ignored.txt"), "this is ignored content\n").unwrap();

    // Without --no-ignore, the gitignored file should be skipped
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "ignored content",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);

    // With --no-ignore, the gitignored file should be found
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-ignore",
            "ignored content",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("this is ignored content"));
}

// ─── Unrestricted (-u) ─────────────────────────────────────────────

#[test]
fn unrestricted_single_u_is_no_ignore() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");

    let git_status = std::process::Command::new("git")
        .args(["init"])
        .current_dir(&sub)
        .output();
    let git_ok = git_status
        .as_ref()
        .map(|o| o.status.success())
        .unwrap_or(false);
    if !git_ok {
        eprintln!("skipping unrestricted_single_u test: git init failed or git not available");
        return;
    }

    fs::write(sub.join(".gitignore"), "secret.txt\n").unwrap();
    fs::write(sub.join("secret.txt"), "unrestricted secret\n").unwrap();

    // -u = --no-ignore
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-u",
            "unrestricted secret",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("unrestricted secret"));
}

#[test]
fn unrestricted_double_u_includes_hidden() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join(".very_hidden.txt"), "double u content\n").unwrap();

    // -uu = --no-ignore + --hidden
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-uu",
            "double u content",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("double u content"));
}

// ─── Glob negation (!pattern) ──────────────────────────────────────

#[test]
fn glob_negation_excludes_files() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-g",
            "!*.toml",
            ".",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!stdout.contains("config.toml"));
    // Other files should still appear
    assert!(
        stdout.contains("hello.rs") || stdout.contains("lib.rs") || stdout.contains("notes.txt")
    );
}

// ─── Combined flag interactions ────────────────────────────────────

#[test]
fn case_insensitive_with_fixed_strings() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(
        sub.join("mixed.txt"),
        "Hello World\nhello world\nHELLO WORLD\n",
    )
    .unwrap();

    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-i",
            "-F",
            "hello world",
            sub.join("mixed.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert_eq!(
        stdout.lines().count(),
        3,
        "expected 3 case-insensitive matches, got: {stdout}"
    );
}

#[test]
fn word_regexp_with_case_insensitive() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(
        sub.join("wordcase.txt"),
        "Add numbers\nadditional\nADD\nadd\n",
    )
    .unwrap();

    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-w",
            "-i",
            "add",
            sub.join("wordcase.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("Add numbers"));
    assert!(stdout.contains("ADD"));
    assert!(stdout.contains("add"));
    assert!(!stdout.contains("additional"));
}

#[test]
fn invert_match_with_count() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    // hello.rs has 3 lines, 1 with "fn"
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-v",
            "-c",
            "fn",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // 3 total lines - 1 with fn = 2 non-matching
    assert!(
        stdout.contains("2"),
        "expected 2 inverted matches, got: {stdout}"
    );
}

#[test]
fn only_matching_with_count() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    // -o -c: count should still reflect number of matching lines
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-o",
            "-c",
            "fn",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("1"));
}

#[test]
fn max_count_with_files_only() {
    let dir = setup_fixture();
    // -m 1 -l: should still list all files that have at least 1 match
    let output = tgrep()
        .args(["--no-index", "-m", "1", "-l", "fn", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello.rs"));
    assert!(stdout.contains("lib.rs"));
}

#[test]
fn json_output_with_context() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .args([
            "--no-index",
            "--json",
            "-A",
            "1",
            "fn main",
            sub.join("hello.rs").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let mut has_match = false;
    let mut has_context = false;
    for line in stdout.lines() {
        let parsed: serde_json::Value = serde_json::from_str(line).unwrap();
        match parsed["type"].as_str().unwrap() {
            "match" => has_match = true,
            "context" => has_context = true,
            "begin" | "end" | "summary" => {}
            other => panic!("unexpected type: {other}"),
        }
    }
    assert!(has_match, "expected at least one match");
    assert!(has_context, "expected at least one context line");
}

#[test]
fn glob_with_invert_match_and_count() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-g",
            "*.rs",
            "-v",
            "-c",
            "fn",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Should only count in .rs files
    assert!(!stdout.contains("config.toml"));
    assert!(!stdout.contains("notes.txt"));
}

// ─── Exit codes ────────────────────────────────────────────────────

#[test]
fn exit_code_zero_on_match() {
    let dir = setup_fixture();
    tgrep()
        .args(["--no-index", "fn main", &fixture_path(&dir)])
        .assert()
        .success();
}

#[test]
fn exit_code_one_on_no_match() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "zzz_definitely_no_match_zzz",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
}

#[test]
fn invert_match_exit_code() {
    let dir = setup_fixture();
    // Every file has at least one line not matching "fn main"
    tgrep()
        .args(["--no-index", "-v", "fn main", &fixture_path(&dir)])
        .assert()
        .success();
}

// ─── Edge cases ────────────────────────────────────────────────────

#[test]
fn empty_file_no_matches() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("empty.txt"), "").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "anything",
            sub.join("empty.txt").to_str().unwrap(),
        ])
        .assert()
        .code(1);
}

#[test]
fn single_line_file() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("single.txt"), "only one line").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "only one",
            sub.join("single.txt").to_str().unwrap(),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("only one line"));
}

#[test]
fn regex_alternation() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-l",
            "hello|version",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello.rs"));
    assert!(stdout.contains("config.toml"));
}

#[test]
fn multiple_patterns_with_fixed_strings() {
    let dir = setup_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("special2.txt"), "a+b\nc+d\na*b\n").unwrap();

    // -F with both patterns via -e, since -e makes positionals paths.
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-N",
            "-F",
            "-e",
            "c+d",
            "-e",
            "a+b",
            sub.join("special2.txt").to_str().unwrap(),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("a+b"));
    assert!(stdout.contains("c+d"));
    assert!(!stdout.contains("a*b"));
}

#[test]
fn files_without_match_with_invert_match() {
    let dir = setup_fixture();
    // -v -L: files where ALL lines match the pattern (no non-matching lines)
    // Using "." which matches every non-empty line; files without match on -v
    // means files where every line matches "."
    let output = tgrep()
        .args([
            "--no-index",
            "-v",
            "--files-without-match",
            ".",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    // All our test files have content on every line, so -v "." finds no
    // non-matching lines, meaning no file "matches" inverted, so -L
    // lists them all.
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello.rs"));
    assert!(stdout.contains("lib.rs"));
}

// ═══════════════════════════════════════════════════════════════════════
// Indexed search tests
//
// These tests build a trigram index first and then run searches through
// the index path (no --no-index) to ensure that the same ripgrep-compatible
// flags work correctly when the index is used for file discovery.
// ═══════════════════════════════════════════════════════════════════════

/// Create a fixture with richer content for indexed tests (trigrams need
/// at least 3-char sequences to be useful).
fn setup_indexed_fixture() -> (TempDir, String) {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();

    fs::write(
        sub.join("hello.rs"),
        "fn main() {\n    println!(\"hello world\");\n}\n",
    )
    .unwrap();

    fs::write(
        sub.join("lib.rs"),
        "pub fn add(a: i32, b: i32) -> i32 {\n    a + b\n}\n",
    )
    .unwrap();

    fs::write(
        sub.join("config.toml"),
        "[package]\nname = \"test\"\nversion = \"0.1.0\"\n",
    )
    .unwrap();

    fs::write(
        sub.join("notes.txt"),
        "This is a note.\nNothing important here.\nJust some text.\n",
    )
    .unwrap();

    let index_dir = dir.path().join("idx");
    let root = sub.to_str().unwrap().to_string();

    // Build the index
    tgrep()
        .args(["index", &root, "--index-path", index_dir.to_str().unwrap()])
        .assert()
        .success();

    (dir, index_dir.to_str().unwrap().to_string())
}

/// Helper: get path to testdata inside the indexed fixture.
fn indexed_fixture_path(dir: &TempDir) -> String {
    dir.path().join("testdata").to_str().unwrap().to_string()
}

#[test]
fn indexed_basic_search() {
    let (dir, idx) = setup_indexed_fixture();
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "fn main",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs"));
}

#[test]
fn indexed_passthru_prints_no_match_and_exits_one() {
    let (dir, idx) = setup_indexed_fixture();

    tgrep()
        .args([
            "--index-path",
            &idx,
            "--no-heading",
            "--no-filename",
            "--passthru",
            "--stats",
            "-g",
            "!lib.rs",
            "-g",
            "!*.toml",
            "-g",
            "!*.txt",
            "does-not-exist",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .code(1)
        .stdout("fn main() {\n    println!(\"hello world\");\n}\n")
        .stderr(predicate::str::contains("Query plan: MatchAll"));
}

#[test]
fn indexed_passthru_emits_filtered_no_hit_files_beside_a_match() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    let scope = root.join("scope");
    fs::create_dir_all(&scope).unwrap();
    fs::write(root.join(".ignore"), "scope/ignored.rs\n").unwrap();
    fs::write(scope.join("hit.rs"), "actual needle\n").unwrap();
    fs::write(scope.join("miss.rs"), "eligible no hit\n").unwrap();
    fs::write(scope.join("ignored.rs"), "ignored no hit\n").unwrap();
    fs::write(scope.join("globbed.rs"), "glob no hit\n").unwrap();
    fs::write(scope.join("typed.txt"), "typed no hit\n").unwrap();
    fs::write(root.join("outside.rs"), "outside no hit\n").unwrap();

    let index_dir = dir.path().join("idx");
    tgrep()
        .args([
            "index",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
        ])
        .assert()
        .success();

    tgrep()
        .args([
            "--index-path",
            index_dir.to_str().unwrap(),
            "--no-heading",
            "--passthru",
            "-t",
            "rust",
            "-g",
            "!globbed.rs",
            "needle",
            scope.to_str().unwrap(),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("actual needle"))
        .stdout(predicate::str::contains("eligible no hit"))
        .stdout(predicate::str::contains("ignored no hit").not())
        .stdout(predicate::str::contains("glob no hit").not())
        .stdout(predicate::str::contains("typed no hit").not())
        .stdout(predicate::str::contains("outside no hit").not());
}

struct PassthruServer(std::process::Child);

impl Drop for PassthruServer {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}

fn start_passthru_server(root: &std::path::Path, index_dir: &std::path::Path) -> PassthruServer {
    let mut child = std::process::Command::new(assert_cmd::cargo::cargo_bin("tgrep"))
        .args([
            "serve",
            root.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
            "--no-watch",
        ])
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .spawn()
        .expect("failed to start tgrep serve");

    let deadline = Instant::now() + Duration::from_secs(30);
    let serve_json = index_dir.join("serve.json");
    let port = loop {
        if let Some(status) = child.try_wait().unwrap() {
            panic!("tgrep serve exited before becoming ready: {status}");
        }
        assert!(
            Instant::now() < deadline,
            "tgrep serve did not become ready"
        );
        if let Ok(data) = fs::read_to_string(&serve_json)
            && let Ok(info) = serde_json::from_str::<serde_json::Value>(&data)
            && let Some(port) = info.get("port").and_then(|v| v.as_u64())
            && TcpStream::connect(format!("127.0.0.1:{port}")).is_ok()
        {
            break port as u16;
        }
        std::thread::sleep(Duration::from_millis(100));
    };

    loop {
        assert!(
            Instant::now() < deadline,
            "tgrep serve did not finish indexing"
        );
        if let Ok(response) =
            send_rpc_request(port, r#"{"jsonrpc":"2.0","method":"status","id":0}"#)
            && let Ok(status) = serde_json::from_str::<serde_json::Value>(&response)
            && status.pointer("/result/indexing").and_then(|v| v.as_bool()) == Some(false)
        {
            break;
        }
        std::thread::sleep(Duration::from_millis(100));
    }

    PassthruServer(child)
}

#[test]
fn passthru_bypasses_server_for_scoped_no_match() {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    let scope = root.join("scope");
    fs::create_dir_all(&scope).unwrap();
    fs::write(scope.join("plain.txt"), "alpha\nbeta\n").unwrap();
    fs::write(root.join("outside.txt"), "must stay outside scope\n").unwrap();
    let index_dir = dir.path().join("idx");
    let _server = start_passthru_server(&root, &index_dir);

    tgrep()
        .args([
            "--index-path",
            index_dir.to_str().unwrap(),
            "--no-heading",
            "--no-filename",
            "--passthru",
            "--stats",
            "does-not-exist",
            scope.to_str().unwrap(),
        ])
        .assert()
        .code(1)
        .stdout("alpha\nbeta\n")
        .stderr(predicate::str::contains("Query plan: MatchAll"))
        .stderr(predicate::str::contains("(via server)").not())
        .stderr(predicate::str::contains("Server unreachable").not());
}

#[test]
fn passthru_max_count_zero_matches_ripgrep_across_search_paths() {
    let (dir, idx) = setup_indexed_fixture();
    let root = dir.path().join("testdata");
    let root = root.to_str().unwrap();

    let run = |index: Option<&str>, pattern: &str| {
        let mut cmd = tgrep();
        if let Some(index) = index {
            cmd.args(["--index-path", index]);
        } else {
            cmd.arg("--no-index");
        }
        cmd.args([
            "--no-heading",
            "--passthru",
            "--stats",
            "-g",
            "!lib.rs",
            "-g",
            "!*.toml",
            "-g",
            "!*.txt",
            "-m",
            "0",
            pattern,
            root,
        ])
        .output()
        .unwrap()
    };

    for pattern in ["fn main", "does-not-exist"] {
        let direct = run(None, pattern);
        assert_eq!(direct.status.code(), Some(1));
        assert!(direct.stdout.is_empty(), "direct output: {direct:?}");

        let indexed = run(Some(&idx), pattern);
        assert_eq!(indexed.status.code(), direct.status.code());
        assert_eq!(indexed.stdout, direct.stdout);
        assert!(
            String::from_utf8_lossy(&indexed.stderr).contains("Query plan:"),
            "search did not use the local index: {indexed:?}"
        );
    }

    let _server = start_passthru_server(std::path::Path::new(root), std::path::Path::new(&idx));
    for pattern in ["fn main", "does-not-exist"] {
        let server = run(Some(&idx), pattern);
        assert_eq!(server.status.code(), Some(1));
        assert!(server.stdout.is_empty(), "server output: {server:?}");
        assert!(
            String::from_utf8_lossy(&server.stderr).contains("(via server)"),
            "search did not use the server: {server:?}"
        );
    }
}

#[test]
fn indexed_case_insensitive() {
    let (dir, idx) = setup_indexed_fixture();
    // "FN" should not match without -i
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "FN MAIN",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .code(1);

    // With -i it should match
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-i",
            "FN MAIN",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("fn main"));
}

#[test]
fn indexed_fixed_strings() {
    let (dir, idx) = setup_indexed_fixture();
    let sub = dir.path().join("testdata");
    fs::write(sub.join("special.txt"), "price is $10.00\nother line\n").unwrap();

    // Rebuild index with the new file
    tgrep()
        .args(["index", &indexed_fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-F",
            "$10.00",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("price is $10.00"));
}

#[test]
fn indexed_word_boundary() {
    let (dir, idx) = setup_indexed_fixture();
    let sub = dir.path().join("testdata");
    fs::write(
        sub.join("words.txt"),
        "add the numbers\nadditional info\nadd\n",
    )
    .unwrap();

    tgrep()
        .args(["index", &indexed_fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let output = tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-w",
            "add",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("add the numbers"));
    assert!(!stdout.contains("additional"));
}

#[test]
fn indexed_invert_match() {
    let (dir, idx) = setup_indexed_fixture();
    // Search the directory but filter to hello.rs via glob
    let output = tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-v",
            "-g",
            "hello.rs",
            "fn",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("println!"));
    assert!(!stdout.contains("fn main"));
}

#[test]
fn indexed_files_with_matches() {
    let (dir, idx) = setup_indexed_fixture();
    let output = tgrep()
        .args([
            "--index-path",
            &idx,
            "-l",
            "fn",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello.rs"));
    assert!(stdout.contains("lib.rs"));
    assert!(!stdout.contains("config.toml"));
    assert!(!stdout.contains("notes.txt"));
}

#[test]
fn indexed_files_without_match() {
    let (dir, idx) = setup_indexed_fixture();
    let output = tgrep()
        .args([
            "--index-path",
            &idx,
            "--files-without-match",
            "fn",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!stdout.contains("hello.rs"));
    assert!(!stdout.contains("lib.rs"));
    assert!(stdout.contains("config.toml"));
    assert!(stdout.contains("notes.txt"));
}

#[test]
fn indexed_count() {
    let (dir, idx) = setup_indexed_fixture();
    let output = tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-c",
            "fn main",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Only hello.rs has "fn main" (1 match)
    assert!(
        stdout.contains(":1"),
        "expected count of 1 for fn main, got: {stdout}"
    );
}

#[test]
fn indexed_quiet_exit_codes() {
    let (dir, idx) = setup_indexed_fixture();
    // Match → exit 0
    tgrep()
        .args([
            "--index-path",
            &idx,
            "-q",
            "fn main",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::is_empty());

    // No match → exit 1
    tgrep()
        .args([
            "--index-path",
            &idx,
            "-q",
            "zzz_nonexistent_zzz",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .code(1)
        .stdout(predicate::str::is_empty());
}

#[test]
fn indexed_glob_filter() {
    let (dir, idx) = setup_indexed_fixture();
    let output = tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-g",
            "*.rs",
            "fn",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello.rs"));
    assert!(stdout.contains("lib.rs"));
    assert!(!stdout.contains("config.toml"));
}

#[test]
fn indexed_only_matching() {
    let (dir, idx) = setup_indexed_fixture();
    let output = tgrep()
        .args([
            "--no-heading",
            "--no-filename",
            "-N",
            "--index-path",
            &idx,
            "-o",
            "-g",
            "hello.rs",
            "fn [a-z]+",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main"));
    assert!(!stdout.contains("() {"));
}

#[test]
fn indexed_max_count() {
    let (dir, idx) = setup_indexed_fixture();
    let sub = dir.path().join("testdata");
    fs::write(
        sub.join("many.txt"),
        "line1 match\nline2 match\nline3 match\nline4 match\n",
    )
    .unwrap();

    tgrep()
        .args(["index", &indexed_fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let output = tgrep()
        .args([
            "--no-heading",
            "--no-filename",
            "-N",
            "--index-path",
            &idx,
            "-m",
            "2",
            "-g",
            "many.txt",
            "match",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert_eq!(
        stdout.lines().count(),
        2,
        "expected 2 matches, got: {stdout}"
    );
}

#[test]
fn indexed_context_lines() {
    let (dir, idx) = setup_indexed_fixture();
    let output = tgrep()
        .args([
            "--no-heading",
            "--no-filename",
            "-N",
            "--index-path",
            &idx,
            "-A",
            "1",
            "-g",
            "hello.rs",
            "fn main",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("fn main() {"));
    assert!(stdout.contains("println!"));
}

#[test]
fn indexed_json_output() {
    let (dir, idx) = setup_indexed_fixture();
    let output = tgrep()
        .args([
            "--index-path",
            &idx,
            "--json",
            "-g",
            "hello.rs",
            "fn main",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let mut saw_match = false;
    for line in stdout.lines() {
        let parsed: serde_json::Value =
            serde_json::from_str(line).unwrap_or_else(|_| panic!("invalid JSON: {line}"));
        if parsed["type"] == "match" {
            saw_match = true;
            assert!(parsed["data"]["line_number"].is_number());
            assert!(
                parsed["data"]["lines"]["text"]
                    .as_str()
                    .unwrap()
                    .contains("fn main")
            );
        }
    }
    assert!(saw_match, "expected a match message in: {stdout}");
}

#[test]
fn indexed_smart_case() {
    let (dir, idx) = setup_indexed_fixture();
    // All-lowercase pattern → case-insensitive (matches "fn main")
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-S",
            "fn main",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("fn main"));

    // Pattern with uppercase → case-sensitive (no match)
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-S",
            "FN MAIN",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .code(1);
}

#[test]
fn indexed_no_filename_no_line_number() {
    let (dir, idx) = setup_indexed_fixture();
    let output = tgrep()
        .args([
            "--no-heading",
            "--no-filename",
            "-N",
            "--index-path",
            &idx,
            "-g",
            "hello.rs",
            "fn main",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    for line in stdout.lines() {
        assert_eq!(line.trim(), "fn main() {");
    }
}

// ─── Large files, binary files and encodings ───────────────────────
//
// These cover cases where tgrep used to silently return no results, which is
// far worse than an error: a search that finds nothing looks like a clean bill
// of health.

/// A file above the old hard-coded 1 MiB walker cap.
fn setup_large_file_fixture() -> TempDir {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();

    let mut big = String::with_capacity(1_200_000);
    while big.len() < 1_200_000 {
        big.push_str("filler line that is not interesting\n");
    }
    big.push_str("needle_in_a_big_file\n");
    fs::write(sub.join("big.txt"), big).unwrap();
    dir
}

#[test]
fn searches_files_larger_than_one_mib() {
    let dir = setup_large_file_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "needle_in_a_big_file",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("needle_in_a_big_file"));
}

#[test]
fn max_filesize_excludes_large_files() {
    let dir = setup_large_file_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--max-filesize",
            "1K",
            "needle_in_a_big_file",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
}

#[test]
fn max_filesize_accepts_suffixes() {
    let dir = setup_large_file_fixture();
    // 2M is above the 1.2 MB fixture, so the match must still be found.
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--max-filesize",
            "2M",
            "needle_in_a_big_file",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0);
}

#[test]
fn invalid_max_filesize_is_an_error_not_a_silent_fallback() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--max-filesize",
            "notanumber",
            "fn main",
            &fixture_path(&dir),
        ])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("max-filesize"));
}

#[test]
fn text_flag_searches_binary_files() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("blob.bin"), b"prefix\x00binary_needle\x00suffix").unwrap();

    // Without -a the file is skipped as binary.
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "binary_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);

    // With -a it is searched, and reported without dumping raw bytes.
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-a",
            "binary_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("binary_needle"));
}

#[test]
fn unrestricted_uuu_enables_binary_search() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("blob.bin"), b"prefix\x00binary_needle\x00suffix").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-uuu",
            "binary_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0);
}

#[test]
fn searches_files_that_are_not_valid_utf8() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    // Latin-1 encoded "café" followed by an ASCII marker.
    fs::write(sub.join("latin1.txt"), b"caf\xe9 latin_needle\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "latin_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("latin_needle"));
}

// ─── Multiline (-U / --multiline-dotall) ───────────────────────────

fn setup_multiline_fixture() -> TempDir {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("span.txt"), "alpha\nstart\nmiddle\nend\nomega\n").unwrap();
    dir
}

#[test]
fn multiline_matches_across_lines() {
    let dir = setup_multiline_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-U",
            r"start\nmiddle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("start"))
        .stdout(predicate::str::contains("middle"));
}

#[test]
fn multiline_alone_does_not_make_dot_match_newline() {
    let dir = setup_multiline_fixture();
    // ripgrep requires --multiline-dotall for this; -U alone must not match.
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-U",
            "start.middle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
}

#[test]
fn multiline_dotall_makes_dot_match_newline() {
    let dir = setup_multiline_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--multiline-dotall",
            "start.middle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("start"));
}

#[test]
fn non_multiline_anchors_per_line() {
    let dir = setup_multiline_fixture();
    // `^middle` must match line 3 even though it is not the start of the file.
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "^middle$",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("middle"));
}

// ─── Per-match output (--vimgrep, -o, --color) ─────────────────────

fn setup_repeats_fixture() -> TempDir {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("repeats.txt"), "foo bar foo baz foo\n").unwrap();
    dir
}

#[test]
fn vimgrep_emits_one_row_per_match() {
    let dir = setup_repeats_fixture();
    let sub = dir.path().join("testdata");
    let output = tgrep()
        .current_dir(&sub)
        .args(["--no-index", "--vimgrep", "foo", "repeats.txt"])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let rows: Vec<&str> = stdout.lines().collect();
    assert_eq!(rows.len(), 3, "expected one row per match, got: {stdout}");

    // Columns are 1-based byte offsets of each match: "foo bar foo baz foo".
    let cols: Vec<&str> = rows.iter().map(|r| r.split(':').nth(2).unwrap()).collect();
    assert_eq!(cols, vec!["1", "9", "17"], "rows: {stdout}");
}

#[test]
fn only_matching_prints_one_line_per_match() {
    let dir = setup_repeats_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-o",
            "foo",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let rows: Vec<&str> = stdout.lines().filter(|l| !l.is_empty()).collect();
    assert_eq!(rows.len(), 3, "expected 3 output lines, got: {stdout}");
    for row in rows {
        assert!(row.ends_with("foo"), "unexpected row: {row}");
    }
}

#[test]
fn color_always_highlights_the_match() {
    let dir = setup_repeats_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--color",
            "always",
            "bar",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("\x1b[1;31mbar\x1b[0m"),
        "expected the match itself to be colored, got: {stdout:?}"
    );
}

#[test]
fn color_never_leaves_output_plain() {
    let dir = setup_repeats_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--color",
            "never",
            "bar",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!stdout.contains('\x1b'), "unexpected escapes: {stdout:?}");
}

#[test]
fn json_submatches_cover_every_match_on_a_line() {
    let dir = setup_repeats_fixture();
    let output = tgrep()
        .args(["--no-index", "--json", "foo", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    let m: serde_json::Value = stdout
        .lines()
        .map(|l| serde_json::from_str::<serde_json::Value>(l).unwrap())
        .find(|m| m["type"] == "match")
        .expect("expected a match message");
    let subs = m["data"]["submatches"].as_array().unwrap();
    assert_eq!(subs.len(), 3, "expected 3 submatches, got: {subs:?}");
    assert_eq!(subs[0]["start"], 0);
    assert_eq!(subs[1]["start"], 8);
    assert_eq!(subs[2]["start"], 16);
}

// ─── Glob case sensitivity ─────────────────────────────────────────

fn setup_case_glob_fixture() -> TempDir {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("lower.txt"), "needle\n").unwrap();
    fs::write(sub.join("UPPER.TXT"), "needle\n").unwrap();
    dir
}

#[test]
fn globs_are_case_sensitive_by_default() {
    let dir = setup_case_glob_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-g",
            "*.txt",
            "needle",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("lower.txt"), "got: {stdout}");
    assert!(!stdout.contains("UPPER.TXT"), "got: {stdout}");
}

#[test]
fn iglob_matches_case_insensitively() {
    let dir = setup_case_glob_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--iglob",
            "*.txt",
            "needle",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("lower.txt"), "got: {stdout}");
    assert!(stdout.contains("UPPER.TXT"), "got: {stdout}");
}

#[test]
fn glob_case_insensitive_flag_applies_to_globs() {
    let dir = setup_case_glob_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--glob-case-insensitive",
            "-g",
            "*.txt",
            "needle",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("UPPER.TXT"), "got: {stdout}");
}

// ─── Newly added ripgrep short flags ───────────────────────────────

#[test]
fn case_sensitive_flag_overrides_smart_case() {
    let dir = setup_fixture();
    // notes.txt contains "Nothing important here." — smart case makes an
    // all-lowercase pattern case-insensitive, so it matches.
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-S",
            "nothing",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0);

    // -s forces case sensitivity back on, so the same pattern no longer matches.
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-S",
            "-s",
            "nothing",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
}

#[test]
fn ignore_case_still_wins_over_case_sensitive() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-s",
            "-i",
            "HELLO",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0);
}

#[test]
fn capital_i_suppresses_filenames() {
    let dir = setup_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-I",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!stdout.contains("hello.rs"), "got: {stdout}");
    assert!(stdout.contains("fn main"), "got: {stdout}");
}

#[test]
fn dot_flag_is_an_alias_for_hidden() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join(".hidden.txt"), "hidden_needle\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "hidden_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-.",
            "hidden_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0);
}

#[test]
fn follow_flag_is_accepted_as_dash_l() {
    let dir = setup_fixture();
    // -L is --follow in ripgrep; it must no longer mean --files-without-match.
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-L",
            "fn main",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("fn main"),
        "-L should follow links, not list non-matching files: {stdout}"
    );
}

// ─── Exit codes ────────────────────────────────────────────────────

#[test]
fn quiet_with_match_exits_zero_even_after_an_error() {
    let dir = setup_fixture();
    let missing = dir.path().join("nope").to_str().unwrap().to_string();

    // ripgrep: `matched && (quiet || !errored)` → 0.
    tgrep()
        .args([
            "--no-index",
            "--no-messages",
            "-q",
            "fn main",
            &fixture_path(&dir),
            &missing,
        ])
        .assert()
        .code(0);
}

// ═══════════════════════════════════════════════════════════════════════
// Regressions found in review
//
// Each of these was a real defect: the first two produced wrong output on
// the local path, the rest made results depend on whether a server or index
// happened to be in play.
// ═══════════════════════════════════════════════════════════════════════

/// Two matching lines with a gap between them, and no context requested.
fn setup_gap_fixture() -> TempDir {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(
        sub.join("gap.txt"),
        "alpha\nbeta\ngamma\ndelta\nalpha again\n",
    )
    .unwrap();
    dir
}

#[test]
fn no_context_separator_without_context_flags() {
    let dir = setup_gap_fixture();
    let output = tgrep()
        .args(["--no-index", "--no-heading", "alpha", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        !stdout.lines().any(|l| l.trim() == "--"),
        "`--` must only appear when context is requested, got: {stdout}"
    );
}

#[test]
fn no_context_separator_in_vimgrep_output() {
    let dir = setup_gap_fixture();
    let output = tgrep()
        .args(["--no-index", "--vimgrep", "alpha", &fixture_path(&dir)])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    // A bare `--` row breaks quickfix parsing.
    for line in stdout.lines().filter(|l| !l.is_empty()) {
        assert!(
            line.contains(".txt:"),
            "unparseable vimgrep row {line:?} in: {stdout}"
        );
    }
}

#[test]
fn context_separator_still_appears_with_context() {
    let dir = setup_gap_fixture();
    let output = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-C",
            "1",
            "alpha",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.lines().any(|l| l.trim() == "--"),
        "expected a `--` separator, got: {stdout}"
    );
}

#[test]
fn max_count_keeps_multiline_matches_whole() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("m.txt"), "start\nmiddle\nend\ntail\n").unwrap();

    let full = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-U",
            r"start[\s\S]*end",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let full = String::from_utf8_lossy(&full.stdout).to_string();

    // --max-count limits matches, not lines: one match must still print whole.
    let capped = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-U",
            "-m",
            "1",
            r"start[\s\S]*end",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let capped = String::from_utf8_lossy(&capped.stdout).to_string();

    assert_eq!(full.lines().count(), 3, "baseline changed: {full}");
    assert_eq!(
        capped, full,
        "-m 1 truncated a single multiline match mid-way"
    );
}

#[test]
fn indexed_max_filesize_is_honored() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    let mut big = String::new();
    while big.len() < 4000 {
        big.push_str("padding padding padding padding\n");
    }
    big.push_str("indexed_size_needle\n");
    fs::write(sub.join("big.txt"), big).unwrap();

    let index_dir = dir.path().join("idx");
    let idx = index_dir.to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    // Sanity: found through the index without a limit.
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "indexed_size_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0);

    // The flag must apply on the indexed path too, not just --no-index.
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "--max-filesize",
            "1K",
            "indexed_size_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
}

#[test]
fn indexed_pattern_file_is_honored() {
    let (dir, idx) = setup_indexed_fixture();
    let pats = dir.path().join("pats.txt");
    fs::write(&pats, "hello world\nzzz_no_such_pattern\n").unwrap();

    // -f patterns must survive the trip through the index/server path.
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-f",
            pats.to_str().unwrap(),
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("hello world"));
}

#[test]
fn indexed_extra_patterns_reach_the_query_plan() {
    let (dir, idx) = setup_indexed_fixture();
    // The trigram plan must union every pattern. Narrowing candidates with
    // only the primary pattern hides files that just the -e pattern matches.
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-e",
            "hello world",
            "-e",
            "zzz_no_such_pattern",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("hello world"));
}

#[test]
fn indexed_multiple_patterns_match_the_same_as_brute_force() {
    let (dir, idx) = setup_indexed_fixture();
    let path = indexed_fixture_path(&dir);

    let lines = |extra: &[&str]| -> Vec<String> {
        let mut args: Vec<&str> = vec!["--no-heading"];
        args.extend_from_slice(extra);
        args.extend_from_slice(&[
            "-e",
            "hello world",
            "-e",
            "version",
            "-e",
            "pub fn add",
            &path,
        ]);
        let out = tgrep().args(&args).output().unwrap();
        let mut v: Vec<String> = String::from_utf8_lossy(&out.stdout)
            .lines()
            .map(str::to_string)
            .collect();
        v.sort();
        v
    };

    let brute = lines(&["--no-index"]);
    let indexed = lines(&["--index-path", &idx]);

    assert_eq!(brute.len(), 3, "expected 3 matches, got: {brute:?}");
    assert_eq!(brute, indexed, "indexed path missed -e patterns");
}

#[test]
fn indexed_fixed_string_multiple_patterns() {
    let (dir, idx) = setup_indexed_fixture();
    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "-F",
            "-e",
            "println!(\"hello world\")",
            "-e",
            "a + b",
            &indexed_fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("hello world"))
        .stdout(predicate::str::contains("a + b"));
}
#[test]
fn indexed_count_ignores_context_lines() {
    let (dir, idx) = setup_indexed_fixture();

    let local = tgrep()
        .args([
            "--no-index",
            "-c",
            "-A",
            "2",
            "fn",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let indexed = tgrep()
        .args([
            "--index-path",
            &idx,
            "-c",
            "-A",
            "2",
            "fn",
            &indexed_fixture_path(&dir),
        ])
        .output()
        .unwrap();

    let mut a: Vec<String> = String::from_utf8_lossy(&local.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    let mut b: Vec<String> = String::from_utf8_lossy(&indexed.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    a.sort();
    b.sort();
    assert!(!a.is_empty(), "expected some counts");
    assert_eq!(a, b, "-c must count matching lines, not context lines");
}

#[test]
fn indexed_search_reads_non_utf8_files() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("latin1.txt"), b"caf\xe9 indexed_latin_needle\n").unwrap();

    let index_dir = dir.path().join("idx");
    let idx = index_dir.to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    tgrep()
        .args([
            "--no-heading",
            "--index-path",
            &idx,
            "indexed_latin_needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(0)
        .stdout(predicate::str::contains("indexed_latin_needle"));
}

// ─── Second review round: -v candidate soundness and -c on binary files ───

/// `-v` inverts at the *line* level, so a file matches when some line does not
/// match. Filtering candidates by the trigram plan selects exactly the wrong
/// files, so the plan has to be bypassed. Regression: the indexed path used to
/// return only files that *contained* the pattern.
#[test]
fn indexed_invert_match_returns_files_without_the_pattern() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    // Only `has.txt` contains the pattern, so its trigrams are the only ones in
    // the index. `none.txt` must still be reported by `-v`.
    fs::write(sub.join("has.txt"), "zebraqux marker\n").unwrap();
    fs::write(sub.join("none.txt"), "totally unrelated text\n").unwrap();

    let idx = dir.path().join("idx").to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let local = tgrep()
        .args(["--no-index", "-v", "-l", "zebraqux", &fixture_path(&dir)])
        .output()
        .unwrap();
    let indexed = tgrep()
        .args([
            "--index-path",
            &idx,
            "-v",
            "-l",
            "zebraqux",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();

    let mut a: Vec<String> = String::from_utf8_lossy(&local.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    let mut b: Vec<String> = String::from_utf8_lossy(&indexed.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    a.sort();
    b.sort();
    assert!(
        a.iter().any(|l| l.contains("none.txt")),
        "brute force should report none.txt, got {a:?}"
    );
    assert_eq!(a, b, "-v must not be narrowed by the trigram plan");
}

/// A file whose NUL byte sits past the 8 KiB binary sniff window is indexed as
/// ordinary text, so it becomes a normal search candidate. ripgrep hides binary
/// files found by traversal but reports a count for one named explicitly, and
/// both search paths must agree on each.
#[test]
fn count_reports_binary_files_with_late_nul() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();

    let mut content = String::new();
    for i in 0..800 {
        content.push_str(&format!("lateneedle line {i}\n"));
    }
    content.push_str("binary\u{0}marker\n");
    content.push_str("tail lateneedle only\n");
    fs::write(sub.join("big.txt"), &content).unwrap();
    fs::write(sub.join("plain.txt"), "a lateneedle in plain\n").unwrap();

    let idx = dir.path().join("idx").to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let count = |mode: &[&str], target: &str| -> Vec<String> {
        let mut args: Vec<&str> = mode.to_vec();
        args.extend_from_slice(&["-c", "lateneedle", target]);
        let out = tgrep().args(&args).output().unwrap();
        let mut v: Vec<String> = String::from_utf8_lossy(&out.stdout)
            .lines()
            .map(str::to_string)
            .collect();
        v.sort();
        v
    };

    // Traversal: the binary file is invisible on both paths.
    let dir_local = count(&["--no-index"], &fixture_path(&dir));
    let dir_indexed = count(&["--index-path", &idx], &fixture_path(&dir));
    assert!(
        !dir_local.iter().any(|l| l.contains("big.txt")),
        "an implicitly found binary file must be hidden, got {dir_local:?}"
    );
    assert_eq!(dir_local, dir_indexed, "-c must agree across search paths");

    // Named explicitly: the count is reported on both paths.
    let big = sub.join("big.txt").to_str().unwrap().to_string();
    let file_local = count(&["--no-index"], &big);
    let file_indexed = count(&["--index-path", &idx], &big);
    assert_eq!(file_local, vec!["801".to_string()], "expected 801 matches");
    assert_eq!(
        file_local, file_indexed,
        "-c must report explicit binary files on both paths"
    );
}

/// Without `-c`, an explicitly named binary file is summarised as a note on
/// both paths, and one found by traversal is hidden on both.
#[test]
fn binary_note_matches_between_indexed_and_brute_force() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();

    let mut content = String::new();
    for i in 0..800 {
        content.push_str(&format!("notaneedle line {i}\n"));
    }
    content.push_str("binary\u{0}marker\n");
    content.push_str("tail notaneedle only\n");
    fs::write(sub.join("big.txt"), &content).unwrap();

    let idx = dir.path().join("idx").to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let run = |mode: &[&str], target: &str| -> String {
        let mut args: Vec<&str> = mode.to_vec();
        args.extend_from_slice(&["--no-heading", "tail notaneedle", target]);
        let out = tgrep().args(&args).output().unwrap();
        String::from_utf8_lossy(&out.stdout).to_string()
    };

    let big = sub.join("big.txt").to_str().unwrap().to_string();
    let file_local = run(&["--no-index"], &big);
    let file_indexed = run(&["--index-path", &idx], &big);
    assert!(
        file_local.contains("binary file matches"),
        "expected a binary note, got {file_local:?}"
    );
    assert_eq!(
        file_local, file_indexed,
        "binary notes must agree across search paths"
    );

    let dir_local = run(&["--no-index"], &fixture_path(&dir));
    let dir_indexed = run(&["--index-path", &idx], &fixture_path(&dir));
    assert_eq!(dir_local, "", "traversal must hide binary files");
    assert_eq!(
        dir_local, dir_indexed,
        "binary suppression must agree across search paths"
    );
}

// ---------------------------------------------------------------------------
// File types (-t/-T/--type-add/--type-clear/--type-list)
// ---------------------------------------------------------------------------

#[test]
fn type_filter_restricts_to_rust_files() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-t",
            "rust",
            "fn",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs").or(predicate::str::contains("lib.rs")))
        .stdout(predicate::str::contains("config.toml").not());
}

#[test]
fn type_not_excludes_a_type() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-T",
            "rust",
            "-l",
            "e",
            &fixture_path(&dir),
        ])
        .assert()
        .stdout(predicate::str::contains(".rs").not());
}

#[test]
fn type_flag_is_repeatable() {
    let dir = setup_fixture();
    let out = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-t",
            "rust",
            "-t",
            "toml",
            "-l",
            "e",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let s = String::from_utf8_lossy(&out.stdout);
    assert!(s.contains(".rs"), "expected rust files, got {s:?}");
    assert!(s.contains(".toml"), "expected toml files, got {s:?}");
    assert!(!s.contains(".txt"), "txt must be excluded, got {s:?}");
}

#[test]
fn unknown_type_is_a_usage_error() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "-t",
            "definitelynotatype",
            "fn",
            &fixture_path(&dir),
        ])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("unrecognized file type"));
}

#[test]
fn type_add_defines_a_new_type() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--type-add",
            "note:*.txt",
            "-t",
            "note",
            "-l",
            "note",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("notes.txt"));
}

#[test]
fn type_clear_removes_a_builtin_type() {
    let dir = setup_fixture();
    // ripgrep drops the definition entirely, so selecting it afterwards is an
    // unrecognized-type usage error rather than a match-nothing filter.
    tgrep()
        .args([
            "--no-index",
            "--type-clear",
            "rust",
            "-t",
            "rust",
            "fn",
            &fixture_path(&dir),
        ])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("unrecognized file type"));
}

#[test]
fn type_list_includes_ripgrep_builtins() {
    tgrep()
        .arg("--type-list")
        .assert()
        .success()
        .stdout(predicate::str::contains("rust:"))
        .stdout(predicate::str::contains("cpp:"))
        .stdout(predicate::str::contains("py:"));
}

#[test]
fn type_list_reflects_type_add() {
    tgrep()
        .args(["--type-list", "--type-add", "zzz:*.zzz"])
        .assert()
        .success()
        .stdout(predicate::str::contains("zzz:"));
}

// ---------------------------------------------------------------------------
// Encoding (-E/--encoding)
// ---------------------------------------------------------------------------

/// Write `text` as UTF-16LE, optionally with a BOM.
fn write_utf16le(path: &std::path::Path, text: &str, bom: bool) {
    let mut bytes = Vec::new();
    if bom {
        bytes.extend_from_slice(&[0xFF, 0xFE]);
    }
    for u in text.encode_utf16() {
        bytes.extend_from_slice(&u.to_le_bytes());
    }
    fs::write(path, bytes).unwrap();
}

#[test]
fn utf16_bom_files_are_searched_as_text() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    write_utf16le(&sub.join("wide.txt"), "hello needle here\n", true);

    tgrep()
        .args(["--no-index", "--no-heading", "needle", &fixture_path(&dir)])
        .assert()
        .success()
        .stdout(predicate::str::contains("needle"))
        .stdout(predicate::str::contains("Binary file").not());
}

#[test]
fn explicit_encoding_finds_bomless_utf16() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    write_utf16le(&sub.join("wide.txt"), "hello needle here\n", false);

    // Without -E the file has no BOM, so it is treated as raw bytes.
    tgrep()
        .args(["--no-index", "--no-heading", "needle", &fixture_path(&dir)])
        .assert()
        .code(1);

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-E",
            "utf-16le",
            "needle",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("needle"));
}

#[test]
fn encoding_none_disables_bom_sniffing() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    write_utf16le(&sub.join("wide.txt"), "hello needle here\n", true);

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-E",
            "none",
            "needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
}

#[test]
fn no_encoding_restores_auto_detection() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    write_utf16le(&sub.join("wide.txt"), "hello needle here\n", true);

    // `--no-encoding` comes last, so it wins over `-E none`.
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-E",
            "none",
            "--no-encoding",
            "needle",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("needle"));
}

#[test]
fn latin1_encoding_decodes_high_bytes() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    // "café" in Latin-1: the 0xE9 byte is not valid UTF-8.
    fs::write(sub.join("l1.txt"), b"caf\xE9 au lait\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-E",
            "latin1",
            "café",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("café"));
}

#[test]
fn unknown_encoding_is_a_usage_error() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "-E",
            "definitelynotanencoding",
            "fn",
            &fixture_path(&dir),
        ])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("unsupported encoding"));
}

#[test]
fn encoding_results_agree_across_search_paths() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    write_utf16le(&sub.join("wide.txt"), "hello needle here\n", false);
    fs::write(sub.join("plain.txt"), "needle in plain text\n").unwrap();

    let idx = dir.path().join("idx").to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let local = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-E",
            "utf-16le",
            "needle",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let indexed = tgrep()
        .args([
            "--index-path",
            &idx,
            "--no-heading",
            "-E",
            "utf-16le",
            "needle",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();

    let mut a: Vec<_> = String::from_utf8_lossy(&local.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    let mut b: Vec<_> = String::from_utf8_lossy(&indexed.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    a.sort();
    b.sort();
    assert!(!a.is_empty(), "expected matches, got none");
    assert_eq!(a, b, "--encoding must agree across search paths");
}

// ---------------------------------------------------------------------------
// New ripgrep flags: matching, output, and walking
// ---------------------------------------------------------------------------

#[test]
fn line_regexp_requires_a_whole_line_match() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-x",
            "hello",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-x",
            "    a \\+ b",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("a + b"));
}

#[test]
fn whole_line_matching_allows_punctuation() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("p.txt"), "(flag)\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-w",
            "-x",
            r"\(flag\)",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("(flag)"));
}

#[test]
fn pcre2_enables_lookaround() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-P",
            "hello(?! world)",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-P",
            "hello(?= world)",
            &fixture_path(&dir),
        ])
        .assert()
        .success();
}

#[test]
fn default_engine_rejects_lookaround() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--engine",
            "default",
            "hello(?= world)",
            &fixture_path(&dir),
        ])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("regex error"));
}

#[test]
fn unknown_engine_is_a_usage_error() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--engine",
            "bogus",
            "hello",
            &fixture_path(&dir),
        ])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("unrecognized regex engine"));
}

#[test]
fn pcre2_version_reports_the_engine() {
    tgrep()
        .arg("--pcre2-version")
        .assert()
        .success()
        .stdout(predicate::str::contains("fancy-regex"));
}

#[test]
fn regex_size_limit_rejects_an_oversized_pattern() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--regex-size-limit",
            "1",
            "\\w{3,20}x[a-z]+",
            &fixture_path(&dir),
        ])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("size limit"));
}

#[test]
fn replace_rewrites_matches() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-r",
            "REP",
            "hello",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("REP world"));
}

#[test]
fn replace_expands_capture_groups() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-r",
            "<${1}>",
            "hel(lo)",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("<lo> world"));
}

#[test]
fn replace_with_only_matching_prints_replacements() {
    let dir = setup_fixture();
    let out = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "-o",
            "-r",
            "REP",
            "hello",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let s = String::from_utf8_lossy(&out.stdout);
    assert!(s.lines().any(|l| l.ends_with("REP")), "got {s:?}");
    assert!(
        !s.contains("world"),
        "-o must not print the rest, got {s:?}"
    );
}

#[test]
fn passthru_prints_every_line() {
    let dir = setup_fixture();
    let out = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--passthru",
            "hello",
            dir.path()
                .join("testdata")
                .join("hello.rs")
                .to_str()
                .unwrap(),
        ])
        .output()
        .unwrap();
    let s = String::from_utf8_lossy(&out.stdout);
    assert_eq!(s.lines().count(), 3, "expected the whole file, got {s:?}");
    assert!(s.contains("fn main()"), "got {s:?}");
}

#[test]
fn passthru_prints_explicit_no_match_and_exits_one() {
    let dir = TempDir::new().unwrap();
    let path = dir.path().join("plain.txt");
    fs::write(&path, "alpha\nbeta\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "--passthru",
            "does-not-exist",
            path.to_str().unwrap(),
        ])
        .assert()
        .code(1)
        .stdout("alpha\nbeta\n");
}

#[test]
fn passthru_no_match_keeps_binary_files_silent() {
    let dir = TempDir::new().unwrap();
    let path = dir.path().join("binary.bin");
    fs::write(&path, b"alpha\n\0beta\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--passthru",
            "does-not-exist",
            path.to_str().unwrap(),
        ])
        .assert()
        .code(1)
        .stdout(predicate::str::is_empty());
}

#[test]
fn stop_on_nonmatch_halts_at_the_first_gap() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("s.txt"), "hit\nhit\nmiss\nhit\n").unwrap();

    let out = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "--stop-on-nonmatch",
            "hit",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let s = String::from_utf8_lossy(&out.stdout);
    assert_eq!(
        s.lines().count(),
        2,
        "expected to stop at line 3, got {s:?}"
    );
}

#[test]
fn column_flag_prints_match_columns() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--column",
            "world",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains(":2:21:"));
}

#[test]
fn byte_offset_flag_prints_line_offsets() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-n",
            "-b",
            "world",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains(":2:12:"));
}

#[test]
fn max_columns_omits_long_lines() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(
        sub.join("long.txt"),
        format!("needle {}\n", "x".repeat(200)),
    )
    .unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-M",
            "20",
            "needle",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("[Omitted long matching line]"));
}

#[test]
fn max_columns_preview_truncates_instead() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(
        sub.join("long.txt"),
        format!("needle {}\n", "x".repeat(200)),
    )
    .unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-M",
            "20",
            "--max-columns-preview",
            "needle",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("[... omitted end of long line]"));
}

#[test]
fn count_matches_counts_matches_not_lines() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("m.txt"), "aa aa aa\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-c",
            "aa",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains(":1"));
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--count-matches",
            "aa",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains(":3"));
}

#[test]
fn include_zero_reports_unmatched_files() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-c",
            "--include-zero",
            "definitelynothere",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1)
        .stdout(predicate::str::contains("hello.rs:0"));
}

#[test]
fn context_separator_is_configurable() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("g.txt"), "hit\na\nb\nc\nd\nhit\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-C1",
            "--context-separator",
            "=====",
            "hit",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("====="));

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-C1",
            "--no-context-separator",
            "hit",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("--").not());
}

#[test]
fn field_separators_are_configurable() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-n",
            "--field-match-separator",
            "@@",
            "world",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("@@2@@"));
}

#[test]
fn path_separator_rewrites_printed_paths() {
    let dir = setup_fixture();
    let nested = dir.path().join("testdata").join("nested");
    fs::create_dir_all(&nested).unwrap();
    fs::write(nested.join("deep.txt"), "world\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--path-separator",
            "::",
            "-l",
            "world",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("nested::deep.txt"));
}

#[test]
fn sort_path_orders_results_deterministically() {
    let dir = setup_fixture();
    let out = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--sort",
            "path",
            "-l",
            "e",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let lines: Vec<_> = String::from_utf8_lossy(&out.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    let mut sorted = lines.clone();
    sorted.sort();
    assert_eq!(lines, sorted, "--sort path must emit ascending order");

    let rev = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--sortr",
            "path",
            "-l",
            "e",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let mut rev_lines: Vec<_> = String::from_utf8_lossy(&rev.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    rev_lines.reverse();
    assert_eq!(rev_lines, sorted, "--sortr path must emit descending order");
}

#[test]
fn unknown_sort_criteria_is_a_usage_error() {
    let dir = setup_fixture();
    tgrep()
        .args(["--no-index", "--sort", "bogus", "e", &fixture_path(&dir)])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("unrecognized sort criteria"));
}

#[test]
fn max_depth_limits_recursion() {
    let dir = setup_fixture();
    let deep = dir.path().join("testdata").join("nested");
    fs::create_dir_all(&deep).unwrap();
    fs::write(deep.join("deep.txt"), "needle\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--max-depth",
            "1",
            "-l",
            "needle",
            &fixture_path(&dir),
        ])
        .assert()
        .code(1);
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--max-depth",
            "2",
            "-l",
            "needle",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("deep.txt"));
}

#[test]
fn ignore_file_applies_extra_rules() {
    let dir = setup_fixture();
    let ignore = dir.path().join("extra-ignore");
    fs::write(&ignore, "hello.rs\n").unwrap();

    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--ignore-file",
            ignore.to_str().unwrap(),
            "-l",
            "fn",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello.rs").not())
        .stdout(predicate::str::contains("lib.rs"));
}

#[test]
fn threads_flag_is_accepted() {
    let dir = setup_fixture();
    tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-j",
            "1",
            "hello",
            &fixture_path(&dir),
        ])
        .assert()
        .success()
        .stdout(predicate::str::contains("hello world"));
}

#[test]
fn pretty_implies_color_and_heading() {
    let dir = setup_fixture();
    let out = tgrep()
        .args(["--no-index", "-p", "hello", &fixture_path(&dir)])
        .output()
        .unwrap();
    let s = String::from_utf8_lossy(&out.stdout);
    assert!(s.contains("\u{1b}["), "expected ANSI colour, got {s:?}");
    assert!(s.contains("hello.rs"), "expected a heading, got {s:?}");
}

#[test]
fn new_flags_agree_across_search_paths() {
    let dir = setup_fixture();
    let idx = dir.path().join("idx").to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let cases: &[&[&str]] = &[
        &["--no-heading", "-r", "REP", "hello"],
        &["--no-heading", "--passthru", "hello"],
        &["--no-heading", "--passthru", "zzz_no_such_passthru_pattern"],
        &["--no-heading", "--column", "-b", "hello"],
        &["--no-heading", "-x", "}"],
        &["--no-heading", "--count-matches", "n"],
        &["--no-heading", "-c", "n"],
        &["--no-heading", "-M", "10", "hello"],
        &["--no-heading", "-P", "hello(?= world)"],
        &["--no-heading", "--sort", "path", "-l", "n"],
        &["--no-heading", "-o", "-r", "REP", "hello"],
    ];

    let path = fixture_path(&dir);
    for case in cases {
        let mut local_args = vec!["--no-index"];
        local_args.extend_from_slice(case);
        local_args.push(&path);
        let local = tgrep().args(&local_args).output().unwrap();

        let mut idx_args = vec!["--index-path", &idx];
        idx_args.extend_from_slice(case);
        idx_args.push(&path);
        let indexed = tgrep().args(&idx_args).output().unwrap();

        let mut a: Vec<_> = String::from_utf8_lossy(&local.stdout)
            .lines()
            .map(str::to_string)
            .collect();
        let mut b: Vec<_> = String::from_utf8_lossy(&indexed.stdout)
            .lines()
            .map(str::to_string)
            .collect();
        a.sort();
        b.sort();
        assert_eq!(a, b, "paths disagree for {case:?}");
    }
}

#[test]
fn search_zip_is_rejected_rather_than_ignored() {
    let dir = setup_fixture();
    tgrep()
        .args(["--no-index", "-z", "hello", &fixture_path(&dir)])
        .assert()
        .code(2)
        .stderr(predicate::str::contains("not supported"));
}

#[test]
fn compatibility_no_op_flags_are_accepted() {
    let dir = setup_fixture();
    for flag in ["--mmap", "--no-mmap", "--crlf", "--no-crlf", "--no-config"] {
        tgrep()
            .args([
                "--no-index",
                "--no-heading",
                flag,
                "hello",
                &fixture_path(&dir),
            ])
            .assert()
            .success()
            .stdout(predicate::str::contains("hello world"));
    }
}

#[test]
fn column_is_not_printed_on_context_lines() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();
    fs::write(sub.join("f.txt"), "alpha\nbravo NEEDLE here\ncharlie\n").unwrap();

    let out = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--no-filename",
            "--column",
            "-C1",
            "NEEDLE",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let s = String::from_utf8_lossy(&out.stdout);
    assert!(s.contains("2:7:bravo"), "match needs a column, got {s:?}");
    assert!(
        s.contains("1-alpha"),
        "context must have no column, got {s:?}"
    );
    assert!(
        s.contains("3-charlie"),
        "context must have no column, got {s:?}"
    );
}

#[test]
fn include_zero_agrees_across_search_paths() {
    let dir = setup_fixture();
    let idx = dir.path().join("idx").to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let local = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "-c",
            "--include-zero",
            "definitelynothere",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let indexed = tgrep()
        .args([
            "--index-path",
            &idx,
            "--no-heading",
            "-c",
            "--include-zero",
            "definitelynothere",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();

    let mut a: Vec<_> = String::from_utf8_lossy(&local.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    let mut b: Vec<_> = String::from_utf8_lossy(&indexed.stdout)
        .lines()
        .map(str::to_string)
        .collect();
    a.sort();
    b.sort();
    assert!(!a.is_empty(), "expected zero-count rows, got none");
    assert_eq!(a, b, "--include-zero must agree across search paths");
}

#[test]
fn sort_path_uses_the_same_order_on_every_search_path() {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(sub.join("src")).unwrap();
    // `.` and `x` straddle `/` in ASCII, so a raw string sort disagrees with a
    // component-wise path sort here.
    fs::write(sub.join("src.rs"), "needle\n").unwrap();
    fs::write(sub.join("srcx.rs"), "needle\n").unwrap();
    fs::write(sub.join("src").join("lib.rs"), "needle\n").unwrap();

    let idx = dir.path().join("idx").to_str().unwrap().to_string();
    tgrep()
        .args(["index", &fixture_path(&dir), "--index-path", &idx])
        .assert()
        .success();

    let local = tgrep()
        .args([
            "--no-index",
            "--no-heading",
            "--sort",
            "path",
            "-l",
            "needle",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();
    let indexed = tgrep()
        .args([
            "--index-path",
            &idx,
            "--no-heading",
            "--sort",
            "path",
            "-l",
            "needle",
            &fixture_path(&dir),
        ])
        .output()
        .unwrap();

    // Deliberately NOT sorted: the order itself is what is under test.
    let a = String::from_utf8_lossy(&local.stdout).to_string();
    let b = String::from_utf8_lossy(&indexed.stdout).to_string();
    assert_eq!(a.lines().count(), 3, "expected three files, got {a:?}");
    assert_eq!(a, b, "--sort path must use one order on every search path");
}

// ---------------------------------------------------------------------------
// `--no-require-git` reaches the index, not just the search
//
// `.gitignore` is git-gated by default (ripgrep's own rule), so enlistments
// that are not git checkouts -- Perforce and Source Depot trees, exported
// source drops -- have their `.gitignore` files ignored and index build
// output. `--no-require-git` is the documented escape hatch, and because it is
// a global flag clap accepted it on `index` and `serve` while the value was
// dropped on the floor: the search path honoured it and the index path did
// not, so the two disagreed about which files existed.
// ---------------------------------------------------------------------------

/// A tree with a real `.gitignore` and deliberately no `.git` directory.
fn non_git_enlistment() -> TempDir {
    let dir = TempDir::new().unwrap();
    let root = dir.path().join("testdata");
    fs::create_dir_all(root.join("src")).unwrap();
    fs::create_dir_all(root.join("build")).unwrap();
    fs::write(root.join(".gitignore"), "build/\n*.log\n").unwrap();
    fs::write(root.join("src").join("main.rs"), "let needle = 1;\n").unwrap();
    fs::write(root.join("build").join("gen.rs"), "let needle = 2;\n").unwrap();
    fs::write(root.join("out.log"), "needle\n").unwrap();
    dir
}

fn indexed_file_count(root: &str, idx: &str, extra: &[&str]) -> usize {
    let mut args = vec!["index", root, "--index-path", idx];
    args.extend_from_slice(extra);
    let out = tgrep().args(&args).output().unwrap();
    assert!(out.status.success(), "index failed: {out:?}");
    let text = String::from_utf8_lossy(&out.stderr).to_string();
    let line = text
        .lines()
        .find(|l| l.starts_with("Found "))
        .unwrap_or_else(|| panic!("no 'Found' line in: {text}"));
    line.split_whitespace().nth(1).unwrap().parse().unwrap()
}

#[test]
fn index_is_git_gated_by_default_like_ripgrep() {
    let dir = non_git_enlistment();
    let idx = dir.path().join("idx");
    let n = indexed_file_count(&indexed_fixture_path(&dir), idx.to_str().unwrap(), &[]);
    // src/main.rs + build/gen.rs + out.log + the nonignored .gitignore source.
    assert_eq!(n, 4, "no `.git`, so `.gitignore` must not apply by default");
}

#[test]
fn index_honours_no_require_git() {
    let dir = non_git_enlistment();
    let idx = dir.path().join("idx");
    let n = indexed_file_count(
        &indexed_fixture_path(&dir),
        idx.to_str().unwrap(),
        &["--no-require-git"],
    );
    // src/main.rs and the nonignored .gitignore source survive.
    assert_eq!(
        n, 2,
        "`--no-require-git` must reach the indexing walk, not just search"
    );
}

/// The actual user-visible symptom: build output stays searchable through the
/// index even though `.gitignore` excludes it.
#[test]
fn indexed_search_excludes_ignored_files_under_no_require_git() {
    let dir = non_git_enlistment();
    let idx = dir.path().join("idx");
    let root = indexed_fixture_path(&dir);
    tgrep()
        .args([
            "index",
            &root,
            "--index-path",
            idx.to_str().unwrap(),
            "--no-require-git",
        ])
        .assert()
        .success();

    let out = tgrep()
        .args([
            "--no-heading",
            "--index-path",
            idx.to_str().unwrap(),
            "--no-require-git",
            "needle",
            &root,
        ])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&out.stdout).to_string();
    assert!(
        stdout.contains("main.rs"),
        "expected the source hit: {stdout:?}"
    );
    assert!(
        !stdout.contains("gen.rs") && !stdout.contains("out.log"),
        "ignored build output must not be searchable: {stdout:?}"
    );
}

// ---------------------------------------------------------------------------
// `-P` patterns still use the index
//
// A PCRE pattern cannot be parsed by regex-syntax, so the planner used to give up
// and hand back MatchAll - every file in the index, read and decoded and matched
// one by one. On a large tree that turned a query with an obvious mandatory
// literal into a full-corpus scan. The planner now relaxes the pattern first
// (dropping the zero-width assertions) and plans from the result, which matches a
// superset and therefore cannot exclude a real hit. These tests pin that the
// answers are unchanged.
// ---------------------------------------------------------------------------

/// Index and direct scans can print paths differently; compare the set of lines
/// with separators and ordering normalised away.
fn normalize(out: &str) -> Vec<String> {
    let mut lines: Vec<String> = out
        .lines()
        .filter(|l| !l.is_empty())
        .map(|l| l.replace('\\', "/"))
        .collect();
    lines.sort();
    lines
}

/// Two files hold the literal - one commented out, one not - plus decoys that do
/// not hold it at all, so a plan that works can be told apart from one that does
/// not.
fn setup_lookaround_fixture() -> (TempDir, String) {
    let dir = TempDir::new().unwrap();
    let sub = dir.path().join("testdata");
    fs::create_dir_all(&sub).unwrap();

    fs::write(sub.join("live.rs"), "let p = ExchangePrincipal::new();\n").unwrap();
    fs::write(sub.join("commented.rs"), "//ExchangePrincipal is gone\n").unwrap();
    fs::write(sub.join("unrelated.rs"), "let q = SomethingElse::new();\n").unwrap();
    fs::write(sub.join("notes.txt"), "no mention of the type here\n").unwrap();

    let index_dir = dir.path().join("idx");
    tgrep()
        .args([
            "index",
            sub.to_str().unwrap(),
            "--index-path",
            index_dir.to_str().unwrap(),
        ])
        .assert()
        .success();

    (dir, index_dir.to_str().unwrap().to_string())
}

#[test]
fn indexed_lookaround_finds_the_same_lines_as_a_direct_scan() {
    let (dir, idx) = setup_lookaround_fixture();
    let root = indexed_fixture_path(&dir);

    let indexed = String::from_utf8(
        tgrep()
            .args([
                "--no-heading",
                "-P",
                "--index-path",
                &idx,
                r"(?<!//)ExchangePrincipal",
                &root,
            ])
            .assert()
            .success()
            .get_output()
            .stdout
            .clone(),
    )
    .unwrap();

    let direct = String::from_utf8(
        tgrep()
            .args([
                "--no-heading",
                "-P",
                "--no-index",
                r"(?<!//)ExchangePrincipal",
                &root,
            ])
            .assert()
            .success()
            .get_output()
            .stdout
            .clone(),
    )
    .unwrap();

    assert_eq!(
        normalize(&indexed),
        normalize(&direct),
        "using the index must not change the answer"
    );
    assert!(
        indexed.contains("live.rs"),
        "the uncommented hit survives the relaxed plan: {indexed}"
    );
    assert!(
        !indexed.contains("commented.rs"),
        "the lookbehind is still applied by the real matcher: {indexed}"
    );
}

#[test]
fn indexed_lookahead_finds_the_same_lines_as_a_direct_scan() {
    let (dir, idx) = setup_lookaround_fixture();
    let root = indexed_fixture_path(&dir);

    for pattern in [
        r"ExchangePrincipal(?=::)",
        r"ExchangePrincipal(?!::)",
        r"(?=.*Exchange)ExchangePrincipal",
    ] {
        let indexed = tgrep()
            .args(["--no-heading", "-P", "--index-path", &idx, pattern, &root])
            .assert()
            .get_output()
            .stdout
            .clone();
        let direct = tgrep()
            .args(["--no-heading", "-P", "--no-index", pattern, &root])
            .assert()
            .get_output()
            .stdout
            .clone();
        assert_eq!(
            normalize(&String::from_utf8(indexed).unwrap()),
            normalize(&String::from_utf8(direct).unwrap()),
            "index and direct scan disagree for {pattern}"
        );
    }
}

#[test]
fn indexed_backreference_still_returns_every_match() {
    // Backreferences cannot be relaxed, so the planner falls back to scanning
    // everything. That is slow, not wrong - the results must still be complete.
    let (dir, idx) = setup_lookaround_fixture();
    let root = indexed_fixture_path(&dir);

    let out = String::from_utf8(
        tgrep()
            .args([
                "--no-heading",
                "-P",
                "--index-path",
                &idx,
                r"(Exchange)\1?Principal",
                &root,
            ])
            .assert()
            .success()
            .get_output()
            .stdout
            .clone(),
    )
    .unwrap();
    assert!(
        out.contains("live.rs") && out.contains("commented.rs"),
        "an unrelaxable pattern still sees every file: {out}"
    );
}
