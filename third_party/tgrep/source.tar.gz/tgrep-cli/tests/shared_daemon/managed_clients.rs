// Copyright (c) Microsoft Corporation. All rights reserved.

use super::*;
use std::sync::Arc;
use tgrep_core::managed::Id;

pub(super) fn manage(root: &Path, method: &str, params: Value) -> Value {
    let params = params.to_string();
    let response: Value = serde_json::from_str(&success(cli(
        root,
        &["shared", "manage", ".", method, "--params", &params],
    )))
    .unwrap();
    assert_eq!(response["ok"], true, "{response}");
    response["result"].clone()
}

/// A client-side guarded generation open takes the catalog writer lock, so it
/// may legally fail with retryable, uncommitted `busy`/`catalog-io`.
fn open_guarded<T>(open: impl FnMut() -> tgrep_core::managed::Result<T>) -> T {
    retry_catalog_busy(open, Instant::now() + CATALOG_BUSY_DEADLINE).unwrap()
}

fn assert_catalog_contention(error: &tgrep_core::managed::Error) {
    assert_eq!(error.category, ErrorCategory::Busy, "{error:?}");
    assert_eq!(error.reason_code, "catalog-io", "{error:?}");
    assert!(error.retryable, "{error:?}");
    assert_eq!(
        error.committed_state,
        CommitState::NotCommitted,
        "{error:?}"
    );
}

#[test]
fn guarded_generation_open_retries_only_exact_catalog_writer_contention() {
    let fixture = Fixture::new();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let (claim, guard) = owner(&daemon);
    let attached = verified_attach(
        &daemon,
        &daemon.rpc("views.attach", attach_input(&fixture, &claim)),
    );
    // Readiness precedes permit teardown, which must finish before we hold the writer lock.
    live::wait_for(&daemon, "namespace.status", json!({}), |status| {
        status["usage"]["reserved_slots"] == 0
    });
    let storage = PathBuf::from(daemon.marker["storage"].as_str().unwrap());
    let incarnation = Id::parse(
        attached["result"]["current"]["current"]["incarnation"]
            .as_str()
            .unwrap(),
    )
    .unwrap();
    let open = || tgrep_core::managed::open_generation(&storage, &incarnation);
    let generation = thread::scope(|scope| {
        let (ready_tx, ready_rx) = std::sync::mpsc::channel();
        let (release_tx, release_rx) = std::sync::mpsc::channel::<()>();
        let catalog = storage.join("catalog.sqlite");
        let holder = scope.spawn(move || {
            let mut connection = rusqlite::Connection::open(catalog).unwrap();
            connection.busy_timeout(Duration::from_secs(10)).unwrap();
            let transaction = connection
                .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)
                .unwrap();
            ready_tx.send(()).unwrap();
            release_rx.recv_timeout(Duration::from_secs(10)).unwrap();
            transaction.rollback().unwrap();
        });
        ready_rx.recv_timeout(Duration::from_secs(10)).unwrap();
        let mut attempts = 0;
        let expired = retry_catalog_busy(
            || {
                attempts += 1;
                open()
            },
            Instant::now(),
        );
        assert_catalog_contention(
            expired
                .as_ref()
                .err()
                .expect("writer lock must block the guarded open"),
        );
        assert_eq!(attempts, 1, "an expired bound must not be extended");
        let mut attempts = 0;
        let generation = open_guarded(|| {
            attempts += 1;
            let result = open();
            if attempts == 1 {
                assert_catalog_contention(
                    result
                        .as_ref()
                        .err()
                        .expect("writer lock must block the guarded open"),
                );
                release_tx.send(()).unwrap();
            }
            result
        });
        holder.join().unwrap();
        assert!(attempts >= 2, "{attempts}");
        generation
    });
    assert!(
        generation
            .base()
            .reader()
            .all_paths()
            .contains(&"notes.txt".to_owned())
    );
    drop(generation);

    let missing = Id::parse("f".repeat(32)).unwrap();
    let mut outcomes = Vec::new();
    let error = retry_catalog_busy(
        || {
            let result = tgrep_core::managed::open_generation(&storage, &missing);
            outcomes.push(result.as_ref().err().map(|error| {
                (
                    error.category,
                    error.reason_code.clone(),
                    error.retryable,
                    error.committed_state,
                )
            }));
            result
        },
        Instant::now() + CATALOG_BUSY_DEADLINE,
    )
    .err()
    .expect("an unpublished generation must not open");
    assert_ne!(error.category, ErrorCategory::Busy, "{error:?}");
    let (last, retried) = outcomes.split_last().unwrap();
    assert_eq!(last.as_ref().unwrap().1, error.reason_code);
    for retried in retried {
        assert_eq!(
            retried.as_ref().unwrap(),
            &(
                ErrorCategory::Busy,
                "catalog-io".to_owned(),
                true,
                CommitState::NotCommitted
            )
        );
    }
    daemon.rpc("owners.release", json!({"claim":claim}));
    drop(guard);
    stop(&mut daemon);
}

fn wait_json(process: &mut runtime::Process, flag: &str) -> Value {
    let started = Instant::now();
    loop {
        for line in String::from_utf8_lossy(&process.stdout()).lines() {
            if let Ok(value) = serde_json::from_str::<Value>(line)
                && value[flag] == true
            {
                return value;
            }
        }
        assert!(
            process.running(),
            "owned helper exited before readiness: {:?}",
            process.finish(Duration::from_secs(1))
        );
        assert!(
            started.elapsed() < Duration::from_secs(30),
            "owned helper readiness deadline"
        );
        thread::sleep(Duration::from_millis(5));
    }
}

pub(super) fn held_owner(fixture: &Fixture, daemon: &Daemon) -> (OwnerClaim, runtime::Process) {
    let prepared = daemon.rpc(
        "owners.prepare",
        json!({
            "token":format!("process-owner-{}", LEASE_SEQUENCE.fetch_add(1, Ordering::Relaxed))
        }),
    );
    let claim: OwnerClaim = serde_json::from_value(prepared["claim"].clone()).unwrap();
    let path = fixture
        .temp
        .path()
        .join(format!("{}.claim.json", claim.owner));
    fs::write(&path, serde_json::to_vec(&claim).unwrap()).unwrap();
    let mut child =
        runtime::Process::start(Command::new(assert_cmd::cargo::cargo_bin("tgrep")).args([
            "shared",
            "owner-hold",
            "--claim",
            path.to_str().unwrap(),
        ]));
    let holding = wait_json(&mut child, "holding");
    assert_eq!(holding["claim"], serde_json::to_value(&claim).unwrap());
    manage(&fixture.a, "owners.register", json!({"claim":claim}));
    (claim, child)
}

#[test]
fn management_rpc_rejects_public_identity_without_private_authorization() {
    let fixture = Fixture::new();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let (claim, guard) = owner(&daemon);
    for authorization in [
        Value::Null,
        json!(Id::new().unwrap()),
        daemon.marker["namespace"].clone(),
        daemon.marker["instance"].clone(),
    ] {
        for (method, params) in [
            ("owners.release", json!({"claim":claim})),
            ("owners.page", json!({"after":null})),
            ("owners.prepare", json!({"token":"unauthorized-owner"})),
            ("operations.cancel", json!({"id":Id::new().unwrap()})),
            ("collections.start", json!({})),
            ("stop-if-idle", idle_request(&daemon)),
            ("hello", json!({})),
        ] {
            let mut request = daemon.request(method, params);
            request.as_object_mut().unwrap().remove("authorization");
            if !authorization.is_null() {
                request["authorization"] = authorization.clone();
            }
            let response = daemon.raw(&request).unwrap();
            assert_eq!(
                response["error"]["data"]["category"], "permission",
                "{method}: {response}"
            );
            assert_eq!(
                response["error"]["data"]["reason_code"], "rpc-authentication-failed",
                "{method}: {response}"
            );
            assert_eq!(response["error"]["data"]["retryable"], false);
            assert_eq!(
                response["error"]["data"]["committed_state"],
                "not-committed"
            );
        }
    }
    let owners = daemon.rpc("owners.page", json!({"after":null}));
    assert_eq!(owners.as_array().unwrap().len(), 1, "{owners}");
    assert_eq!(owners[0]["released"], false);
    daemon.rpc("owners.release", json!({"claim":claim}));
    drop(guard);
    stop(&mut daemon);
    drop(daemon);
    fixture.temp.close().unwrap();
}

#[test]
fn management_rpc_credentials_rotate_and_bind_discovery() {
    let fixture = Fixture::new();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let common = tgrep_core::generations::Repository::discover(&fixture.a)
        .unwrap()
        .common_dir()
        .to_path_buf();
    let marker = common.join("tgrep-daemon-v2.json");
    let credentials = common.join("tgrep-daemon-v2.auth.json");
    let original = fs::read(&marker).unwrap();
    let listener = std::net::TcpListener::bind(("127.0.0.1", 0)).unwrap();
    listener.set_nonblocking(true).unwrap();
    let mut forged = daemon.marker.clone();
    forged["port"] = json!(listener.local_addr().unwrap().port());
    fs::write(&marker, serde_json::to_vec(&forged).unwrap()).unwrap();
    let denied = cli(&fixture.a, &["shared", "manage", ".", "hello"]);
    assert!(!denied.status.success(), "{denied:?}");
    assert!(
        String::from_utf8_lossy(&denied.stderr).contains("rpc-registration-mismatch"),
        "{denied:?}"
    );
    assert_eq!(
        listener.accept().unwrap_err().kind(),
        std::io::ErrorKind::WouldBlock
    );
    fs::write(&marker, original).unwrap();
    success(cli(&fixture.a, &["shared", "manage", ".", "hello"]));
    let old_authorization = daemon.authorization.clone();
    stop(&mut daemon);
    drop(daemon);
    assert!(!credentials.exists());
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    assert_ne!(daemon.authorization, old_authorization);
    let mut request = daemon.request("hello", json!({}));
    request["authorization"] = old_authorization;
    let response = daemon.raw(&request).unwrap();
    assert_eq!(
        response["error"]["data"]["reason_code"], "rpc-authentication-failed",
        "{response}"
    );
    success(cli(&fixture.a, &["shared", "manage", ".", "hello"]));
    stop(&mut daemon);
    drop(daemon);
    drop(listener);
    fixture.temp.close().unwrap();
}

#[test]
fn management_rpc_legacy_route_requires_the_private_compatibility_credential() {
    let fixture = Fixture::new();
    let mut configured = policy();
    configured["storage"] = json!("compatibility-retain-all");
    let mut daemon = start(&fixture, &configured, &["--no-watch"]);
    let common = tgrep_core::generations::Repository::discover(&fixture.a)
        .unwrap()
        .common_dir()
        .to_path_buf();
    let legacy =
        tgrep_core::managed::read_private_control_file(&common.join("tgrep-daemon-v1.json"))
            .unwrap();
    assert_ne!(legacy["instance"], daemon.marker["instance"]);
    let request = |instance: &Value| {
        json!({
            "jsonrpc":"2.0","protocol":1,"instance":instance,
            "repository":daemon.marker["repository"],"id":1,"method":"hello","params":{}
        })
    };
    for value in [&daemon.marker["instance"], &daemon.authorization] {
        let denied = daemon.raw(&request(value)).unwrap();
        assert_eq!(
            denied["error"]["data"]["reason_code"], "rpc-authentication-failed",
            "{denied}"
        );
    }
    let mut v2 = daemon.request("hello", json!({}));
    v2["authorization"] = legacy["instance"].clone();
    let denied = daemon.raw(&v2).unwrap();
    assert_eq!(
        denied["error"]["data"]["reason_code"], "rpc-authentication-failed",
        "{denied}"
    );
    let allowed = daemon.raw(&request(&legacy["instance"])).unwrap();
    assert_eq!(allowed["result"]["protocol"], 1, "{allowed}");
    assert_eq!(allowed["result"]["instance"], legacy["instance"]);
    stop(&mut daemon);
    drop(daemon);
    fixture.temp.close().unwrap();
}

#[test]
fn management_rpc_registration_failure_cleans_private_credentials() {
    let fixture = Fixture::new();
    let common = tgrep_core::generations::Repository::discover(&fixture.a)
        .unwrap()
        .common_dir()
        .to_path_buf();
    let policy_file = fixture.storage.join("policy.json");
    fs::write(&policy_file, serde_json::to_vec(&policy()).unwrap()).unwrap();
    for name in ["tgrep-daemon-v2.json", "tgrep-daemon-v1.json"] {
        let conflict = common.join(name);
        fs::create_dir(&conflict).unwrap();
        let result = cli(
            &fixture.a,
            &[
                "serve",
                "--shared",
                ".",
                "--shared-storage",
                fixture.storage.to_str().unwrap(),
                "--shared-policy",
                policy_file.to_str().unwrap(),
                "--no-watch",
            ],
        );
        assert!(!result.status.success(), "{result:?}");
        assert!(!common.join("tgrep-daemon-v2.auth.json").exists());
        assert!(conflict.is_dir());
        fs::remove_dir(conflict).unwrap();
        assert!(!common.join("tgrep-daemon-v2.json").exists());
    }
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    stop(&mut daemon);
    drop(daemon);
    fixture.temp.close().unwrap();
}

#[test]
fn managed_search_preserves_pattern_files_boundaries_and_multiline_spans() {
    let mut fixture = Fixture::new();
    fs::write(
        fixture.a.join("corpus.txt"),
        "alpha\nALPHA\nbeta\nBETA\n test \nplain test\na_c\nA_C\na- x\nxa- x\na-\naa\n",
    )
    .unwrap();
    git(&fixture.a, &["add", "corpus.txt"]);
    git(
        &fixture.a,
        &["commit", "-qm", "search compatibility corpus"],
    );
    fixture.revision = git(&fixture.a, &["rev-parse", "HEAD"]);
    let whitespace = fixture.temp.path().join("whitespace-patterns");
    let blank = fixture.temp.path().join("blank-patterns");
    let empty = fixture.temp.path().join("empty-patterns");
    let uppercase = fixture.temp.path().join("uppercase-patterns");
    fs::write(&whitespace, " test \r\n").unwrap();
    fs::write(&blank, "alpha\n\n").unwrap();
    fs::write(&empty, "").unwrap();
    fs::write(&uppercase, "alpha\r\nBETA\r\n").unwrap();

    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let (claim, guard) = owner(&daemon);
    verified_attach(
        &daemon,
        &daemon.rpc("views.attach", attach_input(&fixture, &claim)),
    );
    assert_scan_parity(&daemon, &fixture.a, fixture.temp.path());
    let cases: &[&[&str]] = &[
        &["-F", "-f", whitespace.to_str().unwrap()],
        &["-F", "-f", blank.to_str().unwrap()],
        &["-F", "-v", "-f", empty.to_str().unwrap()],
        &["-S", "-f", uppercase.to_str().unwrap()],
        &["-e", "(?i)alpha", "-e", "beta"],
        &["-S", "-e", r"a\Sc"],
        &["-S", "-e", r"a\Sc", "-e", "BETA"],
        &["-w", "-e", "a-"],
        &["-w", "-x", "-e", "a-"],
        &["-x", "-w", "-e", "a-"],
        &["-U", "-o", "-e", "a"],
        &["-U", "-e", ""],
    ];
    for engine in ["auto", "pcre2"] {
        for flags in cases {
            let mut args = vec![
                "--stats",
                "--json",
                "--engine",
                engine,
                "--glob",
                "corpus.txt",
            ];
            args.extend_from_slice(flags);
            args.extend(["--", "."]);
            let indexed = cli(&fixture.a, &args);
            args.insert(0, "--no-index");
            let scanned = cli(&fixture.a, &args);
            assert!(
                String::from_utf8_lossy(&indexed.stderr).contains("(via shared daemon v2)"),
                "managed backend was not used for {engine} {flags:?}: {}",
                String::from_utf8_lossy(&indexed.stderr)
            );
            assert_eq!(
                canonical_matches(indexed),
                canonical_matches(scanned),
                "{engine} {flags:?}"
            );
        }
        let no_query = cli(
            &fixture.a,
            &[
                "--stats",
                "--json",
                "--engine",
                engine,
                "-f",
                empty.to_str().unwrap(),
                "--",
                ".",
            ],
        );
        assert_eq!(no_query.status.code(), Some(1), "{no_query:?}");
        assert!(no_query.stdout.is_empty(), "{no_query:?}");
        assert!(no_query.stderr.is_empty(), "{no_query:?}");
    }
    daemon.rpc("owners.release", json!({"claim":claim}));
    drop(guard);
    stop(&mut daemon);
    drop(daemon);
    fixture.temp.close().unwrap();
}

#[test]
fn actual_legacy_core_readers_reject_staged_and_published_managed_storage() {
    let reader =
        PathBuf::from(std::env::var_os("TGREP_V1_READER").expect(
            "managed qualification requires the pinned TGREP_V1_READER; see CONTRIBUTING.md",
        ));
    let legacy =
        PathBuf::from(std::env::var_os("TGREP_V1_BINARY").expect(
            "managed qualification requires the pinned TGREP_V1_BINARY; see CONTRIBUTING.md",
        ));
    assert_ne!(
        fs::canonicalize(&legacy).unwrap(),
        fs::canonicalize(assert_cmd::cargo::cargo_bin("tgrep")).unwrap()
    );
    let fixture = Fixture::new();
    let probe = |path: &Path, expected| {
        for kind in ["reader", "shared"] {
            let result = runtime::output(Command::new(&reader).arg(kind).arg(path));
            assert_eq!(
                result.status.code(),
                Some(expected),
                "{kind} {}: {result:?}",
                path.display()
            );
        }
    };
    success(runtime::output(
        Command::new(&legacy)
            .current_dir(&fixture.a)
            .args(["index", "."]),
    ));
    probe(&fixture.a.join(".tgrep"), 0);
    probe(&fixture.temp.path().join("absent"), 1);
    fs::write(fixture.a.join("late.txt"), "managed_compatibility_fresh\n").unwrap();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let (claim, guard) = owner(&daemon);
    let input = attach_input(&fixture, &claim);
    let hook = super::faults::pause_for_operation(&daemon, "generation-built", &input["token"]);
    let operation = daemon.rpc("views.attach", input);
    super::faults::reached(&daemon, &hook);
    let page = daemon.rpc("objects.page", json!({"cursor":null}));
    let stage = page["objects"]
        .as_array()
        .unwrap()
        .iter()
        .find(|object| object["kind"] == "generation" && object["state"] == "preparing")
        .unwrap_or_else(|| panic!("fully built managed stage not present: {page}"));
    let directory = PathBuf::from(daemon.marker["storage"].as_str().unwrap())
        .join("objects")
        .join(stage["id"].as_str().unwrap());
    probe(&directory, 1);
    let renamed = fixture.temp.path().join("renamed-managed-sections");
    fs::create_dir(&renamed).unwrap();
    for (managed, old) in [
        ("paths.tgm", "files.bin"),
        ("lookup.tgm", "lookup.bin"),
        ("postings.tgm", "index.bin"),
        ("meta.tgm", "meta.json"),
    ] {
        fs::copy(directory.join(managed), renamed.join(old)).unwrap();
    }
    probe(&renamed, 1);
    daemon.rpc("testing.release", json!({"id":hook["ticket"]}));
    let attached = verified_attach(&daemon, &operation);
    assert_eq!(
        attached["result"]["current"]["current"]["incarnation"],
        stage["id"]
    );
    probe(&directory, 1);
    let storage = PathBuf::from(daemon.marker["storage"].as_str().unwrap());
    let incarnation = Id::parse(stage["id"].as_str().unwrap()).unwrap();
    let guarded = open_guarded(|| tgrep_core::managed::open_generation(&storage, &incarnation));
    assert!(
        guarded
            .base()
            .reader()
            .all_paths()
            .contains(&"notes.txt".to_owned())
    );
    drop(guarded);
    let old = runtime::output(Command::new(&legacy).current_dir(&fixture.a).args([
        "--json",
        "-F",
        "--",
        "managed_compatibility_fresh",
        ".",
    ]));
    let scan = cli(
        &fixture.a,
        &[
            "--no-index",
            "--json",
            "-F",
            "--",
            "managed_compatibility_fresh",
            ".",
        ],
    );
    assert_eq!(old.status.code(), Some(0), "{old:?}");
    assert_eq!(canonical_matches(old), canonical_matches(scan));
    assert_scan_parity(&daemon, &fixture.a, fixture.temp.path());
    daemon.rpc("owners.release", json!({"claim":claim}));
    drop(guard);
    stop(&mut daemon);
}

#[test]
fn independent_process_leases_survive_detach_and_only_proven_owner_death_reaps_abandonment() {
    let fixture = Fixture::new();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let (claim, mut child) = held_owner(&fixture, &daemon);
    let input = attach_input(&fixture, &claim);
    let accepted = manage(&fixture.a, "views.attach", input.clone());
    let first = completed(&daemon, &accepted);
    assert_eq!(
        manage(&fixture.a, "views.attach", input.clone())["id"],
        accepted["id"]
    );
    let view = &first["result"]["current"];
    let (sibling, sibling_guard) = owner(&daemon);
    let mut join = attach_input(&fixture, &sibling);
    join["request"]["revision"] = Value::Null;
    join["request"]["lease"] = json!("independent-sibling");
    join["request"]["accept_current"] = json!({"view":view["id"],"version":1});
    let second = completed(&daemon, &daemon.rpc("views.attach", join));
    assert_eq!(second["result"]["current"]["id"], view["id"]);
    assert_eq!(
        daemon.rpc("views.status", json!({"id":view["id"]}))["leases"],
        2
    );
    let detached = manage(
        &fixture.a,
        "views.detach",
        json!({"owner":claim.owner,"lease":"managed-client"}),
    );
    assert_eq!(detached["lease_released"], true);
    assert_eq!(detached["remaining_leases"], 1);
    assert_eq!(detached["root_handles_released"], false);
    assert_scan_parity(&daemon, &fixture.a, fixture.temp.path());

    let mut abandoned = input;
    abandoned["token"] = token(&claim, 2);
    abandoned["request"]["revision"] = Value::Null;
    abandoned["request"]["lease"] = json!("abandoned-client");
    abandoned["request"]["accept_current"] = json!({"view":view["id"],"version":1});
    completed(&daemon, &manage(&fixture.a, "views.attach", abandoned));
    let alive = daemon
        .try_rpc("owners.reap", json!({"id":claim.owner}))
        .unwrap();
    assert_eq!(
        alive["error"]["data"]["reason_code"], "owner-still-alive",
        "{alive}"
    );
    assert_eq!(
        daemon.rpc("views.status", json!({"id":view["id"]}))["leases"],
        2
    );
    child.cancel();
    let ended = retry_busy_response(&daemon, "owners.reap", json!({"id":claim.owner}));
    if ended.get("error").is_some() {
        assert_eq!(
            ended["error"]["data"]["category"], "receipt-expired",
            "{ended}"
        );
    } else {
        assert_eq!(ended["result"]["data"]["owner"]["released"], true);
    }
    assert_eq!(
        daemon.rpc("views.status", json!({"id":view["id"]}))["leases"],
        1
    );
    assert_scan_parity(&daemon, &fixture.a, fixture.temp.path());
    daemon.rpc(
        "views.detach",
        json!({"owner":sibling.owner,"lease":"independent-sibling"}),
    );
    daemon.rpc("owners.release", json!({"claim":sibling}));
    drop(sibling_guard);
    stop(&mut daemon);
}

#[test]
#[ignore = "subprocess entry point; requires a caller-owned TGREP_MANAGED_READER journal"]
fn guarded_reader_process() {
    let journal =
        PathBuf::from(std::env::var_os("TGREP_MANAGED_READER").expect("owned reader journal"));
    let request: Value = serde_json::from_slice(&fs::read(journal).unwrap()).unwrap();
    let namespace = PathBuf::from(request["namespace"].as_str().unwrap());
    let incarnation = Id::parse(request["incarnation"].as_str().unwrap()).unwrap();
    let generation =
        open_guarded(|| tgrep_core::managed::open_generation(&namespace, &incarnation));
    if request["candidate"] == true {
        let view = tgrep_core::worktrees::WorktreeView::new(
            Path::new(request["root"].as_str().unwrap()),
            Arc::clone(&generation),
            tgrep_core::worktrees::WorktreeOptions::default(),
        )
        .unwrap();
        view.reconcile_full().unwrap();
        let candidate = view
            .with_snapshot(|snapshot| snapshot.open_candidate("notes.txt").unwrap())
            .unwrap();
        let clone = candidate.try_clone().unwrap();
        drop((candidate, view, generation));
        println!("{}", json!({"ready":true,"kind":"escaped-candidate"}));
        std::io::stdout().flush().unwrap();
        let mut action = String::new();
        std::io::stdin().read_line(&mut action).unwrap();
        assert_eq!(action.trim(), "release");
        drop(clone);
    } else {
        let reader = Arc::clone(generation.base().reader());
        drop(generation);
        assert!(reader.all_paths().contains(&"notes.txt".to_string()));
        println!("{}", json!({"ready":true,"kind":"escaped-index-reader"}));
        std::io::stdout().flush().unwrap();
        let mut action = String::new();
        std::io::stdin().read_line(&mut action).unwrap();
        assert_eq!(action.trim(), "release");
        drop(reader);
    }
}

#[test]
#[ignore = "subprocess entry point; requires a caller-owned TGREP_MANAGED_NAMESPACE path"]
fn namespace_owner_process() {
    let path = PathBuf::from(std::env::var_os("TGREP_MANAGED_NAMESPACE").expect("owned namespace"));
    let namespace = tgrep_core::managed::Namespace::open(&path).unwrap();
    println!(
        "{}",
        json!({"ready":true,"namespace":namespace.header().namespace})
    );
    std::io::stdout().flush().unwrap();
    let mut action = String::new();
    std::io::stdin().read_line(&mut action).unwrap();
    assert_eq!(action.trim(), "release");
    drop(namespace);
}

#[test]
fn a_native_namespace_owner_excludes_startup_and_other_maintenance_until_release() {
    let fixture = Fixture::new();
    let configured = policy();
    let mut daemon = start(&fixture, &configured, &["--no-watch"]);
    let (claim, guard) = owner(&daemon);
    let original = verified_attach(
        &daemon,
        &daemon.rpc("views.attach", attach_input(&fixture, &claim)),
    );
    let namespace = PathBuf::from(daemon.marker["storage"].as_str().unwrap());
    let namespace_id = daemon.marker["namespace"].clone();
    daemon.rpc("owners.release", json!({"claim":claim}));
    drop(guard);
    stop(&mut daemon);
    drop(daemon);

    let mut holder = runtime::Process::start(
        Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "managed::clients::namespace_owner_process",
                "--ignored",
                "--nocapture",
            ])
            .env("TGREP_MANAGED_NAMESPACE", &namespace),
    );
    assert_eq!(wait_json(&mut holder, "ready")["namespace"], namespace_id);
    let policy_path = fixture.storage.join("policy.json");
    let mut starter =
        runtime::Process::start(Command::new(assert_cmd::cargo::cargo_bin("tgrep")).args([
            "serve",
            "--shared",
            fixture.a.to_str().unwrap(),
            "--shared-storage",
            fixture.storage.to_str().unwrap(),
            "--shared-policy",
            policy_path.to_str().unwrap(),
            "--no-watch",
        ]));
    let mut inspector =
        runtime::Process::start(Command::new(assert_cmd::cargo::cargo_bin("tgrep")).args([
            "shared",
            "maintenance",
            namespace.to_str().unwrap(),
            "namespace.status",
        ]));
    let request = json!({"token":{"scope":namespace_id,"sequence":1,"token":"competing-maintainer"},"request":{"cursor":null}});
    let mut maintainer =
        runtime::Process::start(Command::new(assert_cmd::cargo::cargo_bin("tgrep")).args([
            "shared",
            "maintenance",
            namespace.to_str().unwrap(),
            "maintenance.recover",
            "--params",
            &request.to_string(),
            "--apply",
        ]));
    let startup = starter.finish(Duration::from_secs(10)).unwrap();
    assert!(!startup.status.success());
    assert!(
        String::from_utf8_lossy(&startup.stderr).contains("namespace-owned"),
        "{startup:?}"
    );
    for process in [&mut inspector, &mut maintainer] {
        let output = process.finish(Duration::from_secs(10)).unwrap();
        assert_eq!(output.status.code(), Some(2), "{output:?}");
        let error: Value = serde_json::from_slice(&output.stdout).unwrap();
        assert_eq!(error["error"]["category"], "busy", "{error}");
        assert_eq!(error["error"]["reason_code"], "namespace-owned", "{error}");
        assert_eq!(
            error["error"]["committed_state"], "not-committed",
            "{error}"
        );
    }
    assert!(holder.running());
    holder.send("release");
    assert!(
        holder
            .finish(Duration::from_secs(10))
            .unwrap()
            .status
            .success()
    );
    let mut restarted = start(&fixture, &configured, &["--no-watch"]);
    let (claim, guard) = owner(&restarted);
    let current = verified_attach(
        &restarted,
        &restarted.rpc("views.attach", attach_input(&fixture, &claim)),
    );
    assert_eq!(
        current["result"]["current"]["current"],
        original["result"]["current"]["current"]
    );
    assert_scan_parity(&restarted, &fixture.a, fixture.temp.path());
    restarted.rpc("owners.release", json!({"claim":claim}));
    drop(guard);
    stop(&mut restarted);
}

fn reader_process(
    fixture: &Fixture,
    daemon: &Daemon,
    incarnation: &Value,
    candidate: bool,
) -> runtime::Process {
    let path = fixture.temp.path().join("reader.json");
    fs::write(
        &path,
        serde_json::to_vec(&json!({
            "namespace":daemon.marker["storage"],"incarnation":incarnation,"candidate":candidate,
            "root":fs::canonicalize(&fixture.a).unwrap(),
        }))
        .unwrap(),
    )
    .unwrap();
    let mut child = runtime::Process::start(
        Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "managed::clients::guarded_reader_process",
                "--ignored",
                "--nocapture",
            ])
            .env("TGREP_MANAGED_READER", path),
    );
    assert_eq!(
        wait_json(&mut child, "ready")["kind"],
        if candidate {
            "escaped-candidate"
        } else {
            "escaped-index-reader"
        }
    );
    child
}

fn collect_all(daemon: &Daemon, claim: &OwnerClaim, sequence: &mut u64) {
    let mut cursor = Value::Null;
    for _ in 0..32 {
        *sequence += 1;
        let request = json!({"token":token(claim,*sequence),"request":{
            "policy_version":1,"allocation_version":1,"cursor":cursor,
            "bounds":{"max_duration_ms":1000,"max_examined":64,"max_removed":16,
                "max_delete_bytes":1048576,"max_pages":64}
        }});
        let done = completed(daemon, &daemon.rpc("collections.start", request));
        assert_eq!(done["result"]["errors"], 0, "{done}");
        cursor = done["result"]["next"].clone();
        if cursor.is_null() {
            return;
        }
    }
    panic!("bounded collection did not finish its traversal");
}

fn removed(daemon: &Daemon, incarnation: &Value) -> bool {
    let response = daemon
        .try_rpc("objects.inspect", json!({"id":incarnation}))
        .unwrap();
    if response.get("error").is_some() {
        assert_eq!(
            response["error"]["data"]["category"], "cache-evicted",
            "{response}"
        );
        true
    } else {
        response["result"]["data"]["state"] == "removed"
    }
}

/// Probes until an outcome shows no other work. A probe that sees any, such
/// as a scheduler pass or a request still finishing, refuses the stop before
/// admission closes, so it never tests `activity.lock` for readers.
fn idle_status(daemon: &Daemon) -> Value {
    let started = Instant::now();
    loop {
        let idle = retry_busy(daemon, "stop-if-idle", idle_request(daemon));
        let other_work = [
            "leases",
            "owners",
            "reservations",
            "operations",
            "operation_readers",
        ]
        .iter()
        .any(|field| idle[*field] != 0)
            || idle["external"]
                .as_object()
                .unwrap()
                .values()
                .any(|count| *count != 0);
        if idle["stopping"] == true || !other_work {
            return idle;
        }
        assert!(
            started.elapsed() < Duration::from_secs(10),
            "other work remains visible: {idle}"
        );
        thread::sleep(Duration::from_millis(20));
    }
}

#[test]
fn escaped_cross_process_readers_block_collection_and_idle_stop_then_allow_exact_rebuild() {
    for candidate in [false, true] {
        let fixture = Fixture::new();
        let mut configured = policy();
        configured["retention"] = json!({"mode":"bounded","target_bytes":1});
        configured["collection"]["max_pages"] = json!(64);
        let mut daemon = start(&fixture, &configured, &["--no-watch"]);
        let (claim, guard) = owner(&daemon);
        verified_attach(
            &daemon,
            &daemon.rpc("views.attach", attach_input(&fixture, &claim)),
        );
        let before = daemon.rpc(
            "lookup",
            json!({"root":fs::canonicalize(&fixture.a).unwrap()}),
        );
        assert_scan_parity(&daemon, &fixture.a, fixture.temp.path());
        let mut reader = reader_process(&fixture, &daemon, &before["incarnation"], candidate);
        let detached = daemon.rpc(
            "views.detach",
            json!({"owner":claim.owner,"lease":"managed-client"}),
        );
        assert_eq!(detached["lease_released"], true);
        assert_eq!(detached["root_handles_released"], !candidate);
        let mut sequence = 1;
        collect_all(&daemon, &claim, &mut sequence);
        assert!(!removed(&daemon, &before["incarnation"]));
        assert!(
            daemon
                .rpc("objects.references", json!({"id":before["incarnation"]}))
                .as_array()
                .unwrap()
                .is_empty()
        );
        let eligibility = daemon.rpc("objects.eligibility", json!({"id":before["incarnation"]}));
        assert_eq!(eligibility["eligible"], false);
        assert!(
            eligibility["reasons"]
                .as_array()
                .unwrap()
                .contains(&json!("object-readers-active"))
        );
        daemon.rpc("owners.release", json!({"claim":claim}));
        drop(guard);
        let idle = idle_status(&daemon);
        assert_eq!(idle["stopping"], false, "{idle}");
        assert_eq!(idle["namespace_readers_or_work"], true, "{idle}");
        assert_eq!(idle["leases"], 0, "{idle}");
        reader.send("release");
        success(reader.finish(Duration::from_secs(30)).unwrap());

        let (claim, guard) = owner(&daemon);
        let mut sequence = 0;
        collect_all(&daemon, &claim, &mut sequence);
        assert!(removed(&daemon, &before["incarnation"]));
        fs::write(
            fixture.a.join("notes.txt"),
            "shared_term newer than the evicted exact pin\n",
        )
        .unwrap();
        git(&fixture.a, &["commit", "-qam", "newer checkout"]);
        sequence += 1;
        let mut input = attach_input(&fixture, &claim);
        input["token"] = token(&claim, sequence);
        verified_attach(&daemon, &daemon.rpc("views.attach", input));
        let rebuilt = daemon.rpc(
            "lookup",
            json!({"root":fs::canonicalize(&fixture.a).unwrap()}),
        );
        assert_eq!(rebuilt["commit"], fixture.revision);
        assert_ne!(rebuilt["incarnation"], before["incarnation"]);
        assert_scan_parity(&daemon, &fixture.a, fixture.temp.path());
        daemon.rpc(
            "views.detach",
            json!({"owner":claim.owner,"lease":"managed-client"}),
        );
        daemon.rpc("owners.release", json!({"claim":claim}));
        drop(guard);
        stop(&mut daemon);
    }
}

#[test]
fn owner_holder_enforces_claim_file_size_limit() {
    let fixture = Fixture::new();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let limit = tgrep_core::managed::MAX_REQUEST_BYTES;
    let path = fixture.temp.path().join("owner.claim.json");
    for (name, padded_size, suffix) in [
        ("oversized-whitespace", limit, " "),
        ("oversized-trailing-data", limit, "{}"),
        ("compact", 0, ""),
        ("below-limit", limit - 1, ""),
        ("at-limit", limit, ""),
    ] {
        let prepared = daemon.rpc("owners.prepare", json!({"token":name}));
        let claim: OwnerClaim = serde_json::from_value(prepared["claim"].clone()).unwrap();
        let mut bytes = serde_json::to_vec(&claim).unwrap();
        if padded_size != 0 {
            assert!(bytes.len() < padded_size);
            bytes.resize(padded_size, b' ');
        }
        bytes.extend_from_slice(suffix.as_bytes());
        fs::write(&path, &bytes).unwrap();
        let mut child =
            runtime::Process::start(Command::new(assert_cmd::cargo::cargo_bin("tgrep")).args([
                "shared",
                "owner-hold",
                "--claim",
                path.to_str().unwrap(),
            ]));
        if bytes.len() > limit {
            child.close_input();
            let output = child.finish(Duration::from_secs(30)).unwrap();
            assert!(!output.status.success(), "{name}: {output:?}");
            assert!(output.stdout.is_empty(), "{name}: {output:?}");
            assert!(
                String::from_utf8_lossy(&output.stderr)
                    .contains("managed owner claim exceeds its size limit"),
                "{name}: {output:?}"
            );
            let guard = OwnerGuard::claim(claim.clone()).unwrap();
            daemon.rpc("owners.register", json!({"claim":claim}));
            daemon.rpc("owners.release", json!({"claim":claim}));
            drop(guard);
        } else {
            let holding = wait_json(&mut child, "holding");
            assert_eq!(holding["claim"], prepared["claim"], "{name}");
            daemon.rpc("owners.register", json!({"claim":claim}));
            daemon.rpc("owners.release", json!({"claim":claim}));
            child.close_input();
            success(child.finish(Duration::from_secs(30)).unwrap());
        }
    }
    stop(&mut daemon);
    drop(daemon);
    fixture.temp.close().unwrap();
}

fn owner_hold(path: &Path) -> runtime::Process {
    runtime::Process::start(Command::new(assert_cmd::cargo::cargo_bin("tgrep")).args([
        "shared",
        "owner-hold",
        "--claim",
        path.to_str().unwrap(),
    ]))
}

fn stdout_lines(bytes: &[u8]) -> Vec<Value> {
    let text = std::str::from_utf8(bytes).unwrap();
    assert!(text.is_empty() || text.ends_with('\n'), "{text:?}");
    text.lines()
        .map(|line| serde_json::from_str(line).unwrap())
        .collect()
}

/// Runs a helper expected to refuse before its handshake. Like
/// `retry_catalog_busy`, the exited helper is rerun with the same claim while
/// it reports only retryable, uncommitted `busy`/`catalog-io`, which daemon
/// catalog writes can legally cause.
fn owner_hold_refusal(path: &Path) -> Output {
    let deadline = Instant::now() + CATALOG_BUSY_DEADLINE;
    loop {
        let output = owner_hold(path).finish(Duration::from_secs(30)).unwrap();
        let contended = output.status.code() == Some(2)
            && stdout_lines(&output.stdout).first().is_some_and(|frame| {
                let error = &frame["error"];
                error["category"] == "busy"
                    && error["reason_code"] == "catalog-io"
                    && error["retryable"] == true
                    && error["committed_state"] == "not-committed"
            });
        if !contended || Instant::now() >= deadline {
            return output;
        }
        thread::sleep(Duration::from_millis(20));
    }
}

/// The exact pre-handshake contract: one `{ok:false,error}` line, exit 2 and
/// the unchanged human diagnostic, never a `holding` success.
fn pre_handshake_failure(output: &Output, category: &str, reason: &str, retryable: bool) -> Value {
    assert_eq!(output.status.code(), Some(2), "{output:?}");
    let lines = stdout_lines(&output.stdout);
    assert_eq!(lines.len(), 1, "{output:?}");
    let frame = &lines[0];
    let mut keys: Vec<_> = frame
        .as_object()
        .unwrap()
        .keys()
        .map(String::as_str)
        .collect();
    keys.sort_unstable();
    assert_eq!(keys, ["error", "ok"], "{frame}");
    assert_eq!(frame["ok"], false, "{frame}");
    let error = &frame["error"];
    assert_eq!(error["category"], category, "{frame}");
    assert_eq!(error["reason_code"], reason, "{frame}");
    assert_eq!(error["retryable"], retryable, "{frame}");
    assert_eq!(error["committed_state"], "not-committed", "{frame}");
    let detail = error["detail"].as_str().unwrap();
    assert_eq!(
        String::from_utf8_lossy(&output.stderr).trim_end(),
        format!("tgrep: {reason}: {detail}"),
        "{output:?}"
    );
    error.clone()
}

fn holding_handshake(process: &mut runtime::Process, prepared: &Value) {
    let holding = wait_json(process, "holding");
    assert_eq!(holding["claim"], prepared["claim"]);
    // The success handshake is unchanged and is never preceded by a failure frame.
    assert_eq!(stdout_lines(&process.stdout()), [holding]);
}

#[test]
fn owner_holder_frames_catalog_contention_and_the_same_claim_then_holds() {
    let fixture = Fixture::new();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let prepared = daemon.rpc("owners.prepare", json!({"token":"framed-contention"}));
    let claim: OwnerClaim = serde_json::from_value(prepared["claim"].clone()).unwrap();
    let path = fixture.temp.path().join("framed-contention.claim.json");
    fs::write(&path, serde_json::to_vec(&claim).unwrap()).unwrap();

    // Hold the catalog writer until the failed helper has exited.
    let mut connection = rusqlite::Connection::open(claim.storage.join("catalog.sqlite")).unwrap();
    connection.busy_timeout(Duration::from_secs(10)).unwrap();
    let transaction = connection
        .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)
        .unwrap();
    let output = owner_hold(&path).finish(Duration::from_secs(30)).unwrap();
    transaction.rollback().unwrap();
    drop(connection);
    let error = pre_handshake_failure(&output, "busy", "catalog-io", true);
    assert_eq!(error["detail"], "database is locked");

    // The confirmed-exited helper left no claim state: the SAME claim now holds.
    let mut holder = owner_hold(&path);
    holding_handshake(&mut holder, &prepared);
    daemon.rpc("owners.register", json!({"claim":claim}));
    daemon.rpc("owners.release", json!({"claim":claim}));
    holder.close_input();
    success(holder.finish(Duration::from_secs(30)).unwrap());
    stop(&mut daemon);
    drop(daemon);
    fixture.temp.close().unwrap();
}

#[test]
fn owner_holder_frames_typed_refusals_without_inferring_retry_safety() {
    let fixture = Fixture::new();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let prepared = daemon.rpc("owners.prepare", json!({"token":"framed-refusals"}));
    let claim: OwnerClaim = serde_json::from_value(prepared["claim"].clone()).unwrap();
    let path = fixture.temp.path().join("framed-refusals.claim.json");
    fs::write(&path, serde_json::to_vec(&claim).unwrap()).unwrap();

    // A live holder's OS lock is reported as typed busy; the holder is unaffected.
    let mut holder = owner_hold(&path);
    holding_handshake(&mut holder, &prepared);
    let output = owner_hold_refusal(&path);
    pre_handshake_failure(&output, "busy", "owner-guard-already-held", true);
    assert!(holder.running());
    daemon.rpc("owners.register", json!({"claim":claim}));
    daemon.rpc("owners.release", json!({"claim":claim}));
    holder.close_input();
    success(holder.finish(Duration::from_secs(30)).unwrap());

    // An ended lifetime is framed as non-retryable, never as a fresh claim.
    // Housekeeping may already have removed the released owner record, which
    // reports the same stale identity as retired.
    let output = owner_hold_refusal(&path);
    let reason = stdout_lines(&output.stdout)
        .first()
        .and_then(|frame| frame["error"]["reason_code"].as_str().map(str::to_owned))
        .unwrap_or_default();
    assert!(
        matches!(reason.as_str(), "owner-lifetime-ended" | "owner-retired"),
        "{output:?}"
    );
    pre_handshake_failure(&output, "stale-identity", &reason, false);

    // Untyped claim-file failures have no managed classification and stay unframed.
    for (name, bytes) in [
        ("malformed", b"{".to_vec()),
        (
            "unknown-field",
            serde_json::to_vec(&{
                let mut value = prepared["claim"].clone();
                value["unexpected"] = json!(true);
                value
            })
            .unwrap(),
        ),
    ] {
        let path = fixture.temp.path().join(format!("{name}.claim.json"));
        fs::write(&path, bytes).unwrap();
        let output = owner_hold(&path).finish(Duration::from_secs(30)).unwrap();
        assert_eq!(output.status.code(), Some(2), "{name}: {output:?}");
        assert!(output.stdout.is_empty(), "{name}: {output:?}");
        assert!(
            String::from_utf8_lossy(&output.stderr).starts_with("tgrep: "),
            "{name}: {output:?}"
        );
    }
    stop(&mut daemon);
    drop(daemon);
    fixture.temp.close().unwrap();
}

#[test]
fn owner_holder_graceful_eof_releases_its_os_proof_without_guessing_process_identity() {
    let fixture = Fixture::new();
    let mut daemon = start(&fixture, &policy(), &["--no-watch"]);
    let (claim, mut child) = held_owner(&fixture, &daemon);
    let alive = daemon
        .try_rpc("owners.reap", json!({"id":claim.owner}))
        .unwrap();
    assert_eq!(alive["error"]["data"]["reason_code"], "owner-still-alive");
    child.close_input();
    success(child.finish(Duration::from_secs(30)).unwrap());
    let ended = retry_busy_response(&daemon, "owners.reap", json!({"id":claim.owner}));
    if ended.get("error").is_some() {
        assert_eq!(
            ended["error"]["data"]["category"], "receipt-expired",
            "{ended}"
        );
    } else {
        assert_eq!(ended["result"]["data"]["owner"]["released"], true);
    }
    stop(&mut daemon);
}

#[test]
fn a_missing_evicted_exact_commit_never_substitutes_a_newer_head_and_scans_explicitly() {
    let fixture = Fixture::new();
    let mut configured = policy();
    configured["retention"] = json!({"mode":"bounded","target_bytes":1});
    configured["collection"]["max_pages"] = json!(64);
    let mut daemon = start(&fixture, &configured, &["--no-watch"]);
    let (claim, guard) = owner(&daemon);
    verified_attach(
        &daemon,
        &daemon.rpc("views.attach", attach_input(&fixture, &claim)),
    );
    let original = daemon.rpc(
        "lookup",
        json!({"root":fs::canonicalize(&fixture.a).unwrap()}),
    );
    daemon.rpc(
        "views.detach",
        json!({"owner":claim.owner,"lease":"managed-client"}),
    );
    let mut sequence = 1;
    collect_all(&daemon, &claim, &mut sequence);
    assert!(removed(&daemon, &original["incarnation"]));
    fs::write(
        fixture.a.join("notes.txt"),
        "shared_term newer valid worktree\n",
    )
    .unwrap();
    git(&fixture.a, &["commit", "-qam", "newer exact target"]);
    let newer = git(&fixture.a, &["rev-parse", "HEAD"]);
    let repository = tgrep_core::generations::Repository::discover(&fixture.a).unwrap();
    let object = repository
        .common_dir()
        .join("objects")
        .join(&fixture.revision[..2])
        .join(&fixture.revision[2..]);
    assert!(
        object.is_file(),
        "the owned fixture must have a loose initial commit"
    );
    #[cfg(windows)]
    #[allow(
        clippy::permissions_set_readonly_false,
        reason = "Windows-only removal of an owned fixture's read-only Git object."
    )]
    {
        let mut permissions = fs::metadata(&object).unwrap().permissions();
        permissions.set_readonly(false);
        fs::set_permissions(&object, permissions).unwrap();
    }
    fs::remove_file(object).unwrap();
    let mut request = attach_input(&fixture, &claim);
    sequence += 1;
    request["token"] = token(&claim, sequence);
    request["request"]["lease"] = json!("unavailable-target");
    let failed = terminal(&daemon, &manage(&fixture.a, "views.attach", request));
    assert_eq!(
        failed["error"]["category"], "git-objects-unavailable",
        "{failed}"
    );
    assert_eq!(failed["committed_state"], "not-committed");
    let scan = cli(&fixture.a, &["--json", "-F", "--", "shared_term", "."]);
    assert!(
        String::from_utf8_lossy(&scan.stderr).contains("scanning"),
        "{scan:?}"
    );
    let forced = cli(
        &fixture.a,
        &["--no-index", "--json", "-F", "--", "shared_term", "."],
    );
    let rows = |output: Output| {
        let mut rows: Vec<_> = success(output)
            .lines()
            .map(|line| serde_json::from_str::<Value>(line).unwrap())
            .filter(|row| row["type"] == "match")
            .map(|row| row["data"].clone())
            .collect();
        rows.sort_by_key(Value::to_string);
        rows
    };
    assert_eq!(rows(scan), rows(forced));
    sequence += 1;
    let mut request = attach_input(&fixture, &claim);
    request["token"] = token(&claim, sequence);
    request["request"]["revision"] = json!(newer);
    request["request"]["lease"] = json!("available-target");
    // The daemon's catalog writes may contend with this attachment; the
    // documented client contract retries that with a fresh token.
    let attached = super::attach_retry::retry_attach(
        &daemon,
        &claim,
        None,
        request,
        super::attach_retry::Retry {
            point: "available exact target",
            deadline: Instant::now() + Duration::from_secs(30),
            allowance: super::attach_retry::RetryableAttach::CatalogIo,
        },
        |_| {},
    )
    .unwrap_or_else(|failures| {
        panic!("available exact target: attachment exhausted its retry bound: {failures:?}")
    });
    verified(&daemon, attached);
    let available = daemon.rpc(
        "lookup",
        json!({"root":fs::canonicalize(&fixture.a).unwrap()}),
    );
    assert_eq!(available["commit"], newer);
    assert_ne!(available["incarnation"], original["incarnation"]);
    assert_scan_parity(&daemon, &fixture.a, fixture.temp.path());
    daemon.rpc(
        "views.detach",
        json!({"owner":claim.owner,"lease":"available-target"}),
    );
    daemon.rpc("owners.release", json!({"claim":claim}));
    drop(guard);
    stop(&mut daemon);
}
