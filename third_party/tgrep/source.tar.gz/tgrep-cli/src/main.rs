#![deny(unnameable_test_items)]

/// tgrep — trigram-indexed grep with client/server architecture.
///
/// Usage:
///   tgrep index [path]           Build the trigram index
///   tgrep serve [path]           Start the search server
///   tgrep <pattern> [path]       Search (auto-delegates to server)
///   tgrep status [path]          Show index/server status
mod cpu;
mod glob_filter;
mod index;
mod matching;
mod mem;
mod output;
mod search;
mod serve;
mod status;
mod walkcount;

use std::path::PathBuf;
use std::process;
use std::sync::atomic::AtomicBool;
use std::time::Duration;

use anyhow::Result;
use clap::{CommandFactory, FromArgMatches, Parser, Subcommand};
use output::ColorMode;
use tgrep_core::builder;

/// Set when anything is reported to stderr, mirroring ripgrep's `messages`
/// module, which drives the exit code.
static ERRORED: AtomicBool = AtomicBool::new(false);

#[derive(Parser)]
#[command(
    name = "tgrep",
    about = "Trigram-indexed grep — fast regex search for large codebases",
    version
)]
struct Cli {
    #[command(subcommand)]
    command: Option<Command>,

    /// Search pattern (when not using a subcommand).
    #[arg(global = false)]
    pattern: Option<String>,

    /// Root directories or files to search.
    #[arg(global = false, value_name = "PATH", num_args = 0..)]
    paths: Vec<String>,

    // ── Matching ──────────────────────────────────────
    /// Case-insensitive matching. The last of -i, -s and -S wins.
    #[arg(
        short = 'i',
        long = "ignore-case",
        global = true,
        overrides_with_all = ["case_sensitive", "smart_case"]
    )]
    ignore_case: bool,

    /// Force case-sensitive matching. The last of -i, -s and -S wins.
    #[arg(
        short = 's',
        long = "case-sensitive",
        global = true,
        overrides_with_all = ["ignore_case", "smart_case"]
    )]
    case_sensitive: bool,

    /// Smart case: case-insensitive when patterns have literals but no uppercase literals.
    /// The last of -i, -s and -S wins.
    #[arg(
        short = 'S',
        long = "smart-case",
        global = true,
        overrides_with_all = ["ignore_case", "case_sensitive"]
    )]
    smart_case: bool,

    /// Treat pattern as a literal string.
    #[arg(short = 'F', long = "fixed-strings", global = true)]
    fixed_strings: bool,

    /// Match only when neither adjacent character is a word character. Overrides -x.
    #[arg(
        short = 'w',
        long = "word-regexp",
        global = true,
        group = "match_boundary",
        overrides_with = "line_regexp"
    )]
    word_regexp: bool,

    /// Invert match: show lines that do NOT match.
    #[arg(short = 'v', long = "invert-match", global = true)]
    invert_match: bool,

    /// Additional patterns (can be specified multiple times).
    #[arg(short = 'e', long = "regexp", global = true, action = clap::ArgAction::Append)]
    regexp: Vec<String>,

    /// Read patterns verbatim, one per line. Empty lines match every input line.
    /// Repeatable; combines with -e in command-line order.
    #[arg(short = 'f', long = "file", global = true, action = clap::ArgAction::Append)]
    pattern_file: Vec<String>,

    /// `-e` and `-f` in command-line order, across command scopes.
    #[arg(skip)]
    pattern_sources: Vec<search::PatternSource>,

    /// Enable multiline matching (patterns may span line boundaries).
    #[arg(short = 'U', long = "multiline", global = true)]
    multiline: bool,

    /// Allow `.` to match a newline. Implies --multiline.
    #[arg(long = "multiline-dotall", global = true)]
    multiline_dotall: bool,

    // ── Output mode ──────────────────────────────────
    /// Print only filenames with matches.
    #[arg(short = 'l', long = "files-with-matches", global = true)]
    files_only: bool,

    /// Print files that do NOT match the pattern.
    #[arg(long = "files-without-match", global = true)]
    files_without_match: bool,

    /// Print match count per file.
    #[arg(short = 'c', long = "count", global = true)]
    count: bool,

    /// Print only the matched parts of a line.
    #[arg(short = 'o', long = "only-matching", global = true)]
    only_matching: bool,

    /// Limit matches per file.
    #[arg(short = 'm', long = "max-count", global = true)]
    max_count: Option<usize>,

    /// List files that would be searched (no search performed).
    #[arg(long = "files", global = true)]
    list_files: bool,

    /// Suppress all output; exit code only (0 = match found, 1 = no match).
    #[arg(short = 'q', long = "quiet", global = true)]
    quiet: bool,

    // ── Filtering ────────────────────────────────────
    /// Filter files by glob pattern (can be specified multiple times).
    ///
    /// With an index, globs filter the indexed corpus. Use --no-index to let
    /// positive globs reinclude ignored files.
    #[arg(short = 'g', long = "glob", global = true, action = clap::ArgAction::Append)]
    glob: Vec<String>,

    /// Like --glob, but case-insensitive.
    #[arg(long = "iglob", global = true, action = clap::ArgAction::Append)]
    iglob: Vec<String>,

    /// Treat all --glob patterns as case-insensitive.
    #[arg(long = "glob-case-insensitive", global = true)]
    glob_case_insensitive: bool,

    /// Filter files by type (e.g., rust, py, js). Repeatable. Use --type-list to see all.
    /// A glob that matches a file overrides -t and -T.
    #[arg(short = 't', long = "type", global = true, action = clap::ArgAction::Append)]
    file_type: Vec<String>,

    /// Exclude files matching a type. Repeatable; when -t and -T both match a
    /// file, the one given last wins.
    #[arg(short = 'T', long = "type-not", global = true, action = clap::ArgAction::Append)]
    type_not: Vec<String>,

    /// Add or extend a type: `name:glob` or `name:include:type1,type2`.
    #[arg(long = "type-add", global = true, value_name = "SPEC", action = clap::ArgAction::Append)]
    type_add: Vec<String>,

    /// Remove all globs for a type. --type-add and --type-clear apply in
    /// command-line order, so clear a type before redefining it.
    #[arg(long = "type-clear", global = true, value_name = "NAME", action = clap::ArgAction::Append)]
    type_clear: Vec<String>,

    /// `-t`, `-T`, `--type-add` and `--type-clear` in command-line order.
    #[arg(skip)]
    type_ops: Vec<tgrep_core::filetypes::TypeOp>,

    /// Print all supported file types.
    #[arg(long = "type-list", global = true)]
    type_list: bool,

    /// Ignore files larger than NUM bytes (suffixes K, M, G allowed).
    /// Defaults to 64M; use --no-max-filesize for no limit.
    #[arg(
        long = "max-filesize",
        global = true,
        value_name = "NUM",
        overrides_with = "no_max_filesize"
    )]
    max_filesize: Option<String>,

    /// Apply no file size limit, as ripgrep does.
    #[arg(
        long = "no-max-filesize",
        global = true,
        overrides_with = "max_filesize"
    )]
    no_max_filesize: bool,

    /// Text encoding to use: `auto` (BOM sniffing), `none`, or a label like `utf-16le`.
    #[arg(
        short = 'E',
        long = "encoding",
        global = true,
        value_name = "ENCODING",
        overrides_with = "no_encoding"
    )]
    encoding: Option<String>,

    /// Reset --encoding back to `auto`.
    #[arg(long = "no-encoding", global = true, overrides_with = "encoding")]
    no_encoding: bool,

    /// Search binary files as if they were text.
    #[arg(short = 'a', long = "text", global = true)]
    text: bool,

    // ── Context ──────────────────────────────────────
    /// Lines of context after each match.
    #[arg(short = 'A', long = "after-context", global = true)]
    after_context: Option<usize>,

    /// Lines of context before each match.
    #[arg(short = 'B', long = "before-context", global = true)]
    before_context: Option<usize>,

    /// Lines of context before and after each match.
    #[arg(short = 'C', long = "context", global = true)]
    context: Option<usize>,

    /// Print the file name for each match (default behavior, ripgrep compatibility).
    #[arg(short = 'H', long = "with-filename", global = true)]
    with_filename: bool,

    /// Suppress filenames in output.
    #[arg(short = 'I', long = "no-filename", global = true)]
    no_filename: bool,

    /// Show line numbers (default behavior, ripgrep compatibility).
    #[arg(short = 'n', long = "line-number", global = true)]
    line_number: bool,

    /// Suppress line numbers in output.
    #[arg(short = 'N', long = "no-line-number", global = true)]
    no_line_number: bool,

    // ── Output formatting ────────────────────────────
    /// Group matches by file with heading.
    #[arg(long = "heading", global = true)]
    heading: bool,

    /// Don't group matches; flat output.
    #[arg(long = "no-heading", global = true)]
    no_heading: bool,

    /// JSON output (one object per line).
    #[arg(long = "json", global = true)]
    json: bool,

    /// Output in vim-compatible format (file:line:col:content).
    #[arg(long = "vimgrep", global = true)]
    vimgrep: bool,

    /// Color mode: auto, always, or never.
    #[arg(long = "color", default_value = "auto", global = true)]
    color: String,

    /// Follow each printed file path with a NUL byte (for xargs -0).
    #[arg(short = '0', long = "null", global = true)]
    null: bool,

    /// Trim leading ASCII whitespace from each printed line.
    #[arg(long = "trim", global = true)]
    trim: bool,

    // ── Index control ────────────────────────────────
    /// Print query plan and timing stats.
    #[arg(long = "stats", global = true)]
    stats: bool,

    /// Skip the index, grep all files directly.
    #[arg(long = "no-index", global = true)]
    no_index: bool,

    /// Require shared-worktree discovery; unavailable/incompatible views scan.
    #[arg(long, global = true)]
    shared: bool,

    /// Custom index directory.
    #[arg(long = "index-path", global = true)]
    index_path: Option<PathBuf>,

    // ── File discovery ───────────────────────────────
    /// Include hidden files and directories.
    #[arg(short = '.', long = "hidden", global = true)]
    hidden: bool,

    /// Don't respect .gitignore or p4ignore.ini files.
    #[arg(long = "no-ignore", global = true)]
    no_ignore: bool,

    /// Follow symbolic links while searching.
    #[arg(short = 'L', long = "follow", global = true)]
    follow: bool,

    /// Suppress error messages about nonexistent or unreadable files.
    #[arg(long = "no-messages", global = true)]
    no_messages: bool,

    /// Unrestricted search. -u = no-ignore, -uu = +hidden, -uuu = +binary.
    #[arg(short = 'u', long = "unrestricted", action = clap::ArgAction::Count, global = true)]
    unrestricted: u8,

    /// Search binary files, reporting a note instead of printing their lines.
    #[arg(long = "binary", global = true)]
    binary: bool,

    /// Which files may be searched for content. `extensions` (default) skips
    /// filename extensions such as `.pdf` or `.doc` before reading them;
    /// `content` decides by content alone, still skipping files with NUL
    /// bytes. Indexed search uses only a managed shared view attached with
    /// the matching profile; otherwise tgrep scans.
    #[arg(
        long = "content-eligibility",
        global = true,
        value_enum,
        default_value_t = ContentEligibilityArg::Extensions
    )]
    content_eligibility: ContentEligibilityArg,

    // ── Matching ─────────────────────────────────────
    /// Only match when the whole line matches the pattern. Overrides -w.
    #[arg(
        short = 'x',
        long = "line-regexp",
        global = true,
        group = "match_boundary",
        overrides_with = "word_regexp"
    )]
    line_regexp: bool,

    /// Use the PCRE-style engine, enabling lookaround and backreferences.
    #[arg(short = 'P', long = "pcre2", global = true)]
    pcre2: bool,

    /// Regex engine to use: default, pcre2, or auto.
    #[arg(
        long = "engine",
        value_name = "ENGINE",
        default_value = "auto",
        global = true
    )]
    engine: String,

    /// Print the PCRE-style engine version and exit.
    #[arg(long = "pcre2-version", global = true)]
    pcre2_version: bool,

    /// Disable Unicode-aware matching.
    #[arg(long = "no-unicode", global = true)]
    no_unicode: bool,

    /// Upper size limit for the compiled regex (suffixes K, M, G allowed).
    #[arg(long = "regex-size-limit", value_name = "NUM", global = true)]
    regex_size_limit: Option<String>,

    /// Upper size limit for the regex DFA cache (suffixes K, M, G allowed).
    #[arg(long = "dfa-size-limit", value_name = "NUM", global = true)]
    dfa_size_limit: Option<String>,

    /// Replace each match with TEXT. Capture groups are available as $1, ${name}.
    #[arg(short = 'r', long = "replace", value_name = "TEXT", global = true)]
    replace: Option<String>,

    /// Print both matching and non-matching lines.
    #[arg(long = "passthru", global = true)]
    passthru: bool,

    /// Stop searching a file after a line that does not match.
    #[arg(long = "stop-on-nonmatch", global = true)]
    stop_on_nonmatch: bool,

    // ── Output detail ────────────────────────────────
    /// Show the column number of the first match on each line.
    #[arg(long = "column", global = true, overrides_with = "no_column")]
    column: bool,

    /// Don't show column numbers.
    #[arg(long = "no-column", global = true, overrides_with = "column")]
    no_column: bool,

    /// Print the 0-based byte offset of each output line.
    #[arg(short = 'b', long = "byte-offset", global = true)]
    byte_offset: bool,

    /// Don't print lines longer than NUM bytes.
    #[arg(short = 'M', long = "max-columns", value_name = "NUM", global = true)]
    max_columns: Option<usize>,

    /// Print a truncated preview instead of suppressing a long line entirely.
    #[arg(long = "max-columns-preview", global = true)]
    max_columns_preview: bool,

    /// Count individual matches instead of matching lines.
    #[arg(long = "count-matches", global = true)]
    count_matches: bool,

    /// Print a count of zero for files with no match.
    #[arg(long = "include-zero", global = true)]
    include_zero: bool,

    /// Alias for --color always --heading --line-number.
    #[arg(short = 'p', long = "pretty", global = true)]
    pretty: bool,

    /// String printed between non-contiguous context blocks.
    #[arg(long = "context-separator", value_name = "SEP", global = true)]
    context_separator: Option<String>,

    /// Never print a context separator.
    #[arg(long = "no-context-separator", global = true)]
    no_context_separator: bool,

    /// Separator between the path/line/column fields of a matching line.
    #[arg(long = "field-match-separator", value_name = "SEP", global = true)]
    field_match_separator: Option<String>,

    /// Separator between the path/line/column fields of a context line.
    #[arg(long = "field-context-separator", value_name = "SEP", global = true)]
    field_context_separator: Option<String>,

    /// Character to use as the path separator in output.
    #[arg(long = "path-separator", value_name = "SEP", global = true)]
    path_separator: Option<String>,

    /// Sort results. Choices: none, path, modified, accessed, created.
    #[arg(long = "sort", value_name = "SORTBY", global = true)]
    sort: Option<String>,

    /// Sort results in descending order. Same choices as --sort.
    #[arg(long = "sortr", value_name = "SORTBY", global = true)]
    sortr: Option<String>,

    /// Deprecated alias for --sort path.
    #[arg(long = "sort-files", global = true)]
    sort_files: bool,

    // ── File discovery (advanced) ────────────────────
    /// Descend at most NUM directories below each search path.
    #[arg(long = "max-depth", value_name = "NUM", global = true)]
    max_depth: Option<usize>,

    /// Don't cross file system boundaries.
    #[arg(long = "one-file-system", global = true)]
    one_file_system: bool,

    /// Read extra ignore globs from PATH. Repeatable; later files take precedence.
    #[arg(long = "ignore-file", value_name = "PATH", global = true, action = clap::ArgAction::Append)]
    ignore_file: Vec<String>,

    /// Match --ignore-file globs case-insensitively.
    #[arg(long = "ignore-file-case-insensitive", global = true)]
    ignore_file_case_insensitive: bool,

    /// Don't respect .ignore files.
    #[arg(long = "no-ignore-dot", global = true)]
    no_ignore_dot: bool,

    /// Don't respect .git/info/exclude.
    #[arg(long = "no-ignore-exclude", global = true)]
    no_ignore_exclude: bool,

    /// Don't respect --ignore-file arguments.
    #[arg(long = "no-ignore-files", global = true)]
    no_ignore_files: bool,

    /// Don't respect the global gitignore.
    #[arg(long = "no-ignore-global", global = true)]
    no_ignore_global: bool,

    /// Suppress messages about unparseable ignore files.
    #[arg(long = "no-ignore-messages", global = true)]
    no_ignore_messages: bool,

    /// Don't respect ignore files in parent directories.
    #[arg(long = "no-ignore-parent", global = true)]
    no_ignore_parent: bool,

    /// Don't respect .gitignore files.
    #[arg(long = "no-ignore-vcs", global = true)]
    no_ignore_vcs: bool,

    /// Respect .gitignore files even outside a git repository.
    #[arg(long = "no-require-git", global = true)]
    no_require_git: bool,

    // ── Accepted for ripgrep compatibility ───────────
    /// Number of threads to use. tgrep sizes its pool automatically.
    #[arg(short = 'j', long = "threads", value_name = "NUM", global = true)]
    threads: Option<usize>,

    /// Accepted for compatibility; tgrep always reads files directly.
    #[arg(long = "mmap", global = true, overrides_with = "no_mmap")]
    mmap: bool,

    /// Accepted for compatibility; tgrep always reads files directly.
    #[arg(long = "no-mmap", global = true, overrides_with = "mmap")]
    no_mmap: bool,

    /// Flush output on every line.
    #[arg(
        long = "line-buffered",
        global = true,
        overrides_with = "block_buffered"
    )]
    line_buffered: bool,

    /// Buffer output in blocks (the default when not writing to a terminal).
    #[arg(
        long = "block-buffered",
        global = true,
        overrides_with = "line_buffered"
    )]
    block_buffered: bool,

    /// Accepted for compatibility; tgrep reads no configuration file.
    #[arg(long = "no-config", global = true)]
    no_config: bool,

    /// Accepted for compatibility; tgrep's colors are not configurable yet.
    #[arg(long = "colors", value_name = "SPEC", global = true, action = clap::ArgAction::Append)]
    colors: Vec<String>,

    /// Print debug messages to stderr (implies `--stats`).
    #[arg(long = "debug", global = true)]
    debug: bool,

    /// Print verbose trace messages to stderr (implies `--stats`).
    #[arg(long = "trace", global = true)]
    trace: bool,

    /// Accepted for compatibility; tgrep always strips a trailing `\r`.
    #[arg(long = "crlf", global = true, overrides_with = "no_crlf")]
    crlf: bool,

    /// Accepted for compatibility; tgrep always strips a trailing `\r`.
    #[arg(long = "no-crlf", global = true, overrides_with = "crlf")]
    no_crlf: bool,

    /// Not supported: tgrep does not decompress archives before searching.
    #[arg(short = 'z', long = "search-zip", global = true)]
    search_zip: bool,
}

/// Every argument that needs parsing and can fail, resolved once up front.
struct ResolvedArgs {
    max_filesize: Option<u64>,
    /// Whether the size limit was asked for rather than inherited from
    /// [`tgrep_core::walker::DEFAULT_MAX_FILE_SIZE`]. A file named directly on
    /// the command line ignores the inherited limit — pointing at a file is an
    /// unambiguous request to search it — but honours one the user set.
    max_filesize_requested: bool,
    encoding: tgrep_core::encoding::EncodingMode,
    engine: matching::RegexEngine,
    regex_size_limit: Option<usize>,
    dfa_size_limit: Option<usize>,
    sort: Option<search::SortMode>,
}

/// Parse a `--sort`/`--sortr` value. `none` means "leave results unordered".
fn parse_sort(key: &str, reverse: bool) -> Result<Option<search::SortMode>> {
    if key == "none" {
        return Ok(None);
    }
    let key = search::SortKey::from_str_opt(key)
        .ok_or_else(|| anyhow::anyhow!("unrecognized sort criteria: {key}"))?;
    Ok(Some(search::SortMode { key, reverse }))
}

/// Parse a byte size, accepting K/M/G suffixes like ripgrep.
///
/// `flag` names the option in the error message so a bad `--regex-size-limit`
/// does not report a problem with `--max-filesize`.
fn parse_byte_size(flag: &str, s: &str) -> Result<u64> {
    let s = s.trim();
    let (digits, mult) = match s.chars().last() {
        Some('K') | Some('k') => (&s[..s.len() - 1], 1024u64),
        Some('M') | Some('m') => (&s[..s.len() - 1], 1024 * 1024),
        Some('G') | Some('g') => (&s[..s.len() - 1], 1024 * 1024 * 1024),
        _ => (s, 1),
    };
    let n: u64 = digits
        .trim()
        .parse()
        .map_err(|_| anyhow::anyhow!("invalid {flag} value: {s}"))?;
    n.checked_mul(mult)
        .ok_or_else(|| anyhow::anyhow!("{flag} value is too large: {s}"))
}

/// Parse a size limit that the regex engines take as a `usize`.
///
/// ripgrep stores these limits as `usize` and rejects a value that does not
/// fit ("size is too big") instead of truncating it. Truncating would apply a
/// silently different limit than the one asked for on a 32-bit target, so
/// reject it here too.
fn parse_size_limit(flag: &str, s: &str) -> Result<usize> {
    let bytes = parse_byte_size(flag, s)?;
    usize::try_from(bytes)
        .map_err(|_| anyhow::anyhow!("{flag} value is too large for this platform: {s}"))
}

/// Content eligibility for searches (`--content-eligibility`).
#[derive(Copy, Clone, Debug, PartialEq, Eq, clap::ValueEnum)]
enum ContentEligibilityArg {
    /// Skip known binary filename extensions, then decide by content.
    Extensions,
    /// Decide by content alone.
    Content,
}

impl From<ContentEligibilityArg> for tgrep_core::generations::ContentEligibility {
    fn from(value: ContentEligibilityArg) -> Self {
        match value {
            ContentEligibilityArg::Extensions => Self::ExtensionAndContent,
            ContentEligibilityArg::Content => Self::ContentOnly,
        }
    }
}

/// Posting accumulation strategy for `tgrep index`.
#[derive(Copy, Clone, Debug, PartialEq, Eq, clap::ValueEnum)]
enum IndexStrategyArg {
    /// Accumulate all postings in memory and sort once.
    Memory,
    /// Bound peak memory with an external merge sort that spills to disk.
    External,
}

impl From<IndexStrategyArg> for builder::IndexStrategy {
    fn from(value: IndexStrategyArg) -> Self {
        match value {
            IndexStrategyArg::Memory => Self::InMemory,
            IndexStrategyArg::External => Self::External,
        }
    }
}

#[derive(Subcommand)]
enum Command {
    /// Build or rebuild the trigram index.
    Index {
        /// Root directory to index.
        #[arg(default_value = ".")]
        path: PathBuf,

        /// Force a full rebuild.
        #[arg(long)]
        force: bool,

        /// Exclude directories from indexing (can be specified multiple times).
        #[arg(long = "exclude", action = clap::ArgAction::Append)]
        exclude: Vec<String>,

        /// How postings are accumulated during the build.
        ///
        /// `external` (default) bounds peak memory with an external merge
        /// sort, spilling sorted segments to disk when the arena fills. If the
        /// arena never fills it is identical to `memory`, so small repos are
        /// unaffected. `memory` holds every posting in RAM and sorts once;
        /// peak memory then grows with repo size, unbounded.
        #[arg(
            long = "index-strategy",
            value_name = "STRATEGY",
            default_value = "external"
        )]
        strategy: IndexStrategyArg,

        /// Arena size in megabytes before `--index-strategy=external` spills to
        /// disk. Lower values reduce peak memory at the cost of more spill
        /// segments to merge. Ignored by `--index-strategy=memory`.
        #[arg(long = "index-buffer", value_name = "MB", value_parser = clap::value_parser!(u64).range(1..))]
        index_buffer_mb: Option<u64>,
    },

    /// Start the persistent search server.
    Serve {
        /// Root directory to serve.
        #[arg(default_value = ".")]
        path: PathBuf,

        /// Existing trusted external directory for shared bases and checkpoints.
        #[arg(long, requires = "shared")]
        shared_storage: Option<PathBuf>,

        /// Use managed v2 (recommended) with a complete validated policy JSON file.
        /// Without this policy, --shared selects deprecated v1.
        #[arg(long, value_name = "FILE", requires_all = ["shared", "shared_storage"], conflicts_with_all = ["shared_max_views", "shared_max_leases", "max_memory_mb", "max_cpu_percent"])]
        shared_policy: Option<PathBuf>,

        /// Maximum shared views; native watches and hint slots are divided by this.
        #[arg(long, requires = "shared", default_value_t = 32, value_parser = clap::value_parser!(u32).range(1..=1024))]
        shared_max_views: u32,

        /// Maximum leases across all attached worktrees.
        #[arg(long, requires = "shared", default_value_t = 256, value_parser = clap::value_parser!(u32).range(1..=65536))]
        shared_max_leases: u32,

        /// Disable all automatic refresh, including watching and polling.
        #[arg(long, conflicts_with_all = ["watch_mode", "poll_interval", "watch_budget"])]
        no_watch: bool,

        /// Use native notifications with automatic polling fallback, or polling only.
        #[arg(long, value_enum, default_value = "auto", value_name = "MODE")]
        watch_mode: serve::WatchMode,

        /// Seconds to wait after a polling reconciliation completes (1-86400).
        /// Managed v2 also uses it to verify healthy native views while they serve.
        #[arg(
            long,
            default_value_t = 120,
            value_name = "SECONDS",
            value_parser = clap::value_parser!(u64).range(1..=86400)
        )]
        poll_interval: u64,

        /// Process-local native watch ceiling, not available shared OS capacity.
        #[arg(
            long,
            default_value_t = 8192,
            value_name = "N",
            value_parser = clap::value_parser!(u32).range(1..)
        )]
        watch_budget: u32,

        /// Maximum memory budget in megabytes for the in-memory index built
        /// during the initial scan. When the indexer's working set exceeds
        /// this, it flushes to disk and continues, keeping peak memory bounded
        /// while still producing a complete index. Defaults to 50% of physical
        /// RAM (clamped between 512 MB and 16 GB).
        #[arg(long = "max-memory", value_name = "MB", value_parser = clap::value_parser!(u64).range(1..))]
        max_memory_mb: Option<u64>,

        /// Maximum CPU budget for the initial index build, as a percentage of
        /// logical cores (1-100). The parallel file-reading/trigram-extraction
        /// work is confined to this fraction of cores so the host stays
        /// responsive. Defaults to 50%.
        #[arg(long = "max-cpu", value_name = "PERCENT")]
        max_cpu_percent: Option<u8>,

        /// Exclude directories from indexing (can be specified multiple times).
        #[arg(long = "exclude", action = clap::ArgAction::Append)]
        exclude: Vec<String>,

        /// Number of accumulated index mutations that triggers a background
        /// save. Higher values reduce save frequency (and the pauses they
        /// cause during heavy churn) at the cost of more unsaved work if the
        /// process is killed. Defaults to 5000.
        #[arg(long = "auto-save-mutations", value_name = "N", value_parser = clap::value_parser!(u32).range(1..))]
        auto_save_mutations: Option<u32>,

        /// Maximum number of filesystem events buffered between the OS
        /// watcher and the indexing worker. Raise it if bulk changes (branch
        /// switches, builds) log watcher queue overflows; each overflow costs
        /// a full stale check instead of incremental updates. Defaults to
        /// 16384.
        // Bounded by `usize::MAX` so the value always survives the conversion
        // at the call site. Without it, a value above `usize::MAX` would
        // truncate on a 32-bit target — and truncating to 0 turns the
        // watcher's `sync_channel` into a rendezvous channel, where every
        // `try_send` fails and no event is ever delivered. Plain `//` so the
        // rationale stays out of `--help`.
        #[arg(
            long = "watcher-queue-cap",
            value_name = "N",
            value_parser = clap::value_parser!(u64).range(1..=usize::MAX as u64)
        )]
        watcher_queue_cap: Option<u64>,
    },

    /// Explicit shared-worktree attachment lifecycle (JSON output).
    Shared {
        #[command(subcommand)]
        command: serve::shared::Lifecycle,
    },

    /// Search for a pattern.
    Search {
        /// The regex pattern to search for.
        pattern: String,

        /// Root directories or files to search.
        #[arg(value_name = "PATH", num_args = 0..)]
        paths: Vec<String>,
    },

    /// Show index and server status.
    Status {
        /// Root directory.
        #[arg(default_value = ".")]
        path: PathBuf,
    },

    /// Count text files in a directory (fast walker, no indexing).
    CountFiles {
        /// Root directory to scan.
        #[arg(default_value = ".")]
        path: PathBuf,
    },
}

/// Flags whose relative order changes the result, by clap id.
const ORDERED_ARGS: [&str; 9] = [
    "regexp",
    "pattern_file",
    "file_type",
    "type_not",
    "type_add",
    "type_clear",
    "ignore_case",
    "case_sensitive",
    "smart_case",
];

/// Push `(scope, index, id, value)` for every command-line occurrence of an
/// [`ORDERED_ARGS`] flag in one command's matches. Boolean flags carry an
/// empty value.
fn collect_ordered_args(
    matches: &clap::ArgMatches,
    scope: usize,
    found: &mut Vec<(usize, usize, &'static str, String)>,
) {
    for id in ORDERED_ARGS {
        // Defaults are recorded with indices too.
        if matches.value_source(id) != Some(clap::parser::ValueSource::CommandLine) {
            continue;
        }
        let Some(mut indices) = matches.indices_of(id) else {
            continue;
        };
        match matches.try_get_many::<String>(id) {
            Ok(Some(values)) => found.extend(
                indices
                    .zip(values)
                    .map(|(index, value)| (scope, index, id, value.clone())),
            ),
            _ => found.extend(
                indices
                    .next_back()
                    .map(|index| (scope, index, id, String::new())),
            ),
        }
    }
}

impl Cli {
    fn try_parse_args_from<I, T>(args: I) -> std::result::Result<Self, clap::Error>
    where
        I: IntoIterator<Item = T>,
        T: Into<std::ffi::OsString> + Clone,
    {
        let args: Vec<std::ffi::OsString> = args.into_iter().map(Into::into).collect();
        let mut command = Self::command();
        let matches = command.try_get_matches_from_mut(args.iter().cloned())?;
        // Clap conflicts are unconditional; this one depends on the mode's
        // value and must not treat the inherited budget as an explicit flag.
        if let Some(("serve", serve)) = matches.subcommand()
            && serve.get_one::<serve::WatchMode>("watch_mode") == Some(&serve::WatchMode::Poll)
            && serve.value_source("watch_budget") == Some(clap::parser::ValueSource::CommandLine)
        {
            return Err(command
                .find_subcommand_mut("serve")
                .expect("serve subcommand exists")
                .error(
                    clap::error::ErrorKind::ArgumentConflict,
                    "--watch-budget cannot be used with --watch-mode poll",
                ));
        }
        let mut cli = Self::from_arg_matches(&matches)?;
        // Global booleans propagate across subcommands without applying their
        // mutual overrides. Groups retain the locally supplied choice, so the
        // deepest command's boundary flag wins over a parent command's flag.
        let mut scope = &matches;
        while let Some((_, subcommand)) = scope.subcommand() {
            if let Some(boundary) = subcommand
                .get_many::<clap::Id>("match_boundary")
                .and_then(|mut choices| choices.next_back())
            {
                cli.word_regexp = boundary == "word_regexp";
                cli.line_regexp = boundary == "line_regexp";
            }
            scope = subcommand;
        }
        cli.resolve_ordered_args(&matches, &args);
        Ok(cli)
    }

    /// Rebuild the flags whose relative order matters from their command-line
    /// positions. Clap stores each flag's values separately, and keeps only the
    /// deepest scope's values of a global flag, so neither `-T rust -t rust` nor
    /// `-e foo search -e bar` survives in the parsed fields. Any subcommand,
    /// nested or not, splits them the same way, and `--type-list` honors them
    /// under every one.
    fn resolve_ordered_args(&mut self, matches: &clap::ArgMatches, args: &[std::ffi::OsString]) {
        let mut found = Vec::new();
        collect_ordered_args(matches, 0, &mut found);
        // The root holds every scope's flags, but only the deepest scope's
        // values of each.
        if !found.is_empty()
            && matches.subcommand().is_some()
            && let Some(probe) = Self::probe_scopes(args)
        {
            found.clear();
            // Clap restarts its indices in each subcommand, whose arguments
            // all follow its parent's.
            let chain = std::iter::successors(Some(&probe), |scope| {
                scope.subcommand().map(|(_, subcommand)| subcommand)
            });
            for (depth, scope) in chain.enumerate() {
                collect_ordered_args(scope, depth, &mut found);
            }
        }
        found.sort_by_key(|&(scope, index, ..)| (scope, index));

        use search::PatternSource;
        use tgrep_core::filetypes::TypeOp;
        self.pattern_sources.clear();
        self.type_ops.clear();
        self.regexp.clear();
        self.pattern_file.clear();
        self.file_type.clear();
        self.type_not.clear();
        self.type_add.clear();
        self.type_clear.clear();
        let mut case_flag = None;
        for (_, _, id, value) in found {
            match id {
                "regexp" => {
                    self.regexp.push(value.clone());
                    self.pattern_sources.push(PatternSource::Regexp(value));
                }
                "pattern_file" => {
                    self.pattern_file.push(value.clone());
                    self.pattern_sources.push(PatternSource::File(value));
                }
                "file_type" => {
                    self.file_type.push(value.clone());
                    self.type_ops.push(TypeOp::Select(value));
                }
                "type_not" => {
                    self.type_not.push(value.clone());
                    self.type_ops.push(TypeOp::Negate(value));
                }
                "type_add" => {
                    self.type_add.push(value.clone());
                    self.type_ops.push(TypeOp::Add(value));
                }
                "type_clear" => {
                    self.type_clear.push(value.clone());
                    self.type_ops.push(TypeOp::Clear(value));
                }
                _ => case_flag = Some(id),
            }
        }
        // As in ripgrep, the last of `-i`, `-s` and `-S` decides.
        if let Some(flag) = case_flag {
            self.ignore_case = flag == "ignore_case";
            self.case_sensitive = flag == "case_sensitive";
            self.smart_case = flag == "smart_case";
        }
    }

    /// Re-parse with the order-sensitive flags local to every command, nested
    /// ones included, so the matches at each level of the subcommand chain hold
    /// only that command's own occurrences. Returns `None` if that parse fails.
    fn probe_scopes(args: &[std::ffi::OsString]) -> Option<clap::ArgMatches> {
        fn localize(command: clap::Command, local: &[clap::Arg]) -> clap::Command {
            let names: Vec<String> = command
                .get_subcommands()
                .map(|subcommand| subcommand.get_name().to_owned())
                .collect();
            names.into_iter().fold(command, |command, name| {
                command.mut_subcommand(name, |subcommand| {
                    localize(subcommand.args(local.iter().cloned()), local)
                })
            })
        }
        let mut command = Self::command();
        let local: Vec<clap::Arg> = command
            .get_arguments()
            .filter(|arg| ORDERED_ARGS.contains(&arg.get_id().as_str()))
            .map(|arg| arg.clone().global(false))
            .collect();
        for id in ORDERED_ARGS {
            command = command.mut_arg(id, |arg| arg.global(false));
        }
        localize(command, &local)
            .try_get_matches_from(args.iter().cloned())
            .ok()
    }

    /// Resolve `--max-filesize` once, so a malformed value is reported instead
    /// of silently falling back to a different limit than the user asked for.
    ///
    /// Absent both flags this is [`walker::DEFAULT_MAX_FILE_SIZE`], not `None`.
    /// Resolving the default *here* rather than at each use is what keeps the
    /// index and the search agreeing: a walk that capped at 64 MiB while the
    /// search did not would look exactly like "this file contains no match".
    fn max_filesize_bytes(&self) -> Result<Option<u64>> {
        if self.no_max_filesize {
            return Ok(None);
        }
        match self.max_filesize.as_deref() {
            Some(s) => Ok(Some(parse_byte_size("--max-filesize", s)?)),
            None => Ok(tgrep_core::walker::DEFAULT_MAX_FILE_SIZE),
        }
    }

    /// Resolve `-E/--encoding`. `--no-encoding` means `auto`, and clap's
    /// mutual `overrides_with` makes whichever flag came last win, as ripgrep
    /// does.
    fn encoding_mode(&self) -> Result<tgrep_core::encoding::EncodingMode> {
        match self.encoding.as_deref() {
            Some(label) => tgrep_core::encoding::parse_encoding(label),
            None => Ok(tgrep_core::encoding::EncodingMode::Auto),
        }
    }

    /// Parse every argument that can fail, so a bad value exits with a usage
    /// error instead of silently searching with different settings.
    fn resolve(&self) -> Result<ResolvedArgs> {
        let engine = if self.pcre2 {
            matching::RegexEngine::Pcre2
        } else {
            matching::RegexEngine::from_str_opt(&self.engine)
                .ok_or_else(|| anyhow::anyhow!("unrecognized regex engine: {}", self.engine))?
        };

        let sort = match (&self.sort, &self.sortr, self.sort_files) {
            (Some(key), _, _) => parse_sort(key, false)?,
            (None, Some(key), _) => parse_sort(key, true)?,
            (None, None, true) => Some(search::SortMode {
                key: search::SortKey::Path,
                reverse: false,
            }),
            _ => None,
        };

        Ok(ResolvedArgs {
            max_filesize: self.max_filesize_bytes()?,
            max_filesize_requested: self.max_filesize.is_some() || self.no_max_filesize,
            encoding: self.encoding_mode()?,
            engine,
            regex_size_limit: self
                .regex_size_limit
                .as_deref()
                .map(|s| parse_size_limit("--regex-size-limit", s))
                .transpose()?,
            dfa_size_limit: self
                .dfa_size_limit
                .as_deref()
                .map(|s| parse_size_limit("--dfa-size-limit", s))
                .transpose()?,
            sort,
        })
    }

    /// Split the positional arguments into a pattern and a list of paths.
    ///
    /// ripgrep only treats the first positional as the pattern when no pattern
    /// was supplied another way. Once `-e` or `-f` is present every positional
    /// is a path, so `rg -e foo src` searches `src` rather than also searching
    /// for the literal string `src`.
    fn split_pattern_and_paths(
        &self,
        positional: Option<&String>,
        rest: &[String],
    ) -> (String, Vec<String>) {
        if self.pattern_sources.is_empty() {
            return (positional.cloned().unwrap_or_default(), rest.to_vec());
        }
        let mut paths = Vec::with_capacity(rest.len() + 1);
        paths.extend(positional.cloned());
        paths.extend(rest.iter().cloned());
        (String::new(), paths)
    }

    fn build_search_opts(&self, pattern: String, resolved: &ResolvedArgs) -> search::SearchOptions {
        // `-p/--pretty` is ripgrep's alias for --color always --heading -n.
        let heading = if self.heading || self.pretty {
            Some(true)
        } else if self.no_heading {
            Some(false)
        } else {
            None
        };
        let color = if self.pretty {
            ColorMode::Always
        } else {
            ColorMode::from_str_opt(&self.color).unwrap_or(ColorMode::Auto)
        };
        let no_ignore = self.no_ignore || self.unrestricted >= 1;
        let hidden = self.hidden || self.unrestricted >= 2;
        // ripgrep's third `-u` is `--binary`, not `-a/--text`: binary files
        // become visible and are summarised with a note, rather than having
        // their lines dumped as text.
        let binary = self.binary || self.unrestricted >= 3;
        let text = self.text;

        // ripgrep implements `-c`, `--count-matches`, `-l`, `--files-without-match`
        // and `--files` in a printer that predates `--json` and has no JSON form,
        // so those flags win outright and the whole invocation produces no JSON —
        // not even a `summary`. Dropping the flag here rather than only in
        // `make_output_config` keeps every other `json`-conditional decision
        // (binary handling, match detail) consistent with the printer in use.
        let json = self.json
            && !(self.count
                || self.count_matches
                || self.files_only
                || self.files_without_match
                || self.list_files);

        search::SearchOptions {
            pattern,
            pattern_sources: self.pattern_sources.clone(),
            case_insensitive: self.ignore_case,
            case_sensitive: self.case_sensitive,
            smart_case: self.smart_case,
            fixed_string: self.fixed_strings,
            files_only: self.files_only,
            files_without_match: self.files_without_match,
            count: self.count,
            word_boundary: self.word_regexp,
            max_count: self.max_count,
            json,
            vimgrep: self.vimgrep,
            stats: self.stats || self.debug || self.trace,
            no_index: self.no_index,
            shared: self.shared,
            glob: self.glob.clone(),
            iglob: self.iglob.clone(),
            glob_case_insensitive: self.glob_case_insensitive,
            type_ops: self.type_ops.clone(),
            invert_match: self.invert_match,
            only_matching: self.only_matching,
            after_context: self.after_context,
            before_context: self.before_context,
            context: self.context,
            heading,
            color,
            null: self.null,
            trim: self.trim,
            // --multiline-dotall implies --multiline, as in ripgrep.
            multiline: self.multiline || self.multiline_dotall,
            multiline_dotall: self.multiline_dotall,
            no_ignore,
            hidden,
            quiet: self.quiet,
            no_filename: self.no_filename,
            // ripgrep only turns line numbers on for a terminal, so a piped
            // stream stays `path:content` for whatever parses it. `--column`,
            // `--vimgrep` and `-p` all ask for the line number explicitly.
            no_line_number: self.no_line_number
                || !(self.line_number
                    || self.column
                    || self.vimgrep
                    || self.pretty
                    || crate::output::atty_check()),
            text,
            binary,
            content_eligibility: self.content_eligibility.into(),
            // Replaced per path argument in `run_search`.
            path_display: crate::output::PathDisplay::Bare,
            max_filesize: resolved.max_filesize,
            max_filesize_requested: resolved.max_filesize_requested,
            encoding: resolved.encoding,
            follow: self.follow,
            no_messages: self.no_messages,
            no_ignore_messages: self.no_ignore_messages,
            line_regexp: self.line_regexp,
            no_unicode: self.no_unicode,
            engine: resolved.engine,
            regex_size_limit: resolved.regex_size_limit,
            dfa_size_limit: resolved.dfa_size_limit,
            replace: self.replace.clone(),
            passthru: self.passthru,
            stop_on_nonmatch: self.stop_on_nonmatch,
            column: self.column || self.vimgrep,
            byte_offset: self.byte_offset,
            // ripgrep treats `-M 0` as "no limit", not "omit every line".
            max_columns: self.max_columns.filter(|&limit| limit > 0),
            max_columns_preview: self.max_columns_preview,
            count_matches: self.count_matches,
            include_zero: self.include_zero,
            context_separator: if self.no_context_separator {
                None
            } else {
                Some(
                    self.context_separator
                        .clone()
                        .unwrap_or_else(|| "--".to_string()),
                )
            },
            field_match_separator: self
                .field_match_separator
                .clone()
                .unwrap_or_else(|| ":".to_string()),
            field_context_separator: self
                .field_context_separator
                .clone()
                .unwrap_or_else(|| "-".to_string()),
            path_separator: self.path_separator.clone(),
            sort: resolved.sort,
            max_depth: self.max_depth,
            one_file_system: self.one_file_system,
            ignore_files: if self.no_ignore_files {
                Vec::new()
            } else {
                self.ignore_file.clone()
            },
            ignore_file_case_insensitive: self.ignore_file_case_insensitive,
            no_ignore_dot: self.no_ignore_dot,
            no_ignore_exclude: self.no_ignore_exclude,
            no_ignore_global: self.no_ignore_global,
            no_ignore_parent: self.no_ignore_parent,
            no_ignore_vcs: self.no_ignore_vcs,
            no_require_git: self.no_require_git,
            threads: self.threads,
            line_buffered: self.line_buffered,
        }
    }

    /// File-discovery flags that are declared globally (so every subcommand
    /// accepts them) but that `index` and `serve` do not plumb into their
    /// walks.
    ///
    /// These change *which files exist* as far as the tool is concerned, so
    /// accepting one and ignoring it produces an index that silently disagrees
    /// with what was asked for — and, for `serve`, one that then disagrees with
    /// `tgrep search` over the same tree. That is indistinguishable from a
    /// corpus with no matches, so the only safe answer is to refuse.
    ///
    /// Both builders include hidden files by default, so `--hidden` is accepted
    /// as a redundant flag. `--threads` is excluded deliberately: it is documented as
    /// accepted-for-compatibility and ignored everywhere, not just here.
    fn unsupported_discovery_flags(&self) -> Vec<&'static str> {
        let mut out = Vec::new();
        if self.follow {
            out.push("--follow");
        }
        if self.max_depth.is_some() {
            out.push("--max-depth");
        }
        if self.one_file_system {
            out.push("--one-file-system");
        }
        if !self.ignore_file.is_empty() {
            out.push("--ignore-file");
        }
        if self.ignore_file_case_insensitive {
            out.push("--ignore-file-case-insensitive");
        }
        if self.no_ignore_dot {
            out.push("--no-ignore-dot");
        }
        if self.no_ignore_exclude {
            out.push("--no-ignore-exclude");
        }
        if self.no_ignore_files {
            out.push("--no-ignore-files");
        }
        if self.no_ignore_global {
            out.push("--no-ignore-global");
        }
        if self.no_ignore_parent {
            out.push("--no-ignore-parent");
        }
        if self.no_ignore_vcs {
            out.push("--no-ignore-vcs");
        }
        if self.content_eligibility != ContentEligibilityArg::Extensions {
            out.push("--content-eligibility");
        }
        out
    }
}

/// Exit with a clear error rather than building an index under settings the
/// caller did not ask for. See [`Cli::unsupported_discovery_flags`].
fn reject_unsupported_discovery_flags(cli: &Cli, subcommand: &str) {
    let unsupported = cli.unsupported_discovery_flags();
    if unsupported.is_empty() {
        return;
    }
    eprintln!(
        "tgrep: `{subcommand}` does not support {}; \
         it would be ignored and the index would not match what you asked for",
        unsupported.join(", ")
    );
    process::exit(2);
}

fn main() {
    // clap's derive builds every argument in a single generated stack frame,
    // and tgrep declares enough flags that an unoptimised build overflows the
    // default main-thread stack before parsing finishes. Run the real work on a
    // thread with room to spare so debug builds behave like release ones.
    let worker = std::thread::Builder::new()
        .stack_size(32 * 1024 * 1024)
        .spawn(run_cli)
        .expect("failed to spawn worker thread");
    if worker.join().is_err() {
        process::exit(2);
    }
}

fn run_cli() {
    let cli = Cli::try_parse_args_from(std::env::args_os()).unwrap_or_else(|error| error.exit());
    let no_ignore = cli.no_ignore || cli.unrestricted >= 1;

    // Handle --type-list. It reflects --type-add/--type-clear so users can
    // verify a custom definition without running a search. Like ripgrep, it
    // applies them in argument order and rejects an unknown -t/-T first.
    if cli.type_list {
        let mut defs = tgrep_core::filetypes::TypeDefs::builtin();
        if let Err(e) = defs
            .apply(&cli.type_ops)
            .and_then(|()| defs.build_selections(&cli.type_ops))
        {
            eprintln!("tgrep: {e}");
            process::exit(2);
        }
        defs.print_list();
        process::exit(0);
    }

    // `-z/--search-zip` would need transparent decompression. Failing loudly is
    // the only safe answer: silently ignoring it makes an archive full of hits
    // look like a repo with none.
    if cli.search_zip {
        eprintln!("tgrep: -z/--search-zip is not supported; decompress the files first");
        process::exit(2);
    }

    // `--pcre2-version` reports the backtracking engine and exits, like ripgrep.
    // tgrep links fancy-regex rather than PCRE2 itself, so say so instead of
    // printing a PCRE2 version number that no PCRE2 is behind.
    if cli.pcre2_version {
        println!("fancy-regex (PCRE2-compatible backtracking engine; PCRE2 is not linked)");
        process::exit(0);
    }

    // Validate every parseable argument up front: a bad value must fail loudly
    // rather than silently searching with different settings than were asked
    // for, which is indistinguishable from "no matches".
    let resolved = match cli.resolve() {
        Ok(v) => v,
        Err(e) => {
            eprintln!("tgrep: {e}");
            process::exit(2);
        }
    };
    let max_filesize = resolved.max_filesize;

    // Refuse discovery flags the index-building subcommands can't honour. Done
    // before the match so the arms keep consuming `cli.command` by value.
    match &cli.command {
        Some(Command::Index { .. }) => reject_unsupported_discovery_flags(&cli, "index"),
        Some(Command::Serve { .. }) => reject_unsupported_discovery_flags(&cli, "serve"),
        _ => {}
    }

    if cli.shared && matches!(cli.command, Some(Command::Index { .. })) {
        eprintln!("tgrep: --shared does not change index; use shared attach --revision");
        process::exit(2);
    }
    if cli.shared
        && let Some(Command::Serve {
            ref exclude,
            max_memory_mb,
            max_cpu_percent,
            auto_save_mutations,
            ..
        }) = cli.command
        && (cli.index_path.is_some()
            || no_ignore
            || cli.no_require_git
            || !exclude.is_empty()
            || max_memory_mb.is_some()
            || max_cpu_percent.is_some()
            || auto_save_mutations.is_some()
            || max_filesize != Some(64 * 1024 * 1024)
            || resolved.encoding.may_differ_from_index()
            || cli.text
            || cli.binary)
    {
        eprintln!(
            "tgrep: shared serve supports only the default raw-auto 64 MiB profile, not legacy index/storage/build options"
        );
        process::exit(2);
    }

    let result = match cli.command {
        Some(Command::Index {
            path,
            exclude,
            strategy,
            index_buffer_mb,
            ..
        }) => {
            index::run(index::RunOptions {
                root: &path,
                index_path: cli.index_path.as_deref(),
                include_hidden: true,
                no_ignore,
                no_require_git: cli.no_require_git,
                exclude_dirs: &exclude,
                strategy: strategy.into(),
                index_buffer_mb,
                // Already carries `walker::DEFAULT_MAX_FILE_SIZE` when the user
                // named no limit, so indexing and searching cap identically.
                max_file_size: max_filesize,
            })
        }
        Some(Command::Serve {
            path,
            shared_storage,
            shared_policy,
            shared_max_views,
            shared_max_leases,
            no_watch,
            watch_mode,
            poll_interval,
            watch_budget,
            max_memory_mb,
            max_cpu_percent,
            exclude,
            auto_save_mutations,
            watcher_queue_cap,
        }) => {
            let memory_cap = max_memory_mb
                .map(|mb| mb.saturating_mul(1024 * 1024))
                .unwrap_or_else(mem::default_memory_cap_bytes);
            let index_threads = cpu::index_thread_count(max_cpu_percent.unwrap_or(50));
            if cli.shared {
                match shared_storage {
                    Some(storage) => {
                        let options = serve::shared::Options {
                            storage: &storage,
                            no_watch,
                            watch_mode,
                            poll_interval: Duration::from_secs(poll_interval),
                            watch_budget: watch_budget as usize,
                            hint_budget: watcher_queue_cap.unwrap_or(16384) as usize,
                            max_views: shared_max_views as usize,
                            max_leases: shared_max_leases as usize,
                        };
                        match shared_policy {
                            Some(policy) => serve::shared::run_managed(&path, options, &policy),
                            None => serve::shared::run(&path, options),
                        }
                    }
                    None => Err(anyhow::anyhow!(
                        "serve --shared requires --shared-storage <existing external directory>"
                    )),
                }
            } else {
                serve::run(
                    &path,
                    cli.index_path.as_deref(),
                    serve::ServeOptions {
                        no_watch,
                        watch_mode,
                        poll_interval: Duration::from_secs(poll_interval),
                        watch_budget: watch_budget as usize,
                        exclude_dirs: &exclude,
                        memory_cap_bytes: memory_cap,
                        index_threads,
                        no_ignore,
                        no_require_git: cli.no_require_git,
                        // Same resolved value the search path uses, so the index
                        // and the queries against it agree on what exists.
                        max_file_size: max_filesize,
                        auto_save_mutations,
                        // Clap's range bound guarantees this fits; saturating keeps
                        // the conversion total, and errs toward a large cap rather
                        // than a zero-length (rendezvous) queue.
                        watcher_queue_cap: watcher_queue_cap
                            .map(|n| usize::try_from(n).unwrap_or(usize::MAX)),
                    },
                )
            }
        }
        Some(Command::Shared { command }) => serve::shared::run_lifecycle(command),
        Some(Command::Search {
            ref pattern,
            ref paths,
        }) => {
            let (pattern, paths) = cli.split_pattern_and_paths(Some(pattern), paths);
            run_search(&cli, pattern, &paths, &resolved)
        }
        Some(Command::Status { path }) => {
            match serve::shared::Client::selected(&path, cli.shared, cli.index_path.as_deref()) {
                Ok(false) => status::run(&path, cli.index_path.as_deref()),
                Ok(true) => serve::shared::status(&path, cli.index_path.as_deref()),
                Err(error) => Err(error),
            }
        }
        Some(Command::CountFiles { path }) => walkcount::run(&path, cli.hidden, no_ignore),
        None => {
            if cli.list_files {
                let opts = cli.build_search_opts(String::new(), &resolved);
                let paths = list_files_paths(&cli);
                list_files(&paths, cli.index_path.as_deref(), &opts)
            } else if cli.pattern.is_some() || !cli.pattern_sources.is_empty() {
                let (pattern, paths) =
                    cli.split_pattern_and_paths(cli.pattern.as_ref(), &cli.paths);
                run_search(&cli, pattern, &paths, &resolved)
            } else {
                eprintln!("Usage: tgrep <pattern> [PATH ...]");
                eprintln!("       tgrep index [path]");
                eprintln!("       tgrep serve [path]");
                eprintln!("       tgrep status [path]");
                eprintln!("Search defaults to the current directory when no path is provided.");
                eprintln!("Run `tgrep --help` for full usage.");
                process::exit(2);
            }
        }
    };

    if let Err(e) = result {
        eprintln!("tgrep: {e}");
        process::exit(2);
    }
}

/// A path argument, kept alongside the exact text the user typed.
///
/// ripgrep echoes the argument verbatim into every path it prints, so the
/// original spelling (`.`, `./src`, `src\`, an absolute path) has to survive
/// past the point where the path is canonicalised for the actual walk.
struct SearchTarget {
    path: PathBuf,
    typed: String,
}

impl SearchTarget {
    /// How paths found under this argument should be printed.
    fn display(&self) -> output::PathDisplay {
        if self.typed.is_empty() {
            return output::PathDisplay::Bare;
        }
        if self.path.is_file() {
            return output::PathDisplay::Exact(self.typed.clone());
        }
        // A trailing separator the user typed is kept as typed; otherwise
        // ripgrep joins with the platform separator.
        let mut prefix = self.typed.clone();
        if !prefix.ends_with(['/', '\\']) {
            prefix.push(std::path::MAIN_SEPARATOR);
        }
        output::PathDisplay::Prefix(prefix)
    }
}

fn normalize_search_paths(paths: &[String]) -> Vec<SearchTarget> {
    if paths.is_empty() {
        return vec![SearchTarget {
            path: PathBuf::from("."),
            typed: String::new(),
        }];
    }

    // Arguments are used verbatim, as ripgrep does: whitespace and quote
    // characters are legal in file names, and the shell has already removed
    // any quoting the user typed.
    paths
        .iter()
        .map(|path| SearchTarget {
            path: PathBuf::from(path),
            typed: path.clone(),
        })
        .collect()
}

fn list_files_paths(cli: &Cli) -> Vec<String> {
    let mut paths = Vec::new();
    if let Some(pattern) = cli.pattern.clone() {
        paths.push(pattern);
    }
    paths.extend(cli.paths.iter().cloned());
    paths
}

fn list_files(
    paths: &[String],
    index_path: Option<&std::path::Path>,
    opts: &search::SearchOptions,
) -> anyhow::Result<()> {
    let mut opts = opts.clone();
    for target in normalize_search_paths(paths) {
        if !target.path.exists() {
            report_missing_path(&target.path, opts.no_messages);
            continue;
        }
        opts.path_display = target.display();
        search::list_files(&target.path, index_path, &opts)?;
    }
    Ok(())
}

/// ripgrep reports unreadable paths on stderr and finishes the remaining
/// paths, then exits 2. Silently skipping them hides typos and broken globs.
fn report_missing_path(path: &std::path::Path, no_messages: bool) {
    ERRORED.store(true, std::sync::atomic::Ordering::SeqCst);
    if !no_messages {
        // Ask the OS for the message instead of hard-coding one: the text and
        // the errno differ per platform, and on Windows even between a missing
        // file (error 2) and a missing directory component (error 3).
        let reason = match std::fs::metadata(path) {
            Err(err) => err.to_string(),
            // The path appeared between the existence check and this call.
            Ok(_) => std::io::Error::from(std::io::ErrorKind::NotFound).to_string(),
        };
        let path = path.display();
        eprintln!("tgrep: {path}: IO error for operation on {path}: {reason}");
    }
}

fn run_search(
    cli: &Cli,
    pattern: String,
    paths: &[String],
    resolved: &ResolvedArgs,
) -> anyhow::Result<()> {
    let mut opts = cli.build_search_opts(pattern, resolved);
    if !opts.resolve_patterns()? && !opts.invert_match {
        process::exit(1);
    }
    let mut had_matches = false;

    // ripgrep decides these once, from the whole argument list: file names are
    // shown unless exactly one file was named, and line numbers only when
    // writing to a terminal.
    let targets = normalize_search_paths(paths);
    opts.no_filename = cli.no_filename
        || (!cli.with_filename && !cli.vimgrep && targets.len() == 1 && targets[0].path.is_file());

    // One writer for the whole invocation: ripgrep emits a single JSON
    // `summary` covering every path it was given, so per-path writers would
    // report one summary each and a consumer reading "the" summary would see
    // only the first path's numbers.
    let mut writer = search::new_writer(&opts);

    for target in targets {
        if !target.path.exists() {
            report_missing_path(&target.path, opts.no_messages);
            continue;
        }
        writer.set_path_display(target.display());
        match search::run(&target.path, cli.index_path.as_deref(), &opts, &mut writer) {
            Ok(true) => {
                had_matches = true;
                if opts.quiet {
                    // `process::exit` skips destructors, so the summary and any
                    // buffered output have to be committed explicitly.
                    let _ = writer.finish();
                    process::exit(0);
                }
            }
            Ok(false) => {}
            Err(e) => {
                if !opts.no_messages {
                    eprintln!("tgrep: {e}");
                }
                let _ = writer.finish();
                process::exit(2);
            }
        }
    }

    writer.finish()?;

    // ripgrep's exit code: 0 on a match with no errors, 2 if anything was
    // reported to stderr, otherwise 1 for "no matches".
    let errored = ERRORED.load(std::sync::atomic::Ordering::SeqCst);
    if had_matches && (opts.quiet || !errored) {
        process::exit(0);
    }
    if errored {
        process::exit(2);
    }
    process::exit(1);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse(args: &[&str]) -> std::result::Result<Cli, clap::Error> {
        let args: Vec<String> = std::iter::once("tgrep")
            .chain(args.iter().copied())
            .map(String::from)
            .collect();
        std::thread::Builder::new()
            .stack_size(32 * 1024 * 1024)
            .spawn(move || Cli::try_parse_args_from(args))
            .unwrap()
            .join()
            .unwrap()
    }

    #[test]
    fn word_and_line_regexp_override_each_other_in_argument_order() {
        for (args, word) in [
            (vec!["-x", "-w", "foo"], true),
            (vec!["-w", "-x", "foo"], false),
            (vec!["-x", "search", "-w", "foo"], true),
            (vec!["-w", "search", "-x", "foo"], false),
            (vec!["search", "-xw", "foo"], true),
            (vec!["search", "-wx", "foo"], false),
            (vec!["-w", "search", "-xw", "foo"], true),
            (vec!["-x", "search", "-wx", "foo"], false),
            (vec!["-w", "search", "foo"], true),
            (vec!["-x", "search", "foo"], false),
        ] {
            let cli = parse(&args).unwrap();
            assert_eq!(cli.word_regexp, word, "{args:?}");
            assert_eq!(cli.line_regexp, !word, "{args:?}");
        }
    }

    #[test]
    fn pattern_sources_keep_argument_order_across_scopes() {
        use search::PatternSource::{File, Regexp};
        let regexp = |p: &str| Regexp(p.to_string());
        let file = |p: &str| File(p.to_string());
        for (args, expected) in [
            (vec!["-e", "foo", "data"], vec![regexp("foo")]),
            (
                vec!["-e", "foo", "search", "-e", "bar", "data"],
                vec![regexp("foo"), regexp("bar")],
            ),
            (
                vec!["-f", "a", "search", "-f", "b", "data"],
                vec![file("a"), file("b")],
            ),
            (
                vec!["-f", "a", "-f", "b", "data"],
                vec![file("a"), file("b")],
            ),
            (
                vec![
                    "-e", "foo", "-f", "a", "search", "-e", "bar", "-f", "b", "data",
                ],
                vec![regexp("foo"), file("a"), regexp("bar"), file("b")],
            ),
            (
                vec!["search", "-f", "a", "-e", "foo", "-f", "b", "data"],
                vec![file("a"), regexp("foo"), file("b")],
            ),
            (
                vec!["-e", "foo", "status", "-e", "bar"],
                vec![regexp("foo"), regexp("bar")],
            ),
            (
                vec![
                    "-f", "a", "shared", "-e", "foo", "detach", "--lease", "t", "-f", "b", ".",
                ],
                vec![file("a"), regexp("foo"), file("b")],
            ),
            (vec!["foo", "data"], vec![]),
        ] {
            let cli = parse(&args).unwrap();
            assert_eq!(cli.pattern_sources, expected, "{args:?}");
        }
    }

    #[test]
    fn type_ops_keep_argument_order_across_scopes() {
        use tgrep_core::filetypes::TypeOp::{Add, Clear, Negate, Select};
        let s = String::from;
        for (args, expected) in [
            (
                vec!["-T", "rust", "-t", "rust", "foo"],
                vec![Negate(s("rust")), Select(s("rust"))],
            ),
            (
                vec!["-t", "rust", "-T", "rust", "foo"],
                vec![Select(s("rust")), Negate(s("rust"))],
            ),
            (
                vec!["-T", "rust", "search", "-t", "rust", "foo"],
                vec![Negate(s("rust")), Select(s("rust"))],
            ),
            (
                vec![
                    "--type-add",
                    "rust:*.txt",
                    "search",
                    "--type-clear",
                    "rust",
                    "-t",
                    "rust",
                    "foo",
                ],
                vec![Add(s("rust:*.txt")), Clear(s("rust")), Select(s("rust"))],
            ),
            (
                vec![
                    "--type-clear",
                    "rust",
                    "--type-add",
                    "rust:*.txt",
                    "-t",
                    "rust",
                    "foo",
                ],
                vec![Clear(s("rust")), Add(s("rust:*.txt")), Select(s("rust"))],
            ),
            // `--type-list` reads these under any subcommand.
            (
                vec![
                    "--type-clear",
                    "rust",
                    "index",
                    "--type-add",
                    "rust:*.txt",
                    "--type-list",
                ],
                vec![Clear(s("rust")), Add(s("rust:*.txt"))],
            ),
            (
                vec!["-t", "rust", "serve", "-T", "rust"],
                vec![Select(s("rust")), Negate(s("rust"))],
            ),
            (
                vec![
                    "--type-add",
                    "rust:*.txt",
                    "count-files",
                    "--type-clear",
                    "rust",
                    "-t",
                    "rust",
                ],
                vec![Add(s("rust:*.txt")), Clear(s("rust")), Select(s("rust"))],
            ),
            (
                vec![
                    "-T",
                    "rust",
                    "shared",
                    "--type-clear",
                    "rust",
                    "attach",
                    "--revision",
                    "x",
                    "--type-add",
                    "rust:*.txt",
                    "-t",
                    "rust",
                    ".",
                ],
                vec![
                    Negate(s("rust")),
                    Clear(s("rust")),
                    Add(s("rust:*.txt")),
                    Select(s("rust")),
                ],
            ),
        ] {
            let cli = parse(&args).unwrap();
            assert_eq!(cli.type_ops, expected, "{args:?}");
        }
    }

    #[test]
    fn last_case_flag_wins_across_scopes() {
        // (ignore_case, case_sensitive, smart_case)
        for (args, expected) in [
            (vec!["foo"], (false, false, false)),
            (vec!["-i", "-s", "foo"], (false, true, false)),
            (vec!["-i", "-S", "foo"], (false, false, true)),
            (vec!["-s", "-S", "foo"], (false, false, true)),
            (vec!["-s", "-i", "foo"], (true, false, false)),
            (vec!["-i", "-s", "-i", "foo"], (true, false, false)),
            (vec!["-i", "search", "-s", "foo"], (false, true, false)),
            (vec!["-s", "search", "-i", "foo"], (true, false, false)),
            (vec!["-S", "search", "foo"], (false, false, true)),
            (vec!["search", "-i", "-S", "foo"], (false, false, true)),
            (vec!["-i", "status", "-s"], (false, true, false)),
            (vec!["-S", "index", "-i"], (true, false, false)),
            (
                vec!["-s", "shared", "-i", "detach", "--lease", "t", "-S", "."],
                (false, false, true),
            ),
            (
                vec!["-S", "shared", "-i", "detach", "--lease", "t", "."],
                (true, false, false),
            ),
        ] {
            let cli = parse(&args).unwrap();
            assert_eq!(
                (cli.ignore_case, cli.case_sensitive, cli.smart_case),
                expected,
                "{args:?}"
            );
        }
    }

    #[test]
    fn managed_poll_interval_help_distinguishes_native_watchers() {
        let help = parse(&["serve", "--help"]).err().expect("serve help");
        assert_eq!(help.kind(), clap::error::ErrorKind::DisplayHelp);
        let help = help.to_string();
        assert!(
            help.contains("Seconds to wait after a polling reconciliation completes"),
            "{help}"
        );
        assert!(
            help.contains(
                "Managed v2 also uses it to verify healthy native views while they serve"
            ),
            "{help}"
        );
    }

    #[test]
    fn refresh_defaults_and_explicit_modes() {
        for (args, expected_mode, expected_no_watch) in [
            (vec!["serve"], serve::WatchMode::Auto, false),
            (
                vec!["serve", "--watch-mode", "auto"],
                serve::WatchMode::Auto,
                false,
            ),
            (
                vec!["serve", "--watch-mode", "poll"],
                serve::WatchMode::Poll,
                false,
            ),
            (vec!["serve", "--no-watch"], serve::WatchMode::Auto, true),
        ] {
            let Some(Command::Serve {
                no_watch,
                watch_mode,
                poll_interval,
                watch_budget,
                ..
            }) = parse(&args).unwrap().command
            else {
                panic!("expected serve");
            };
            assert_eq!(no_watch, expected_no_watch);
            assert_eq!(watch_mode, expected_mode);
            assert_eq!(poll_interval, 120);
            assert_eq!(watch_budget, 8192);
        }
    }

    #[test]
    fn refresh_explicit_values_and_boundaries() {
        for (interval, budget) in [("1", "1"), ("120", "8192"), ("86400", "4294967295")] {
            let Some(Command::Serve {
                poll_interval,
                watch_budget,
                ..
            }) = parse(&[
                "serve",
                "--poll-interval",
                interval,
                "--watch-budget",
                budget,
            ])
            .unwrap()
            .command
            else {
                panic!("expected serve");
            };
            assert_eq!(poll_interval, interval.parse::<u64>().unwrap());
            assert_eq!(watch_budget, budget.parse::<u32>().unwrap());
        }
        assert!(parse(&["serve", "--watch-mode", "auto", "--watch-budget", "8192"]).is_ok());
        assert!(parse(&["serve", "--watch-mode", "poll", "--poll-interval", "1"]).is_ok());
        assert!(parse(&["serve", "--no-watch", "--watcher-queue-cap", "1"]).is_ok());
    }

    #[test]
    fn refresh_explicit_conflicts_include_default_values() {
        for args in [
            vec!["--watch-mode", "auto"],
            vec!["--watch-mode", "poll"],
            vec!["--poll-interval", "120"],
            vec!["--poll-interval", "1"],
            vec!["--watch-budget", "8192"],
            vec!["--watch-budget", "1"],
        ] {
            for no_watch_first in [true, false] {
                let mut command = vec!["serve"];
                if no_watch_first {
                    command.push("--no-watch");
                }
                command.extend(&args);
                if !no_watch_first {
                    command.push("--no-watch");
                }
                let error = parse(&command).err().expect("explicit flags conflict");
                assert_eq!(error.kind(), clap::error::ErrorKind::ArgumentConflict);
            }
        }
        for args in [
            ["serve", "--watch-mode", "poll", "--watch-budget", "8192"],
            ["serve", "--watch-budget", "1", "--watch-mode", "poll"],
        ] {
            let error = parse(&args)
                .err()
                .expect("poll does not use native watches");
            assert_eq!(error.kind(), clap::error::ErrorKind::ArgumentConflict);
            assert!(error.to_string().contains("--watch-budget"));
        }
    }

    #[test]
    fn refresh_rejects_invalid_values() {
        for (flag, values) in [
            ("--watch-mode", vec!["native", "disabled", "AUTO", ""]),
            ("--poll-interval", vec!["0", "86401", "-1", "1.5", "bad"]),
            (
                "--watch-budget",
                vec!["0", "4294967296", "-1", "1.5", "bad"],
            ),
        ] {
            for value in values {
                assert!(
                    parse(&["serve", &format!("{flag}={value}")]).is_err(),
                    "{flag}={value} should be rejected"
                );
            }
            assert!(parse(&["serve", flag]).is_err());
        }
    }
}
